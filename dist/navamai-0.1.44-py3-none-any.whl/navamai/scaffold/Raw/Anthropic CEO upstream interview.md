Intro
technological innovation eventually makes business process Innovation or
business model Innovation less important because you can just you know button press everything you know just do
everything yeah it's kind of like the interface and business process Innovation is almost like a substitute
for the intelligence of the model the more of one you have the less of the other you need and so it creates this
interesting Dynamics right where you have these kind of overlapping overlapping revolutions each which is a
little faster to Market than than the one before but maybe the music will stop at some point we don't we don't know for
sure you know what I always say about the scaling laws is like there's you know there's no one should believe that
that there's some you know F fundamental physical law that means they're going to continue it's an empirical observation
they could stop at any time I've been watching them for 10 years and my belief that they my my guess that they won't is
is just based on the amount of time I've been watching them so far but but you know that that that you know that's not
that's a that's a 6040 maybe 7030 proposition the the trend is your friend till the bend at the end as they say i'
I've never heard that phrase but that is that that would indeed be
[Music]
correct hey Upstream listeners this is Natalie one of The Producers at turpentine the podcast Network behind
Upstream with Eric torberg we're super excited to be able to use this feed to highlight the absolute best content and
most insightful interviews across our entire network today we're kicking it off with this week's exciting episode of
econ 102 our economics podcast hosted by Eric and Noah Smith of no opinion where
they were joined by none other than anthropics CEO Dario amadai the show is
usually a running conversation between Noah and Eric and a couple weeks ago they mentioned they wanted to have
someone from anthropic come on as it turns out anthropics co-founder Daniela amadi was listening and let Dario know
the conversation ahead is wide ranging Dario discusses the business moat for AI companies his views on AI safety and
National Security how AI will affect the labor market us relations with China and regulation like California's SB 1047
bill without further Ado here's the full conversation we'd love to hear your feedback you can email me at Nataly
turpentine doco or leave a comment to let me know what you'd like to hear more of on upstream and which guests you're
most interested in where's our guest they're coming they're coming in about to let them in
hello hello hey Dario hey Dario hey how's it going going all right it's been a while great to see you again Noah I I
think we met many years ago I don't remember exactly when we met a couple times yes before the pandemic we haven't
seen each other since since then so yeah that's that was a startling number of years ago I I can't hear you all that
clearly it's kind of coming through how about now is this is this a little better oh that's much better there whatever you did fixed it okay it's
called holding the mic closer to me because no I I I had to abandoned my
my usual setup because the the internet signal was being patchy in that room in my office and so I have to get a a relay
but until I do I'm just podcasting from my couch we we have a running joke at anthropic actually goes back to other
companies worked at that I've had to use on almost every podcast which is we'll solve AGI before we solve video
conferencing and I I think it's going to be literally true I think it's not a joke maybe the AGI can tell us how to
solve the video conferencing yes but the AGI will come first Dario we we haven't uh met face to
face yet but my I'm very close friends with with Yasmin from spark who's been singing your Praises for years and let
me know about how big anthropic was going to be years ago and put me on to you guys so it's great to it's great to
chat have you on yeah no yasmin's uh yasmin's great she's been a very very supportive investor excited to excited
to get started my sister and co-founder heard you you know you say on your podcast that it'd be great to have me
and so you know you spoke you spoke my name and you summoned me so here I am we
summoned you into existence and and maybe let's start there Dario because you have a interesting intellectual
Dario's intellectual evolution
Evolution why don't you briefly briefly describe your your intellectual evolution and why you're on an econ
podcast and why it's fitting yes let's see so I don't know if I go if I go all the way back like you know I think early
before I got involved with AI I was just trying to figure out what was would be most interesting and impactful to work
on so I did my undergrad in physics I believe Noah is the same actually and then considered a bunch of things
actually considered going to grad school for econ decided not to do that went to grad school for computational
neuroscience and biophysics I was very interested I considered AI as well but at that time I just didn't believe that
the the AI of that day was all that interesting or had made all that much progress on important problems in
intelligence and so I figured I'd study that you know the the the one object in the universe we know of that is it at
least sometimes sometimes intelligent the human brain you know and so worked
on that worked on basically networks of biological neurons and trying to
understand what was going on in them which turned out to be a very difficult task because you know just the biological access and the physical
measurement let alone even getting to the analysis just turns out to be a very very difficult task and spent most of my
time on that and very little of it making tiny bits of progress on trying to understand you know that the actual
algorithmics of what is going on inside the human brain and then around you know that I did a postto at at Stanford
worked on proteomics and then around 2014 or so you know the the the Deep
learning Revolution was starting I saw the work on Al net and quac net and so decided to get involved in that field I
worked with Andrew in at Buu for a year and then I was at Google for a year then I joined open AI very shortly after it
started was there for about was there for about five years developed a lot of the ideas around scaling laws help build
some of the early gpts as well as inventing the RL from Human feedback method along with others that you know
would eventually be used to to produce some of these these commercial chap Bots
and then left around the end of 2020 to to found anthropic and you know have been running anthropic ever since here's
Is Google the Bell Labs of Al?
a question in general you know this is econ podcast we like to talk about a little more the econ side than the than the pure Tech side but yeah so is Google
the Bell Labs of the artificial intelligence age because they you know
they produced the research that led to Modern deep learning and Transformers Etc and they didn't really manage to
commercialize it very well kind of like B labs they funded it from their you know it Monopoly kind of like Bell labs
and then you know a bunch of interesting people like you know worked there and then sort of went off and started companies U you know like the eventually
the Fairchild people did from Babs do you think this is an apt analogy yeah I mean while nothing is ever A Perfect
Analogy I certainly think there's something to it right when when when when I was at Google I mean you know for
for many people there they thought of it as a kind of continuation of their academic careers which was you know the
same the same as the same as you know the same as Bell labs in industrial you know an industrial environment that that
has many things in common with an academic environment except that it has kind of more more resources to make
things happen and so you know people were working on a lot of things right the Transformer which is kind of one of the key inventions that you know that
drove the field you know that was one of maybe a hundred things that that were being that were that were being worked
on and if you went high enough up if you went high enough up in the organization you know there was no reasonable
reasonable ability to distinguish between that and the 99 other things that were being invented it was like it
was it was l a thousand flowers bloom and you know it was it was I think during that time that I first started
having ideas around things like the scaling hypothesis that hey we needed to
take some of these Innovations we needed to really scale them up and we needed to put them together and in theory Google
was the best place to do that they have like the biggest clusters in the world they have you know a lot of of talented
engineering staff you know they kind of had all the ingredients but but the Google machine was organized in a
certain way it was organized to do search I don't think it was necessarily organized to kind of put all these
pieces together and scale up something radically different from from what from
what had been done before from what the business was about right like like Bell Labs wasn't set up to you know invent
computers and and give everyone a computer it was set up to like wire everyone up yeah exactly it was a
telephone company yeah and and and so you know I I mean you know I can't speak to Google
obviously obviously now they've you know inition to inventing all this these these you know these you know in
addition to inventing all these amazing things you know they have they're one of the four companies that has you know that that has the frontier models
they're you know both a partner to us and a competitor to us I know many people there they're super super smart
but but I think you're right that that there was a period where if they had had kind of if they had been able to put
together the ingredients in the right way they could have been the only they could have been the only game in town
and you know for whatever reason it didn't it didn't go that way well that's that Segways into something else that we were thinking about you know this the
idea of talking to you actually came from another podcast we were doing where I was mostly talking about the economics
of like internet businesses and then Eric came out with some some kind of pessimism on the business of AI and and
you know was like you know questioning whether you know how how much of emote AI companies have obviously this is
incredibly relevant to anthropic you know and and other companies that we call startups but they're already pretty
big and yeah so so tell us how you think about the the business Moe of AI companies yeah so I I I will say I'm
Economic moats in Al
going to separate this a little bit into two branches I will say it's a little hard to separate some ideas and
questions around the scaling hypothesis from the business questions so like let's let's consider the branch where
kind of the scaling hypothesis is is true in some very strong form and then let's consider the the version where it
you know might be somewhat true or not true at all in in the version where it's true in some very strong form you know I
probably laid this out else elsewhere in public but this is the version where you know you train a billion you know you
train a you've trained a hundred million doll model now and it's about as good as like you know a good college freshman or
something and you train a billion you know it's as good as advanced undergrad you train a 10 billion uh dollar model
and it's as good as you know like a top graduate student and then when you get to your hundred billion dollar model
it's as good as a Nobel Prize winner and then you you just take that model and you you know you put it to work for for
basically everyone right you know it becomes your cooworker it becomes your personal assistant it helps with
National Security it helps with Biology and and I think in that world like that system and the products
built on that system just become a very large fraction of the economy there's still a question of like well you know
where the returns go right do they go to Nvidia on one side do they go to the AI companies on the other side do they go
to Downstream applications and there the the pie is so big that to first order my
answer is yes they go to all of those places right but but but okay think about solar power you know solar is
obviously going to be absolutely immense you know and the more energy we need the more solar there will be and yet it's
hard to for me to name you a solar company that makes a bunch of profit it is a very commoditized product even
though there's plenty of innovation involved but yet there's no branding there's no network effects there's no
you know lock-ins of of anything it it's very hard for any Solar Company to make a profit on this thing that is radically
transforming our entire world in front of our eyes right now and so so I'm not
100% sure that you know just the fact that like everything will be booming as
it is in Soler right now in you know will lead necessarily to profits being
captured by companies but I'm certainly open to the the idea that it will be I just you know what what do you think
will be the source why will AI turn out different than solar yeah yeah so I I I
Scaling hypothesis and Al's future
think I think two points here and I I'll get to what you're saying because I think it's a I think it's an important question in most worlds maybe I'm just
making the point that this is like if if the scaling hypothesis is correct this is going to be like really really big
right and and so big that even if only 10% of the you know profits go to you
know part of the supply chain or that part of the supply chain it's just it's still really really big like you make
the pie big enough and that becomes the most interesting question although you know I'm sure that like the people who
are deciding how the dollar bills get get split up it's going to be you know really important to them whether one trillion goes here and 10 trillion goes
there 10 trillion goes here and one trillion goes there but let's let's actually get to your question because I think it it it matters it matters in all
the world it's just just a matter of you know what is what is the size of the pie that you're that you're Distributing
first of all I think on the model side and again this is dependent on the scaling hypothesis if we're building 10
or hundred billion dollar models there is not going to be probably more than
four or five entities maybe a couple like you know statun enti you know state
run players will get involved as well who who build these so we're looking at something that looks probably more
oligopolistic than it does monopolistic or fully commod ized I suppose there's a
question of you know will will someone release a you know1 billion or hundred billion open source model I'm somewhat
skeptical that that you know the the conviction to do that goes that far and I think actually even if such a model is
released one thing you know that's a disanalogy to to open- Source software
is that these big models they're actually very expensive to run on inference the majority of the cost is is
inference not necessarily the training of the model so if you have only you know I don't know 10 20% 30% better way
to do inference that can kind of negate the effect so the economics are kind of strange yes there's this giant fixed
cost that you have to amortise but then there's also the per unit cost of inference and small differences in that
can actually again assuming the thing is deployed widely enough make a very big difference so I don't know quite how
that's going to play out so that's actually similar to the economics of heavy industry like that's kind of how making steel Works a little bit yeah a
little bit Yeah interesting I I would the other thing I would say is you know
within these few models something we're already starting to see is that like models have different personalities and
so commoditization is one possibility and and I do see some worlds where even
within the oligopoly some particular ways of deploying models could get commoditized although I'm not sure but
one force pushing against that is the idea that I make a model that's really good at coding you make a model that's
like really good at creative writing this third person makes a model that's really good at being kind of like
engaging and entertaining these are kind of choices and once you start to make these choices you start to build
infrastructure around them and so it it to me it seems like it it creates the preconditions for some amount of
differentiation the other thing that I think might lead to differentiation is just the products built on top of it
right in the you can separate the model layer from the product layer in in practice they're somewhat linked to each
other and it can be somewhat challenging to work across organization so you know
while the models there's kind of this I don't want to say single path but like
there's like a there's like a logic to building models many of the companies are going in the same directions with the the multimodality they're adding
onto it making the model smarter making the inference faster there's kind of in
some ways one dire Direction but products are so different right if you look at this like artifacts thing we made which is a way to kind of visualize
in real time the code that the model writes right we do that open AI does their own thing Google does their own
thing I think that is also kind of the source of some differentiation between
companies and I think we've already found that the the economics of selling
apps on top of the model even if they're relatively thin apps and they're starting to become thicker and thicker
is quite different from the the the know the economics are just kind of like handing over the model via an API and
saying here you know we're opening the tap byy it if the scaling laws hold and things get as as big as we we think it
National security and Al
might it might get do you expect these companies to be nationalized at some point and could that prevent present
another another OTE or how do you expect yeah I mean that's that's not it's not it's not what people traditionally talk
about when they talk about OTE you know I think that that does get to these things about National Security I mean
again we you know we we bifurcate into the world where the scaling laws are right and and where you know the scaling
laws are are wrong and things taper off if if things taper off then you know this is just this is just a technology
like you know like the internet or like solar or anything else you know probably bigger than most but not but not you
know unprecedented based on where it has gotten so far and then I don't think it'll be you know nationalized and you
know I think a lot of these questions about who gets the value will be absolutely front and center if the scaling laws are correct and you know
we're building models that are like Nobel prize winning you know biologists you know topof the industry coders or or
better than you know I think both the the questions about national competition
and questions about misuse and the autonomy of the models will will you know will become front and center and
you know I think I've s said elsewhere that I'm not sure of literal nationalization but I think the government probably has a big role to
play right we could get to the point where these models are you know one of the most most valuable perhaps the most
valuable National Defense asset that you know the United States and our allies has we'll want to care a lot about them
being stolen by adversaries about whether adversaries can keep up about whether we can deploy them as fast as
adversaries can you know I I I just think of a you know model that can you know integrate all the intelligence
information across you know that that you know that the United States or or or or or or one of its allies receives or
you know coordinate all of our all of our you know military istics operations you know that sounds really that sounds
really quite powerful so did did you think that that Leopold put it pretty well in his discussion of of China
Leopold Aschenbrenner's essay
versus Us in terms of yeah I mean I think Leopold's Leopold's essay was was super interesting you know there's
there's a lot of it there's a lot of it that I agree with it's it's maybe a shade further towards kind of the
nationalization perspective and the National Security perspective than than than than than than I would necessarily
go but my my view is I would say not not particularly far from it you know I I I
I just definitely think when a when a technology becomes powerful enough this idea of like four or five companies that
are just kind of like autonomously operating it and do what doing whatever they want it just doesn't seem like it's
going to lead to a to a good outcome and you know I I say that as as the person in charge of one of the one of the
companies so you know there there are many models of government involvement in industry for national security reasons
you know there's there's like you know the SpaceX model of a public you know contract there are public private
Partnerships there are things that look like the National Labs there's literal nationalization somewhere in there
there's there's a model that makes sense at some point I don't know what it is yet I don't know when the right time to
do it is I suspect the right time is not like right now like not this year but but you know if the scaling laws are
right things can change really fast this is yeah that that that's fits very closely with what I was kind writing about internet companies for years about
how they'd eventually you know partner with the government I have a I have a question which is about I I have this
Al's impact on business models
big thesis so so you know the story of electricity how basically at first when they got electricity manufacturers tried
to rip out their steam dynamos you know add electrial generators and of course that was much more lossy so their power
was reduced because they kept the same form factor for the factories and they didn't and it was a loser a money loser
for them but then somebody figured out you could run electricity in parallel to a bunch of workstations and they changed the way that Manufacturing worked
instead of from one big assembly line to people taking things you know to different little workstations and doing their work there and that led to
enormous productivity gains over a sustained period of decades and so I've always had the suspicion that AI is
similar well I think the internet's similar actually but but I think AI is similar in that at first everyone seems
to kind of be thinking AI is a person you know you get people actually literally talking about numbers of of
AIS related to numbers of human employees which doesn't make any sense to me because like not it's not
divisible into individuals and and I mean you could make an agent based thing that does act like that but why anyway
but but I guess my I'm seeing everyone think about AI in terms of directly replacing human beings and my thesis is
that this is just the first pass this is kind of like electricity directly replacing steam boilers wasn't that
great of an idea and I think that I I I sort of have this forecast that people are going to be a little disappointed
when there's only a few cases in which that actually works like customer service you know some other well- defined things but but I think there'll
only be a few cases in which that direct replacement of humans actually works and then we'll have a Gartner hype cycle uh
you know sort of bust where people like okay well that doesn't work well AI is a big big fat bust who needs it and then
some you know creative entrepreneurs will say okay well actually instead of just using AI to act just like a human
replacement we could use it in some creative way and of course I can't tell you what that way is because then I could be a billionaire I don't know but
then you know people figure out creative ways to to use AI in ways that humans employ human employees were never used
direct you know that that take over some human tasks but that complement other human tasks and that create whole new
business models and that then we'll see this like you know resurgent boom that this is kind of my my forecast my my
Gartner style prediction am I crazy yeah so it's I think this is like this is
like a a mix of things that I agree with and and things that I might disagree with or maybe like this is true but some
other things are true as well which seem like have a lot of tension with it so so first of all I I think I basically
agree just just to I'm just thinking this through live I think I basically
agree that if you freeze the quality of the current models in place everything that you're saying is true and and we
basically observe we basically observe something you know quite similar in our
in our kind of you know in our commercial activities right so you know we both offer you know Claude A that you
can just talk to but but also you know we we sell the model via API to a whole bunch of folks
and people are definitely you know it's taking them a long time to figure out exactly what is the best way to use the
model right and you know you know C do we do we make it a chatbot questions
about reliability of the model abound which I think are are driving some of the concerns you're saying like let's
say I have a model 95% of the time you know let's say it's wants to offer
financial information or Anze a legal contract or something 95% of the time it
gives a correct answer maybe that's even more often than a human gives the correct answer but people don't really
know what to do with either either end users or the company itself the 5% where
it doesn't it doesn't give the correct answer it doesn't necessarily give the wrong answer in quite the same way a
human would how do you detect those cases how do you do the error handling how do you handle that in you know it's
very different for something to be useful in theory and useful in practice right like I mentioned before this
artifacts feature we have right early on when we had claw. it was like you know
you could have it write some code and then you you could paste the code into you know into this compiler or
interpreter and then it would like make your JavaScript video game or whatever and then some things would be wrong and you'd go back to the model and say blah
blah you know how can you correct this closing that Loop has you know has has just kind of made a big difference we've
also seen like the model like big models orchestrating small models so you know this is
something that's like very different from thinking of the model as a thing single person although I don't know maybe it's maybe there is a person
analogy to it right we have like bigger more powerful models and like faster cheaper less smart models and so a
pattern that we found with some customers is the the big large model you know has in mind some big task and then
it like Farms out a copy of like a hundred of the the small models and and
using that you know they'll go off and do the tasks and they'll like report back to the large model and so you have this kind of instead of a person you
have this kind of like swarm that's doing the task in a very kind of non non-human likee way right it's almost
like how a colony of bees would would would would perform the task so I think there's this is all to say like you know
I think there's we're still figuring out what the best way to use the models are and there's lots of different ways to use the models um but I I also think
that as the models get smarter they get better at powering through these problems so as they get smarter we're
going to be better at turning them into agents they're going to be better at doing tasks end to end the amount of the
human element the amount that humans are going to have to do is is going to decrease and so again it just all comes
back to like will these scaling laws continue if they do it's like it's like a series of processes like the one
you're describing if they freeze then the Innovation stops and the the the
research Innovation stops and the process you're describing plays out so basically think that that scaling brings
Noah's big thesis
back what I consider like the dumbass use case yeah yeah yeah yeah yeah
because like you know right right now you know I I the the dumbest thing that I could do with with jet gbt is be like
hey write me an article about blah blah blah in the style of previous Noah Smith articles and just comes out with a perfect thing it can't do that right now
it can't even come anywhere close to doing it but but the idea is if we scale then eventually we get to the point
where you know all I have to do is say hey write me a Noah Smith article in the style of this and then I get to take
over the world because I get to spam infinite highquality Noah Smith thought into the or you know or even higher than
than natural quality and so basically everyone will just be reading Noah all day long because I will be you know me
and my AI will dominate your your thought sphere I I already spend spend a reasonable amount of time reading your
articles I have to admit that if there were an infinite number of them would be quite powerful
cackle evil evil cackle anyway but yes so so I I I get the I get the idea here but that's basically interesting because
it means that as technological innovation eventually makes business
model Innovation less important because you can just you know button press everything you know just do everything
yeah yeah it's kind of like the the interface and business process Innovation is kind of a it's almost like
a it's almost like a substitute for the for the intelligence of the model the
more of one you have the less of the other you need and so it creates this interesting Dynamics right where you
have these kind of overlapping overlapping revolutions Each of which is a little faster to Market than than the
one before but maybe the music will stop at some point we don't we don't know for sure you know what I always say about
the scaling laws is like there's you know there's no one should believe that that there's some you know F fundamental
physical law that means they're going to continue it's an imperial iCal observation they could stop at any time
I've been watching them for 10 years and my belief that they my my guess that they won't is is just based on the
amount of time I've been watching them so far but you know that's not that's a that's a 6040 maybe 7030 proposition the
the trend is your friend till the bend at the end as they say i' I've never heard that phrase but that is that that would indeed be correct and and what
would change your perception there you what would change your odds there what would change my odds there so I think I
mean first of all if we just you know trained a model and and you know trying the next scale of model and it was just
really crappy and then we tried it a couple times to you know to try to unblock it and we still didn't I'd be
like oh I I guess the trend is stopping if there were problems with running out of data and you know we couldn't generate enough synthetic data to really
kind of you know continue the process then then you know then then at some point I'd say hey this this actually looks like it's hard you know at the
very least the trend is going to pause you know may or may not stop but but you know that's what it might happen it's
it's still my guess that those things won't happen but you know this this is a profoundly non-trivial question we'll
Sponsors: Babbel | Brave
continue our interview in a moment after a word from our sponsor fast forward to the end of 2024 think about your goals
what can you do right now to give yourself the best chance of succeeding if learning a new languag is on your list you absolutely need to check out
Babel Babel offers a range of learning tools self-study app lessons live classes and even podcasts which have
always been my favorite way to learn studies from Yale Michigan State University and others continue to prove
Babel is better one study found that using Babel for 15 hours is equivalent to a full semester at College Babble
isn't just a game to kill time and make you feel like you're learning a language it's not overly academic or rigid either
it's all about learning language for the real world Babble stands out because it's designed by real people using a
modern conversational teaching approach it's not always easy nothing worth doing ever is but it's straightforward and
designed to help you start speaking in just 3 weeks with Babel I was able to brush up on my intermediate Spanish to
ramp up for travel to Argentina last year and was able to set clear goals based on how much time each week I wanted to practice joined millions of
Babel language Learners across all age groups here's a special limited time offer for our listeners right now get up
to 60% off your Babble subscription but only at babel.com torenberg that's babel.com torenberg
spelled b a BB l.com torenberg rules and restrictions May apply
the tech World Turns to the brave browser for its unbeatable privacy protections but did you know that brave also has a private ad platform Brave ads
offers first-party targeting and it's been Cookie list since day one so you can relax while third party tracking cookies disappear from the web today
millions of people turn to ad blockers to avoid being tracked and pestered online for Brave's new ad model aligns
incentives for users and advertisers users earn rewards for viewing ads which they can save spend or pass along to
their favorite creators and advertisers score points for respecting user privacy generating Roi
without invasive tracking so whether it's high impact announcements on the new tab page or keyword targeted ads in
Brave search Brave search offers diverse private futureproof ad formats for all your business goals join the future of
advertising at brave.com ads mention turpentine to get 25% off
your first [Music] campaign all right Eric I think you're
Al arms races?
up ask a big question D how much do you worry about arms races how much of a contributor are they to your overall AI
risk picture and do you worry more about us versus China or competition between firms yeah so I don't know I mean I you
know there's there's kind of no rule that says we have to be in a situation that has like a single right answer or a
good answer so there's there's different things I'm concerned about right you know I'm I'm concerned about you know
what's come to be called Safety although that's a you know that's kind of like a weird term I divide it into kind of you
know the autonomous behavior of AI systems which I think is not a big issue now but as soon as we make agents and
systems become autonomous and they're also smarter then I'll you know I'll be more worried about it and and that might
happen fast in line with the scaling laws and and also kind of misuse of the models and so that you maybe you know
distributed misuse proliferation and so that that points towards hey we have to be careful in how we do this we you know
we have to make sure that we you know know have the right checkpoints measure for the right risks don't go too fast
and you know that's something that's important to us I can talk about our like you know responsible scaling plan which is how we continue to scale the
models while attending to these risks and then on the other side of it there's something which you know I think Noah
has written a lot about which is the you know the renewed competition between the US and China like you know I read your
article on Cold War II you know as as a descriptive picture of what's Happening
you know I think it's it's really correct whether we want it to happen or not I don't know and it it may be it may
be irrelevant it seems to me that it's it seems to me that it's happening and if we take seriously this hypothesis
about how powerful the AI models are going to be um you know they're they're
really power powerful enough to shift perhaps single-handedly shift you know the balance of power on the
international stage and then we have to ask questions about you know after after models of this scale are built is it
democracies or autocracies that are that are going to be you know that that are going to you know win win on the world
stage and you know I think we shouldn't just worry about the safety risks of AI although I'm very very worried about
those um you know we should also worry about you know assuming assuming we get it assuming we get it all right that we
don't have to worry about you know about kind of AIS themselves or or about terrorists or kind of small
proliferative actors misusing AI then then you know we we need to make sure I think it's very important that you know
that that certain certain values survive or even or even Triumph like I think an AGI enabled autocracy sounds like a
really really terrifying thing if you if you think it through and it's something we don't want it's something we really
don't want and so we we we need to do both there's often tension between the two I think there are a number of
policies that that kind of help with both and then some that where there's a tension between the two one of the
policies I really like is what the US has done with chips and semiconductor
equipment I think think holding back the the autocracies has has been has been an
effective strategy because it does two things one it gives us an advantage but it gives us more time to attend to the
risks it it basically gives us some breathing room right where there there's otherwise a hard trade-off between these
things it it gives us some breathing room I have a feeling while you know in
addition to companies competing with each other or sorry in addition to countries competing with each other companies compete with each others
companies if the situation gets dire enough can be can be brought under uh
you know a common legal framework right we can argue about what regulation is appropriate if if evidence really
started to to emerge where I think there you know there is some now and there may be much much more in the future that
that these things are are dangerous either in the misuse or autonomy Direction the coordination problem can
be solved right that's what government is for that's what regulation could be for but the international coordination problem is extremely difficult to solve
but you know we live basically you know the international world is this this Hobs and Anarchy you know hopefully we
could sign disarmament treaties you know we should definitely try for cooperation um but there's there's no mechanism to
enforce it and so you know I would I would favor trying even even while believing that you know maybe maybe our
odds of success are not are not that great all right so I'd like to I'd like to shift gears a little bit to talk about you know the impact on on labor
Al's impact on labor and skill distribution
which is obviously another thing Everyone likes to talk about with regards to AI Eric Ben yelson has this
this thesis and I I pretty much you know kind of agree that generative AI at
least so far compresses skill differentials so that when we see that with you know get up co-pilot or you
know call centers or college essay writing or any of these other standard tasks you know the the first past tasks to which AI has been applied we see that
the people who are bad at it do much better and the people who are good at it do a little a bit better and then the
people who are great at it don't do better and so what you end up getting is the the the the the skill of the top
people becomes less valuable because the bottom people can compete more with with
the top people and to me that was a that that was a hopeful finding you know because it meant that the age where
where only a little bit like you know when Factory workers were able to compete
with Artisans back in the days of garment manufacturing you know the early Industrial Revolution I said okay well it's a machine tool for the mind you
know it's like now you can just have some some schlub from a village in like North England make cloth that's as good
as the the best Artisan or at least 90% is good for 10% of the price right and so then you at that point you yeah you
compress the the skill return distribution and then maybe that could fight inequality do you have any thoughts on
this thesis yeah so I think in terms of again I always separate things out into you know kind of eras you know I think
in terms of what we're seeing now my my my perspective absolutely matches that
you know it's just interesting to see for example as the coding models get better that you know you know some some
of the most skilled programmers that I've worked with in many previous models
said you know this this just doesn't help me very much like this isn't very this isn't very useful to me now finally
occasionally say with you know Claude 3.5 Sonet future models probably will also be true of other models that come
from other other companies they're starting to occasionally find more more use of more use of the models but I I
definitely think it's the case if you look at something like like like like GitHub co-pilot it's been a leveler and
I also agree that it's a good thing in that you know if we if we look at you know kind of the era of the Internet
it's it's had I mean you guys would know more than I would but it has this it's had this kind of aggregating effect
where it's like everything becomes Global News music writers and and you
know then there be become these very large returns to like Superstars and that that kind of drives growth but it
also drives a lot of inequality and so you know I think I think it would be it would you know I think it's it's it's a
good effect if there's this leveling unfortunately again as as the scaling laws continue that may only be one era
there may be another era where the AI models start to do what what kind of everyone can do actually then they may
be sort of a you know they may be sort of a leveler as well and actually I actually agree with something I think
you said recently Noah which is that comparative advantage is still going to be really important so I think even if
we had our you know our like Co you know all if if AIS were much better than
humans at coding you know or even you know better than humans at at at biology
it's just surprising even if even if some small fraction of the task continues to be done by humans like it's
just remarkable how adaptable humans and the econ are kind of reorienting
themselves around the part of the task that humans can still do right like even if 90% of the code is written by AI
humans will get really good at the other 10% and then even if 100% write it well you're still specking out the design
you're still connecting it to everything else you're still writing the product you're still there's there's just
there's surprisingly many things and so I think comparative advantage is going to endure longer than people think e
even in these crazy scaling worlds I don't think it'll endure forever again if it if it goes on if it goes on long
enough and if some complimentary things are built there's there's no reason you know that it can that it can endure or
be a significant factor forever but I think it'll go on a lot longer than people think we'll continue our
Sponsor: Squad
interview in a moment after a word from our sponsor hey everyone Eric here in this environment Founders need to become
profitable faster and do more with smaller teams especially when it comes to engineering that's why Sean Lenahan
started Squad a specialized Global Talent firm for top Engineers that will seamlessly integrate with your
org Squad offers rigorously vetted top 1% talent that will actually work hard for you every day their Engineers work
in your time zone follow your processes and use your tools squad has frontend Engineers excelling in typescript and
react and nextjs ready to onboard to your team today for backend Squad Engineers are experts at node.js python
Java and a range of other languages and Frameworks while it may cost more than the free on upwork billing you for 40
hours but working only two Squad offers premium quality at a fraction of the typical cost without the headache of
assessing for skills and culture fit Squad takes care of sourcing legal compliance and local HR for Global
Talent increase your velocity without amping up burn visit chw squad.com and
mention turpentine to skip the wait list also you know one thing I probably
could have been clear about in my post about comparative advantage that I wrote it got a lot of attention but I think
one thing I could have made clearer was that in a world where the the the sort of Upstream constraints on AI are the
same as the Upstream constraints on humans then we're in trouble comparative advantage or no we're we're kind of in
trouble because both are fighting for energy you know simple explanation if data centers take away energy from
growing food and food gets more expensive then people get mad and that's bad for humans but in the world where
the constraint where the Upstream constraints are different so I most people think about the capabilities the
downstream you know complimentarity and substitutability but I was talking about the the the the complimentarity and
substitutability of production factors so for example if AI if most of the energ if if most of the effort in making
AI if the biggest bottleneck is not energy but ability to manufacture sufficient compute then I think we're
okay uh because then a it's it's basically like and my example was there's one of Mark andreon and then
there's one of Mark Andre's executive assistant there's only one of each there's a different idiosyncratic constraint on those two you know the
fact the two factors of production if you will and so similarly I think that
comparative advantage is likely to to be better for us if the bottleneck in AI
resource-wise is more about compute than about energy and I should have been a little more explicit about that but but
do you basically agree with that like what do you what do you think about that yeah I I think that makes sense I I I you're sort of saying like if if the you
know just to use a somewhat ridiculous analogy if the AIS are syons and the the
process of making growing them is very similar to that of humans then we're then we're in trouble but if it you know
if it's a server Farm somewhere where the inputs are totally different then then we're you know then we're then
we're fine I I think I I haven't thought deeply about that I that sounds pretty plausible that sounds pretty plausible
to me at least at first blush again you know if we're in a world where like AI
is like reshaping the world and the whole way that the economy is designed you know that's kind of like you know at
the at the end of the scaling curve then then you know we could be talking about
something different but but like no you know if the normal rules of Economics you know kind of kind of apply you know
I think they will for a while then then this I mean this sounds very sensible dang also you know as for the sort of
hyperscaling world now now by the way that the stuff that we're talking about I I can show you paper where basically
it shows all these models and you know our intuition basically pretty closely matches what you get when you write down a simple model of stuff and yes there is
the world in which scaling capabilities world does exist in these models and it kind of works kind of like you think but
my my other question is does it make sense to think about a world of incredible abundance where AI is so good
Future of Al and a hyperscaling world
that it gives us amazing biology and amazing manufacturing and amazing every single thing that we could want just
gets 10x better 100x better you know whatever and yet human beings themselves
are impoverished what are the cases in which we we have to worry about a world of radical abundance in which humans are
utterly impoverished yeah let me maybe take the two parts of those one by one because the the world of radical
abundance I mean that's what that's what we're hoping for right I I talk a lot about the risks again both the autonomy
and the kind of misuse in National Security and sometimes people get from that get the impression that it's like
oh I'm like a Doomer I think all these bad things are going to happen no my perspective is more that like you know
by default I think really great things are going to happen and I'm obsessed with the bad things because they're the only standing between us and all these
great things happening right the only thing that can that the only thing that can derail it so I'm like I'm just totally obsessed with like you know
finding the blockers and like destroying them so first of all yeah the world of radical abundance like I think a lot
about biology because I used to be a biologist and and I think I think we're really underestimating what is possible
when people look at Ai and biology you know certainly 10 years ago when I was in the field the attitude was you know
look the data we get from bi ology is is is you know of questionable quality there's only so much of it we can get
you know the the the experiments are often confounded sure it's great to have more data analysis and big data and AI
but it plays at most a supportive role that's maybe changed a little with Alpha fold but but my picture of course and I
don't know maybe this this this this goes a little bit in in in you know what you think of as replacement Pitfall but
is is the AI models kind of serving the the role of a biologist or a co-
biologist if we think about what's really Advanced biology like it's really
disproportionately a few technologies that kind of power everything right so like genome sequencing right just the
ability to like read The genome fundamental to like you know most of Modern Biology right more recently
crisper the ability to edit the genome right fundamental to many experiments where we want to intervene in in animal
experiments starting to become important to you know Pharmaceuticals and and you
know and and curing diseases although there's a while to go and you know it needs to be more reliable there are a
lot of other techniques that are needed I think if we get AI right it could like increase by 10x maybe 100x
the rate at which we invent these discoveries so if you look at crisper you know it was it was it's basically
you know the the assemblage involved comes from the bacterial immune system
and you know this was known for like 30 years years but you know connecting it to the idea that you could use Gene
editing how you could do it that you needed to add these other elements to it it you know there was no reason you
couldn't have done it 30 years ago it took 30 years to invent it and so I I think if we can you know greatly
increase the rate at which these discoveries happen we'll also greatly increase the rate at which we cure disease and you know the way the way I
think about it is you know could could we have like a kind of a compressed 21st century right could we make all the
progress in biology ology that we were going to make in the 21st century using you know AI by you know kind of speeding
things up 10x and if you think of all the progress we made in biology in the 20th century and then you know kind of
compress that into into five or 10 years to me to me that's the upside like I think I think that might literally be
possible and you know diseases that have been with us for Millennia we could we could cure you know and and you know of
course that would do great things to productivity would increase the size of the pie extend the human lifespan so all
that great that's that's what that's what I'm hoping for that's what hopefully we're all hoping for humans ending up impoverished I mean I you know
I guess the you know I guess the easiest bad story would be okay well all this huge
wealth is created right you know we get we get like you know double digit GDP
growth in the developed world and you know but but it doesn't it you know the
returns disproportionately go to you know the companies that are developing it the employees of the
companies complimentary assets that need to be produced and then you know the the
the the average person somehow ends up in a situation where they don't share in it and maybe even more those in the
developing World which I think is actually a more plausible worry kind of end up getting left out of it you know
the extent to which when you when you think about people being left out of a growing economy I think that's happened
a you know a lot more between countries than it has happened within in countries although it's also happened within countries so I I guess that would be the
easiest way to do it within countries also you know countries have a history of redistributing but we haven't been as
good at you know say redistributing to subsaharan Africa as we have within within the United States because there's
there's no governmental entity that has the jurisdiction to do that that's an aspect of the problem I think people
don't really think about a lot is is effect on other countries like but possibly that you know that would take
us too far a field Eric do you have do you have more I have one question and it's it's basically on the two sides of
Al safety and inequality
of the risk coin so some people say that because we aren't able to really
understand how the human brain works to bring it back to the beginning of our conversation that we shouldn't be worried about AI sort of developing
Consciousness or agency because we can't even understand our own programming how how can we you know program or
understand AI That's that's on one side of the safety concern and and then on the flip side of that sort of the AI
powered surveillance States I'm curious if we could speculate more on the risks there it seems to be
the the opposite risk profile around like maybe a question asked that is like what how do we think AI might develop in
China or Russia or or Iran yeah okay so I think I think on the safety side I
mean it's it's several you know like again several different things one you know I think the fact that we don't
understand how you know human brains work I I don't think that alone should give us that much comfort about about AI
systems right there are some like pretty bad humans out there right you know like you know if I look at a if I look at a
two-year-old child and you know I'm like you know is this is this going to be you know the next Gandhi or the next Hitler
or something in between we don't we don't really have any you know way to predict that right I mean you know maybe
make some guesses but it it just it's just it's just really hard so you kind of don't know what you're what you're
getting and and you know I think that's that's true of AI systems as well on the other hand it doesn't mean you know it
should tell us that it's like it doesn't mean it doesn't imply that the systems are like necessarily impossible to
control right like you know we have ways of educating humans we have ways of creating a balance of power between them
so it's it's not an entirely reassuring message but it's not an entirely frightening message either right if
anything it suggests that you know some some of the old problems that you know we've had with just just humans humans
being being being aligned you know two sides of the two sides of the coin we may have the same situation with with AI
that said if we can understand what's going on inside I think that improves the situation quite a lot and we've had
a team at anthropic that since the beginning has worked on you know interpretability looking inside the
model to try and understand why it does what it does that's something that I know from experience is hard to do from
the human brain it's much easier to do in software there's still the the algorithmic the computational complexity
of it but we can face that complexity without without you know worrying about how to how to reach into the go of a
brain without without you know without killing the organism involved so we should do as much of that as we can and
the ideal is if we do that really well the situation might be better than it is with human alignment and our ability to
predict humans you know on the other hand it's like we know a lot about humans we know a lot less about AI so
like if I were to make the the the the bare case it would be and we already see this when we deploy AI systems they're
alien they make mistakes that sometimes are hard to understand they they get things right that no human would get
right but sometimes they make mistakes that no humans would make and I think that's that's a reason to to worry from a safety perspective so I don't know
that's that I I think I and anthropic often have these kind of balanced perspectives on things and that's that's
you know that's our our view on safety on what's going to happen in Russia and China I mean I would go back to the you
know like the export controls right we have no available hard governance mechanism for controlling what happens
there you know as far as we have all these debates on safety issues here I'm happy to see that you know there are
some people in in China who think about the same the same issues um but you know
we have we have we have no mechanism for making sure that they do it right there's no mechanism for Democratic for
Democratic accountability you know authoritarian governments have a history of being more Reckless than democratic
government so I think I think it's generally bad I think it's generally bad news when they're ahead for for a number
of reasons and from a number of different perspectives and so if you know to some extent we Face a tension
between speed up to beat them and think about safety but there are some things we can do that that that kind of are are
good from both from both perspectives and I think we should try to find more of those things and do them there well
we have you for for two more minutes SB 1047 any any Elon just endorsed it and
The SB 1047 debate
any quick thought some people are concerned that it could create a path dependency and how we think about
regulation what are your quick quick thoughts on it yeah so I you know anthropic wrote two letters on this
first was to the original Bill where we had some concerns that it was a bit too heavy-handed you know the the bill
sponsors actually addressed many though not all of those concerns you know maybe maybe 60% of them or so and and after
the changes we we became substantially more more positive you know I think we
we couched we couched our view in terms of analysis we have a lot of experience you know running safety processes and
testing models for safety and so we felt we could be a more useful actor in the
ecosystem by kind of providing information by informing then kind of you know picking a side and like you
know trying to beat up the other side or you know whatever political coalitions do but but you know I think we were I
think after the changes more positive than negative on the bill and you know I think I think I think overall in its
current form to our you know tie kind of to our to our best ability to determine we like it our concern with the original
version of the bill was with something called prearm enforcement so the the way the bill works it's very similar to kind
of rsps the responsible scale plans which are this voluntary mechanism that
we and open Ai and Google and others have developed which says you know you have to run these every time you make a
new more powerful model you have to run these tests tests for autonomous misbehavior tests for you know misuse
for biological weapons for cyber attacks for nuclear information and and and so
if you were to turn that into a law there's two ways you could do it one is you have a government department and the government department is like you know
these are the tests you have to run these are the safeguards you have to do if the models are smart enough to pass
the tests and you know there's kind of an administrative state that writes all of this and our concern there was hey a
lot of these tests are very new and almost all these catastrophes haven't happened yet so I think you know
somewhat in line with those who were concerned we said hey this could really go wrong like you know could these tests
end up being dumb could they you know in a more Sinister way kind of you know be be be kind of repurposed for political
the other way to do it which you thought was more elegant and might be a better way to start for this kind of rapidly
developing field where we think there are going to be these risks soon they're coming at us fast but they haven't
happened yet is what we call DET turrets which says Hey everyone's got to write
out their plan their Safety and Security plan everyone decides for themselves how they run their tests but if something
bad happens and that's you know not just AI taking over the world but you know just could be an ordinary Cyber attack
something bad happens then a court goes and they looks at your plan and they say well was you know was this a good plan
was it person reasonably believe that you know you took all the measures that you could have taken to prevent the
catastrophe and then the hope is that there's this kind of upward race where companies compete not to be the slowest
zebra right to prevent catastrophes and not to be held not to be the ones to be held liable for the catastrophes that
happened so opinions differ you know many many people obviously are are still against the new bill and you know I can
I can understand where they're coming from it's a new technology it hasn't been you know we haven't seen these catastrophes it hasn't been regulated
before but but we felt that it kind of struck the right balance you know time will tell if it passes or even if it
doesn't pass probably it's not the last we'll see of regulatory ideas like this and you know that was there was another
reason why we thought you know we could we could best contribute to the conversation by by saying hey here here
are the good things about it here are the bad things about it we do think that as amended the good things outweigh the
bad the bad things this is an ongoing conversation and this kind of Bill wouldn't make you move operations out of California yeah that that was the that
was the thing that was most perplexing to me there were some companies talking about moving operations out of
California in in fact the bill applies to doing business in California or deploying models in California moving
your corporate headquarters for better or worse change your status Visa the bill so you know honestly I'm surprised
the opponents you know didn't didn't say oh this is scary because it applies you know because it because it applies
anywhere and you know that was that was a reason why we really wanted to make sure that outweigh the costs which we which we do feel um but anything about
you know oh we're moving our headquarters out of California this is going to make us that's just theater that's just negotiating leverage like it
it it has Bears no relationship to what to to the actual content of the bill got it actually can I ask one more question
do we have time for me to ask one more quick question yeah I I'm happy to I'm happy to keep talking you know at some
point Sasha's gonna gonna gonna interrupt me and tell me to stop but I'm just I'm happy to keep talking until she does
Rabbit alignment problem
well I have I have one more question which is in terms of alignment you know most people think about how do we make
an AI based World in which humans do well and which things are good for humans I think a lot about how do we
make a AI based World in which things are good for rabbits um because I really like bunnies
and they've got kind of a raw deal from the universe but you know like a rabbit in in the wild will live only uh 1.5
years on average but then a rabbit in you know captivity will live comfortably for 10 to sen years and so how how do we
other than making rabbits the official sort of animal of anthropic which is a thing I definitely think should be done
kipley will work with me on this other than that how can we create a world where things are are good for bunnies in
a world of super AI yes so I I don't know I thought about some similar things so so I have a I I have a horse and the
way I would describe horses is that they're they're kind of like they're kind of like gigantic rabbits in their
in their behavior and just in their you know they're like prey animals but like you you really you really want to
protect them like they they really create this protective Instinct in you and and you know you want to make sure
that like they have a good life I don't know I guess the way I would think about it is is if we thought about the AI
correctly like hopefully you know we we've created some general principle of you know you should be kind to like less
powerful beings and so it means that you know humans should be kind to rabbits and horses and AI should be kind to
humans and hopefully also the AI would be would be themselves kind to rabbits and horses as a as as as a
generalization of that right that we would have some some some the AI you know the the the you know combined AI
human you know ideology or or or picture of the world would would be based on
some kind of some kind of you know protection of these these creatures I I kind of suspect that to to to you know
if we ever built benevolent powerful AIS they might look at us a little as as we look at the rabbits and horses that
we're a little we're a little we're a little helpless and and you know kind of queued and need to be protected all
right well I I I definitely think more attention needs to be paid to the rabbit alignment problem actually that that was
that was one of the the only science fiction short stories I ever wrote was about you know a future where AI just decided it had to protect bunnies and
other small fluffy animals and would occasionally like blast any humans who had thought might potentially threaten
them yeah no no no you're too close to the rabbit like this is your last warning space laser is coming for you
that happened that did happen well it was great to see you again yeah really
Wrap
great to see you again I've really enjoyed your your essays particularly on you know just just kind of like the
international and National Security situation I I basically have have the same view and in fact you know think
that these issues are even more important because if I'm right about the scaling laws there there's this you know
there's there's this enormous technologically disruptive Revolution that's happening at the same time you
know it feels a little bit like you know the bomb being built during World War II or I mean maybe that's an overly
dramatic analogy but it you know I think it creates it highlights those issues even more and and create some tensions
that we have to that we have to navigate so I'm I'm I'm very I'm very concerned about it and and your analysis has been
helpful to me in in thinking the issues through I appreciate that so
much hey everyone Eric here at turpentine we're building the First Media outlet for tech people by tech
people we the network behind the show you're listening to right now we have a slate of hit shows across a range of
topics in industries from our Ai and investing cluster of podcasts to shows that drive the conversation in Tech with
the most interesting thinkers Founders investors and influencers like econ 102
with Noah Smith we're launching new shows every week and we're looking for industry-leading sponsors if you think
that might be you and your company email me at Eric turpentine doco that's e r i