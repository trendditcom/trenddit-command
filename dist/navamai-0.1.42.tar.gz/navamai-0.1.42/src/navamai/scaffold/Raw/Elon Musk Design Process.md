Beginning
Manufacturing vs. Design
manufacturing is underrated and design
is overrated at the design like this
literally a thousand percent maybe ten
thousand percent more work that goes
into the production system than the the
thing itself so say like how much effort
have we put into say designing raptor
versus designing the manufacturing
system it's 10 to 100 times more effort
to design the manufacturing system than
the engine basically the amount of
effort that goes into the design rounds
down to zero they think the design is
the hard part and not and they think
production is like a copier or something
like that right so it's completely false
all designs are wrong just a matter of
5 Step Process
how wrong what i'm trying to
have a solo just implement rigorously is
the sort of five-step process first make
1. Less dumb requirements
your requirements less done your
requirements are definitely done
uh does not matter who gave them to you
it's particularly dangerous if a smart
person gave you the requirements because
you might not question them enough
everyone's wrong no matter who you are
everyone's wrong some of the time
whatever requirement or constraint you
have it must come with a name not a
department because you can't ask their
apartment you have to ask a person yeah
and that person who's putting forward
the requirement of constraint
must agree that they must take
responsibility for that requirement
otherwise you could have a requirement
that basically an intern two years ago
randomly came up with off the cuff uh
and they're not even at the company
anymore right uh and and and but it came
from the let's say
aero loads department they're like
actually
there's no one in the air flows
department actually it currently agrees
with that this is not this by the way
happens several times then uh try very
2. Delete part or process
hard to delete the part or process this
is actually very important if you're not
occasionally
adding things back in you're not just
leading enough right the bias tends to
be very strongly towards
let's add this part or process step in
case we need it but you can you can
basically make in case arguments for so
many things and for a rocket that is
trying to be the first fully reusable
rocket there's never been a fully useful
rocket people don't understand like this
is like the holy grail of rocketry okay
you really need you have to run at tight
margins because if you don't run tight
margins uh you're going to get nothing
to orbit and you can't like hedge your
vets that's why the quick fins for
example do not hold both down because
that's a whole extra mechanism that we
don't need and if you have a whole
mechanism for folding them that's like
clearly a part that we don't need
so this was a good design decision that
actually i didn't come up with and it
was like great but it followed the
principle of like delete the part leave
the process and i was like great good
idea let's not fold them why are we
folding them anyway and then
3. Simplify or optimize
only the third step is simplify or
optimize the third step
not the first step the reason is the
third step is because it's very common
possibly the most common error of a
smart engineer is to optimize the thing
that should not exist and then finally
4. Accelerate cycle time
you get to step four which is accelerate
cycle time
if you're moving too slowly go faster
but don't go faster until you have
worked on the other three things first
like if you take if you're doing
it you know you're great don't dig it
faster stop digging your grave and then
5. Automate
the final step is automate now i have
Common Mistakes
personally made the mistake of going
backwards on all five steps multiple
times on model three where literally i
automated
accelerated
simplified and then deleted like one one
example i've talked about before is like
the there were these like fiberglass
mats on top of the model three battery
pack they were in between the full pan
and the battery and it was one point
choking the battery pack production line
and i was like basically living on the
battery factory production line like
trying to fix the line because it was
like it was it was like choking the
entire military production program so
the first mistake was we should not have
i i like try to
fix the automation like make the robot
better make it make it like robot move
faster a shorter path increase the
torque delete the reverse 720 degrees on
the the bolt uh because that's
unnecessary just goes forward go forward
fast not a 20 rate at 100 rate instead
of spackling glue on the entire battery
pack just put little dabs of glue
because the fiberglass mats are
sandwiched between the
the battery pack and the floor pan
anyway so all you need is like something
to hold it in place until you bolt the
battery pack into the car so automating
was a mistake then accelerating was a
mistake then optimizing was a mistake
and finally i said what the hell are
these mats for and i asked the battery
safety team what were these maps well
they said oh these masks i said are they
for fire protection or something they
said no they're for noise and vibration
so you don't get that and i said but
you're the battery department then i
asked the uh nba noise vibration horses
uh team what's it for they said fire
safety
so literally it was like being in a
dilbert cartoon okay finally okay great
let's let's uh try a car with the
fiberglass mats and without
and they
put a microphone in both
and it seems to tell the difference you
cannot can i tell in fact i was like
which one is which so we just deleted
them and just bypassed this two million
dollar robot robot cell it was just a
complete pile of nonsense another
mistake that tends to happen in
production is too much in-process
testing if things are getting to end of
line testing and or passing uh then you
don't need to do in-process testing
really in volume production if you have
if things are working well you're really
just taking a risk will this part be
rejected
in the during the production process or
at the end um and so you just really
want to move things pretty much almost
always to just test at the end line
that's it yeah and if you look like the
the various reasons like where we blew
up starships and you looked at the risk
list no no none of the reasons that blew
up were on the risk list really yeah
there was like no
maybe you could argue like one of them
maybe was on somebody's risk list but it
wasn't brought up beforehand because
Everyone is Chief Engineer
it's another important principle which
is that you really want uh everyone to
be chief engineer so everyone as chief
engineer means that people need to
understand the the system at a high
level to know when they are making a bad
optimization i don't know about you but
Remo's comments
i think these principles are pretty
mind-blowing and should be applied as a
new standard in startups and technology
companies personally i like the second
step the most delete things that should
not exist how much simpler would the
world be if we all applied this which
one do you like the most let me know in
the comments below and of course a huge
shout out to the everyday astronaut
whose interview with elon musk served as
a basis for this summary i highly
recommend to watch the full interviews
and i have put links to the interviews
in the description below if you want to
see more videos like this don't forget
to like and subscribe it helps me out a
lot have a great day and see you in the
next video
