
Introduction
- So I was trying to figure out how to do photorealistic AI photos and it was... Stable Diffusion by itself is not doing that well.
The faces look all mangled- - Yeah. - And it doesn't have enough resolution or something to do that well.
But I started seeing these base models, these fine tune models, and people would train them on porn, and I would try them,
and they would be very photorealistic. They would have bodies that actually made sense, like body anatomy.
But if you look at the photo realistic models that people use now, still, there's still core of porn there,
of naked people- - Yeah. - So I need to prompt out the naked, and everyone needs to do this with AI startups with imaging. You need to prompt out the naked stuff.
- You have to keep reminding the model you need to put clothes on the thing. - Yeah, don't put naked 'cause it's very risky. I have Google Vision- - Yeah.
- That checks every photo before it's shown to the user to like check for NSWF. - Like nipples detector? Oh, NSFW detector. (chuckles)
- Because the journalist gets very angry. - The following is a conversation
with Pieter Levels, also known on X as levelsio.
He is a self-taught developer and entrepreneur who designed programs shipped and ran over 40 startups,
many of which are hugely successful. In most cases, he did it all by himself
while living the digital nomad life in over 40 countries, in over 150 cities,
Programming on a laptop while chilling on a couch, using Vanilla HTML, jQuery, PHP, and SQLite
He builds and ships quickly and improves on the fly, all in the open, documenting his work,
both his successes and failures with a raw honesty of a true indie hacker.
Pieter is an inspiration to a huge number of developers and entrepreneurs who love creating cool things in the world
that are hopefully useful for people. This was an honor and a pleasure for me.
This is the "Lex Fridman Podcast." To support it, please check out our sponsors in the description.
And now, dear friends, here's Pieter Levels. You've launched a lot of companies
Startup philosophy
and built a lot of products. As you say, most failed, but some succeeded. What's your philosophy
behind building the startups that you did? - I think my philosophy is very different than most people in startups.
'Cause most people in startups, they build a company and they raise money, right? And they hire people, and then they build a product,
and they find something that makes money. I don't really raise money. I don't use VC funding. I do everything myself.
I'm a designer. I'm the developer. I make everything, I make the logo. So for me, I'm much more scrappy.
And because I don't have funding, I need to go fast. I need to make things fast to see if an idea works, right?
I have an idea in my mind and I build it, build like a micro, mini startup. And I launch it very quickly,
like within two weeks or something of building it, and I check if there's demand. And if people actually sign up,
and not just sign up, but if people actually pay money, right? They need to take out their credit cards, pay me money,
and then I can see if the idea is validated. And most ideas don't work, like as you say,
most fail. - So there's this rapid iterative phase where you just build a prototype that works, launch it.
- Yeah. - See if people like it, improving it really, really quickly to see if people like it a little bit more enough to pay, and all that.
That whole rapid process is how you think of. - Yeah, I think it's very rapid,
and it's like if I compare to, for example, Google, like big tech companies. Especially Google right now is kind of struggling.
They made transformers. They invented all the AI stuff years ago, and they never really shipped.
They could have shipped ChatGPT, for example, I think I heard in 2019, and they never shipped it because they were so stuck in bureaucracy.
But they had everything, they had the data, they had the tech, they had the engineers, and they didn't do it.
And it's because these big organizations, it can make you very slow. So being alone by myself on my laptop,
in my underwear in a hotel room or something, I can ship very fast, and I don't need to ask legal for like,
"Oh, can you vouch for this?" I can just go and ship. - Do you always code in your underwear? Your profile picture, you're slouching-
- Yeah. - On a couch in your underwear, chilling on a laptop. - No, but I do wear shorts a lot, and I usually just wear shorts and no T-shirt
'cause I'm always too hot. I'm always overheating. - Thank you for showing up not just in your underwear but-
- Yeah. - Wearing shorts. - And I'm still wearing this for you, but- - Thank you. Thank you for dressing up. (Pieter chuckles)
- Since I go to the gym, I'm always too hot. - What's your favorite exercise in the gym? - Man, overhead press. - Overhead press like shoulder press?
- Yeah. - Okay. - But it feels good 'cause you win, 'cause when you- (Lex laughs)
I do 60 kilos. - Yeah. - So it's like 120 pounds or something. It's my only thing I can do well in the gym. And you stand like this and you're like, "I did it,"
like a winner pose. - It's victory thing. Yeah. - The victory pose. I do bench press, squat, deadlifts. (Lex and Pieter laughs)
- Hence the mug. - Yes. - Talking to my therapist. - Yeah. - It's a deadlift. - Yeah. Because it acts like therapy for me.
- [Lex] Yeah, yeah, it is. - Which is controversial to say. If I say this on Twitter, people get angry, - Physical hardship is a kind of therapy.
- Yeah. - I just rewatched "Happy People" A Year In The Taiga,"
that Werner Herzog film, where they document people that are doing trapping.
They're essentially just working for survival in the wilderness year round. - Yeah. - And there's a deep happiness to their way of life-
- Yeah. - Because they're so busy in it, in nature. - Yeah, 100%.
- There's something about that physical- - Physical, yeah. - Toil. - Yeah, my dad taught me that. My dad always did construction in the house.
He's always renovating the house. He breaks through one room and then he goes to the next room, and he is just going in a circle around the house
for the last 40 years. So he is always doing construction in the house and it's his hobby.
He taught me, when I'm depressed or something, he says, "Get a big," what do you call it?
Like a big mountain of sand or something from construction, and just get a shovel and bring it to the other side
and just do physical labor, do hard work, and do something.
Set a goal, do something. And I kind of did that with startups too. - Yeah, construction is not about the destination, man.
It's about the journey. - Yeah. (chuckles) - Sometimes I wonder people who are always remodeling their house. Is it really about the remodeling or-
- [Pieter] No, no, its not. - Is it about the project? - It's the journey. - The puzzle of it. - No, he doesn't care about the results. Well, he shows me, he's like, "It's amazing."
I'm like, "Yeah, it's amazing." But then he wants to go to the next room. But I think it's very metaphorical for work,
'cause I also, I never stop work. I go to the next website, or I make a new one, right? or I make a new startup.
So I'm always like... To give you something to wake up in the morning, and like, have coffee and then
kiss your girlfriend, and then you have like a goal. Today I'm gonna fix this . Today I'm gonna fix this bug or something.
I'm gonna do something. You have something to wake up to. And I think maybe especially as a man, also women,
but you need a hard work. You need like an endeavor, I think. - How much of the building that you do is about money?
How much is it about just a deep internal happiness? - It's really about fun, 'cause I was doing it when I didn't make money, right?
That's the point. So I was always coding, I was making music. I made electronic music, drum bass music 20 years ago,
and I was always making stuff. So I think creative expression is like
a meaningful work that's so important. It's so fun. It's so fun to have like a daily challenge where you try figure stuff out.
- But the interesting thing is you built a lot of successful products and you never really wanted to take it to that level
where you scale real big- - Yeah. - And sell it to a company or something like this. - Yeah, the problem is I don't dictate that, right?
If more people start using it, if millions of people suddenly start using it and it becomes big,
I'm not gonna say, "Oh, stop signing up to my website and pay me money." But I never raised funding for it. And I think, 'cause I don't like
the stressful life that comes with it. I have a lot of founder friends
and they tell me secretly. With hundreds of millions of dollars in funding and stuff,
they tell me, "Next time, if I'm gonna do it, I'm gonna do it like you because it's more fun, it's more indie,
it's more chill, it's more creative." They don't like to be manager, right? You become like a CEO, you become a manager.
And I think a lot of people that start startups, when they become a CEO, they don't like that job actually,
but they can't really exit it. But they like to do the groundwork, the coding.
So I think that keeps you happy, doing something creative. - Yeah, it's interesting how people are pulled towards that,
to scale to go really big, and you don't have that honest reflection with yourself,
like what actually makes you happy? 'Cause for a lot of great engineers, what makes them happy is the building,
the quote, unquote, "individual contributor." - Yeah. - like where you're actually still coding or you're- - Yeah. - Actually still building.
And they let go of that, and then they become unhappy, but some of that is the sacrifice needed
to have a impact at scale if you truly believe in a thing you're doing. - But look at Elon.
He's doing things million times bigger than me, and would I wanna do that?
I don't know, you can't really choose these things, right? But I really respect that. I think Elon's very different from VC founders. VC, it's like software.
There's a lot of bullshit in this world, I think. There's a lot of there's dodgy, finance stuff happening there, I think.
And I never have concrete evidence about it, but your gut tells you something's going on with companies getting sold to-
- Yeah. - Friends and VCs, and then they do reciprocity and this shady financial dealings.
With Elon, that's not. He's just raising money from investors and he's actually building stuff. He needs the money to build stuff, hard hardware stuff,
and that I really respect. - You said that there's been a few low points in your life. You've been depressed,
Low points
and building is one of the ways you get out of that. Can you talk to that? Can you take me to that place,
that time when you were at a low point? - So I was in Holland and I graduated university,
and I didn't wanna get a normal job, and I was making some money with YouTube 'cause I had this music career and I uploaded my music to YouTube.
And YouTube started paying me with AdSense, like $2,000 a month, $3,000 a month.
And all my friends got normal jobs, and we stopped hanging out, 'cause people would, like in university, hang out,
chill at each other's houses, you go party. But when people get jobs, they only party in the weekend,
and they don't hang anymore in the week 'cause you need to be at the office. And I was like, "This is not for me. I wanna do something else."
And I was starting getting this like, I think it's like Saturn return when you turn 27.
It's like some concept where Saturn returns to the same place in the orbit that it was when you're born. - I'm learning so many things.
- [Pieter] It's some astrology thing. - So many truly special artists died when they were 27.
- [Pieter] Exactly, there's something with 27, man. And it was for me. I started going crazy- - Yeah. - Because I didn't really see my future in Holland,
buying a house, going living in the suburbs, and stuff. So I flew out, I went to Asia, started digital nomading,
and did that for a year. And then that made me feel even worse, 'cause I was like alone in hotel rooms,
looking at the ceiling. What am I doing with my life? I was working on startups and stuff on YouTube,
but what is the future here?
While my friends in Holland were doing really well and living normal life.
So I was getting very depressed and I'm like an outcast. My money was shrinking. I wasn't making money anymore a lot.
I was making $500 a month or something, And I was looking at the ceiling thinking like,
"Now I'm 27, I'm a loser." And that's the moment when I started building startups. And it was because my dad said,
"If you're depressed, you need to get sand, get shovel, start shoveling, doing something. You can't just sit still."
Which is kinda like a interesting way to deal with depression. It's not like, "Oh, let's talk about it." It's more like, "Let's go do something."
And I started doing a project called 12 Startups in 12 Months where every month I would make something, like a project,
and I would launch it with Stripe, so people could pay for it. - So the basic format is try to build a thing,
put it online, and put Stripe to where you can pay money for it. - Yeah, add a Stripe... I'm not sponsored by Stripe, but add a Stripe checkout button.
- Is that still the easiest way to just like pay for stuff, Stripe? - 100%, I think so, yeah. - It's a cool company.
They just made it so easy. You can just click and- - Yeah. And they're really nice. The CEO, Patrick, is really nice.
- Behind the scenes, it must be difficult to actually make that happen because that used to be a huge problem.
- [Pieter] Merchant. - Just adding a thing, a button where you can pay for a thing. - Dude. - It's-
- Dude, I know this because when I was- - Trustworthy. - Nine years old, I was making websites also,
and I tried to open a merchant account. There was like before Stripe you would have like,
I think it was called Worldpay. So I had to fill out all these forms, and then I had to fax them to America
from Holland with my dad's fax. It was on my dad's name, and he had to sign for this,
and he started reading these terms and conditions, which is he's liable for 100 million in damages. And he's like, "I don't wanna sign this."
I'm like, "Dad, come on, I need a merchant account. I need to make money on the internet." - Yeah. (chuckles) - And he signed it, and we faxed it to America,
and I had a merchant accounts, but then nobody paid for anything, so that was the problem, But it's much easier now.
You can sign up, you add some codes, and yeah. - So 12 startups in 12 months.
12 startups in 12 months
- [Pieter] Yeah. - Startup number one, what was that?
What were you feeling? Were you sitting behind the computer, how much do you actually know about building stuff at that point?
- Well, I could code a little bit 'cause I did the YouTube channel and I made a website for... I would make websites for the YouTube channel.
It was called "Panda Mix Show." And it was like these electronic music mixes, like dubstep, or drum bass, or techno house.
- [Lex] I saw one of them had Flash. Were you using Flash? - Yeah, my album, my CD album was using Flash. Yeah, yeah. - Yeah.
- I sold my CD, yeah. - Kids, Flash was a- - Flash was cool. - Software. This is the break that- - Yeah, like grandpa,
but Flash was cool. - Yeah, and there was... What it is called? Boy, I should remember this ActionScript. There's some kind of programming language
- Script, yeah, yeah, ActionScript. - Oh, yeah. - It was in Flash. Back then that was the JavaScript. - The JavaScript, yeah. - Yeah. And I thought that's gonna,
that's supposed to be the dynamic thing that takes over the internet. - Yeah. - I invested so many hours in learning that. - And Steve Jobs killed it. - Steve Jobs.
- Steve Jobs said, "Flash Sucks, stopped using it." Everyone is like, "Okay." - That guy was right though, right? - Yeah, I don't know, yeah.
Well, it was a closed platform I think and- - Closed. - But this is ironic 'cause Apple, they're not very open.
- Right. - But back then Steve want was like, this is closed. We should not use it. And it's a security problems I think,
which sounded like a cop out. I just wanted to say that to make it look kind of bad. But Flash was cool, yeah.
- Yeah, it was cool for a time. - Yeah. - Listen, animated GIFs were cool for a time too. - Yeah. - They came back
in a different way. - Yeah. - As a meme though. I mean like, I even remember when GIFs were actually cool, not ironically cool.
- Yeah. - There's like, on the internet you would have like a dancing rabbit or something like this. - [Pieter] Yeah.
- And that was really exciting. - No, you had like the Lex homepage. Everything was centered. - Yeah. - And you had like Pieter's homepage
and on the construction. - Yeah. - GIF which was like a guy with a helmet and the lights.
It was amazing. - And there banners. Yeah, that's before like Google AdSense, you would've like banners for advertising.
- It was amazing, yeah. - And a lot of links to porn I think. - Yeah. - Or porny type things.
- I think that devil's squared, and merchant accounts people would use for, people would make money a lot. Only money made on internet was like porn or a lot of it.
- Yeah, it was a dark place. It's still a dark place. - Yeah. - But there's beauty in the darkness.
Anyway, so you did some basic HTML. - Yeah, yeah, but I had to learn the actual like coding.
So this was good. It was a good idea to like launch startup, so I could learn the codes, learn basic stuff.
But it was still very scrappy 'cause I didn't have time to, which is on purpose. I didn't have time to spend a lot of, I had a month to do something,
so I couldn't spend more than a month. And I was pretty strict about that. And I published it as a blog post. So people, I think I put it on Hacker News
and people would check kinda like, oh, did you actually, you know. I felt like accountability, 'cause I put it public,
that I actually had to do it. - Do you remember the first one you did? - I think it was Play My Inbox,
'cause back then my friends, we would send like cool... It was before Spotify, I think, we would send like...
2013, we would send music to each other, like YouTube links. This is a cool song, this is a cool song.
And it was these giant email threads on Gmail. And they were like unnavigable. So I made an app that would log into your Gmail,
get them emails and find ones of YouTube links and then make kinda like a gallery of your songs.
Essentially Spotify, and my friends loved it. - Was it scraping it? Like what was API?
- No, it uses like a POP like POP or IMAP, Actually check your email, so that like privacy concerns, 'cause it would get all your emails to find YouTube links.
But then I wouldn't save anything. But that was fun.
And that first product already would get pressed, when think like some tech media and stuff.
And I was like, that's cool. It didn't make money, there was no payment button, but actually people using it.
I think tens of thousands of people used it. - That's a great idea. I wonder why, why don't we have that?
Why don't we have things that access Gmail and extract some useful aggregate information.
- Yeah, yeah, you could tell Gmail, don't give me all the emails, just give me the ones with YouTube links- - Yeah. - Or something like that.
- Yeah, I mean there is a whole ecosystem of apps you can build on top of the Google. - Yeah. - But people don't really-
- [Pieter] Never do this, I've ever see them. - They build... I've seen a few, like Boomerang, there's a few apps that are like good,
but just- - Yeah. - I wonder what... Maybe it's not easy to make money. - I think it's hard to get people to pay for these like extensions and plugins, you know.
- Yeah. - 'Cause it's not a real app, so it's not like people don't value it. People value, oh this... And a plugin should be free.
When I want to use a plugin in Google Sheets or something, I'm not gonna pay for it. It should be free.
But if you go to a website and you actually, okay, I need this product, I'm gonna pay for this 'cause it's a real product. So even though it's the same code in the back.
It's a plugin. - Yeah, I mean you could do it through extensions, like Chrome extensions through from the browser.
- Yeah, but who pays for Chrome extensions, right? - Nobody. - Barely anybody. - [Lex] Nobody. - That's not a good place to make money, probably.
- Yeah, that sucks. - Chrome extension should be a extension for your startup. You know, you have a product. - Yeah. - Oh, we also have a Chrome extension.
- I wish the Chrome extension would be the product. I wish Chrome would support that. - [Pieter] Yeah.
- Where you could pay for it easily. Because imagine, I can imagine a lot of products that would just live as extensions,
like improvements for social media. - Yeah. - A thing that- - It's GPTs. - GPTs, yeah. - Like these ChatGPTs,
they're gonna charge money for now. And you get a rev share, I think from OpenAI. I made a lot of them also.
- Why? We'll talk about it. - Yeah. - So let's rewind back. (Pieter laughs) It's a pretty cool idea to do 12 startups in 12 months.
What's it take to build a thing in 30 days? At that time, how hard was that?
- I think the hard part is figuring out what you shouldn't add, right? Which you shouldn't build because you don't have time. So you need to build a landing page.
Well, you need to make the... (Lex laughs) You need to build the product actually, 'cause it need to be something they pay for.
Do you need to build a login system? Maybe no, maybe you can build some scrappy login system. For Photo AI, you sign up,
you pay, Stripe checkout, and you get a login link. And when I started out, there was only a login link with a hash and that's just a static link.
So it's very easy to log in. - Yeah. - It's not so safe. What if you link the link and now I have real Google login,
but that took like a year. So keeping it very scrappy is very important too, because you don't have time.
You need to focus on what you can build fast. So money, Stripe,
build a product, build a landing page. You need to think about how are people gonna find this?
So are you gonna put it on Reddit or something? How are you gonna put it on Reddit without being looked at as a spammer, right?
If you say, "Hey, this is my new startup, you should use it." No, nobody gets deleted. Maybe if you find a problem
that a lot of people on Reddit already have and sub-Reddit, and you solve that problem and say, "Sub-people, I made this thing
that might solve your problem and maybe it's free for now." That could work.
But you need to be very narrow it down, what you're building.
- Time is limited. - Yeah. - Actually, can we go back to the, you laying in a room feeling like a loser?
Traveling and depression
- [Pieter] Yeah. - I still feel like a loser sometimes
Can you speak to that feeling, to that place of just like, feeling like a loser?
Because I think a lot of people in this world are laying in a room right now listening to this. - Yeah, yeah, yeah. - And feeling like a loser.
- Okay, so I think it's normal if you're young that you feel like a loser, first of all. - Especially, when you're 27. - Yes.
Yeah, especially. - There's like a peak. - Yeah, yeah, I think 20 is the peak. And so I would not kill yourselves. It's very important.
Just get through it. Because you have nothing, probably no money,
you have no business, you have no job yet. Jordan Peterson said this, I saw it somewhere,
people are depressed because they have nothing. They don't have a girlfriend. They don't have a boyfriend. They don't have a... You need stuff, you need like, or a family.
You need things around you. You need to build a life for yourself. If you don't build a life for yourself, you'll be depressed. So if you're alone in Asia in a hostel
looking at the ceiling, and you don't have any money coming in, you don't have a girlfriend, you don't, of course, you're depressed.
It's logic. But back then, if you're in a moment, you think there's not logic, there's something wrong with me. - [Lex] Yeah.
- And also I think I started getting like anxiety, and I think I started going a little bit crazy
where I think travel can make you sane. And I know this because I know that there's like
digital nomads that they kill themselves. I haven't checked the comparison with baseline people, like suicide rate.
But I have a hunch, especially in the beginning when it was a very new thing like 10 years ago,
that it can be very psychologically taxing. And you're alone a lot,
back then when you travel alone, there was no other digital nomads back then, a lot. So you're in a strange culture.
You look different in everybody. I was in Asia, everybody's really nice in Thailand, but you're not part of the culture.
You're traveling around, you're hopping from city to city. You don't have a home anymore.
You feel disrooted. - And you're constantly in the outcast and that you're different from everybody else.
- Yes, exactly. Like Thailand, people are so nice. - [Lex] Yes. - But you still feel like outcast. And then I think the digital nomads I met then
were all kinda like, it was like shady business. But they were like vigilantes 'cause it was a new thing. And one guy was selling illegal drugs.
It was an American guy. It was selling illegal drugs via UPS to Americans on this website. There were a lot of dropshippers doing shady stuff.
There's a lot of shady things going on there. And they didn't look like very balanced people. They didn't look like people I wanted to hang with.
So I also felt outcast from other foreigners in Thailand, other digital nomads. And I was like, "Man, I made a big mistake."
And then I went back to Holland and then I got even more depressed. - You said digital nomad. What is digital nomad?
What is that way of life? What is the philosophy there? And the history of the movement. - I struck upon it on accident.
'Cause I was like, I'm gonna graduate university and then I need to get out of here. I'll fly to Asia, 'cause I've been before in Asia. I studied in Korea in 2009.
Study exchange. I was like, Asia is easy. Thailand is easy. And I'll just go there, figure things out. And it's cheap.
It's very cheap. Chiang Mai, I would live like for $150 per month rent. - Yeah. - For like a private room. Pretty good. So I struggled on this on accident.
I was like, okay, there's other people on laptops working on their startup or working remotely. Back then nobody worked remotely,
but they worked on their businesses, right? And they would live in Columbia or Thailand
or Vietnam or Bali. They would live kind of like in more cheap places. And it looked a very adventurous life.
You travel around, you build your business. There's no pressure from your home society, right? You're American.
So you get pressure from American society telling you kind of what to do. You need to buy a house or you need to do this stuff. I had this in Holland too.
And you can get away from this pressure. You can kind of feel like you're free. There's nobody telling you what to do.
But that's also why you start feeling like you go crazy 'cause you are free, you're disattached from anything and anybody,
you're disattached from your culture. You're disattached from the culture you're probably in, 'cause you're staying very short. - I think Franz Kafka said, "I'm free, therefore I'm lost."
- Man, that's so true. Yeah, that's exactly the point. And yeah, freedom is like, it's the definition of no constraints, right?
Anything is possible. You can go anywhere. And everybody's like, "Oh, that must be super nice."
Freedom, you must be very happy. And it's opposites, I don't think that makes you happy. I think constraints probably make you happy,
and that's a big lesson I learned then. - But what were they making for money? So you're saying they were doing shady stuff at that time?
- For me, 'cause I was more like a developer. I wanted to make startups kind of, and it was like drugs being shipped to America,
like diet pills and stuff. Non-FDA proof stuff. And they would like let...
They would say with beers and they would laugh about like all the dodgy shit kind of they're doing. - That part of, okay. - That kind of vibe.
Kind of sleazy, e-comm vibe. I'm not saying all e-comm is these. - Right. - But, you know, this vibe.
- It could be a vibe and your vibe was more build cool shit. - Make cool stuff. - That's ethical.
- You know, the guys with sports cars in Dubai, these people, you know. - Yes. - E-comm like, oh bro, you gotta drop ship.
- Yeah. - And you'll make 100 million a month. Those people was this shit. And I was like, this is not my people.
- Yeah, I mean there's nothing wrong with any of those individual components. - No, no judgment. - But there's a foundation that's not quite ethical.
What is that? I don't know what that is, but yeah, I get you. - No, I don't wanna judge. I noted for me, it wasn't my world,
it wasn't my subculture. I wanted to make cool shit. But they also think their shit is cool.
But I wanted to make real startups and that was my thing. I would read Hacker News, like Y Combinator,
and they were making cool stuff. So I wanted to make cool stuff. - I mean, that's a pretty cool way of life.
Just if you romanticize it for a moment. - It's very romantic man. It's colorful.
If I think about the memories. - What are some happy memories? Just like working, working in cafes or working in
just the freedom that envelopes you
from that way of life, 'cause anything is possible, you can just get off of. - I think it was amazing. We would work.
I would make friends and we would work until 6:00 AM in Bali, for example,
with Andre, my best friend was still my best friend and another friend, and we would work until the morning
when the sun came up. Because at night, the coworking space was silence. There was nobody else.
And I would wake up 6:00 PM or 5:00 PM. I would drive to the coworking space on a motorbike.
I would buy 30 hot lattes from a cafe. - How many? - 30.
'Cause there was like six people coming or we didn't know. Sometimes people would come in. - Did you say three, zero, 30?
- Yeah. - Nice. - And we would drink like four per person or something. - Yeah. - Man, it's Bali. I don't know if they were powerful lattes,
but they were lattes and we'd put 'em in a plastic bag and then we'd drive there and all the coffee was like falling everywhere.
- [Lex] Yeah. - And then we'd go negotiate and have these coffees here and we'd work all night. We'd play like techno music,
and everybody would just work in there. This was literally like business people. They would work in their startup and we'd all try and make something.
And then the sun would come up and the morning people, the yoga,
yoga girls and yoga guys would come in after the yoga class at six, and they'd say, "Hey, good morning." And we're like, we look like this.
- Yeah. - And we're like, what's up, how are you doing? And we didn't know how bad we looked, but it was very bad.
And then we'd go home, sleep in a hostel or a hotel and do the same thing and again and again and again.
And it was this lock-in mode, like working. And that was very fun.
- So it's just a bunch of you techno music blasting all through the night, yeah.
- More like (imitates techno music) Like industrial. - Rap chase. - Not like this cheesy. - For me, it's such an interesting thing
because the speed of the beat affects how I feel about a thing. - Yeah. - So the faster it is, the more anxiety I feel.
But that anxiety is channeled into productivity. But if it's a little too fast,
the anxiety overpowers that. - So you don't like drum bass music? - No, probably not. - No, it's too fast. - I mean, for working,
I have to play with it. - Yeah. - It's like you can actually, I can adjust my- - Yeah. - Level of anxiety.
There's a must be a better word than anxiety. It's like productive anxiety that I like. - Yeah.
- Whatever that is. - It also depends what kind of work you do, right? If you're writing, you probably don't want drum bass music. I think for codes like industrial techno,
this kind of stuff, kind of fast. It works well, 'cause you really get locked in and combined with caffeine,
you go deep. - (laughs) Yeah. - And I think you balance on this edge of anxiety, 'cause this caffeine is also hitting your anxiety.
And you want to be on the edge of anxiety with this techno running. Sometimes it gets too much. It's like stop the techno, stop the music is like,
but those are good memories. And also like travel memories. You go from city to city. - Yeah. - And it feels like, it's kinda like jet set life.
It's feels very beautiful. You're seeing a lot of cool cities. - What was your favorite place that you remember, you visited?
- I think still Bangkok is the best place.
And Bangkok and Chiang Mai. I think Thailand is very special. I've been to the other place. I've been to Vietnam
and I've been to South America and stuff. I still think Thailand wins in how nice people are.
How easy of a life people have there. - Everything is cheap. - Yeah. - And good.
- Well, Bangkok is getting expensive now, but Chiang Mai is still cheap. I think when you're starting out. It's a great place.
Man, the air quality sucks. It's a big problem. And it's quite hot. But that's a very cool place.
- [Lex] Pros and cons. - I love Brazil also. My girlfriend is Brazilian. Not just because of that, but I like Brazil.
The problem still is the safety issue. It's like in America, like it's localized. It's hard for Europeans to understand.
Safety is localized to specific areas. So if you go to the right areas, it's amazing. Brazil is amazing. If you go to wrong areas, maybe you die.
Right? - Yeah. Yeah, I mean that's true. - But it's not true in Europe. In Europe it's much more- - That's true. That's true. - More average.
- You're right, you're right. It's more averaged out. - Yeah. - I like it when there's strong neighborhoods,
when you're like, you cross a certain street and you're in a dangerous part of town.
- Man, yeah. - I like it. I like there's certain cities in the United States like that. - Yeah. - I like that.
And you're saying Europe is more about that. - But you don't feel scared? - Well, I don't, I like danger. - Well, you BJJ.
- No, not even just that. I think dangers interesting. - Yeah. - Danger reveals something about yourself, about others.
Also, I like the full range of humanity. - Yeah. - So I don't like the mellowed out aspects of humanity.
- I have friends like, nomad friends that are exactly like this. They go to the kind of broken areas.
They like this reality. They like the authenticity more. They don't like luxury. They don't like- - Oh, yeah, I hate luxury.
- Yeah. - Yeah. - It's very European view, right? (laughs) - Wait, was that? (Lex and Pieter laughs) That's a whole nother conversation.
- Yeah. - So you quoted Freya Stark quote,
"To awaken quite alone in a strange town is one of the most pleasant sensations in the world."
- Yeah. - Do you remember a time you had woken in a strange town and felt like that?
We're talking about small towns or big towns or? - Man, anywhere. I think I wrote it in some blog posts and like...
It was a common thing when you would wake up and this was like... I have this website. I started a website about this digital nomads,
called nomadlist.com. And this was a community, so it was like 3,000 other digital nomads, 'cause I was feeling lonely.
So I built this website and I stopped feeling lonely. I started organizing meetups and making friends and it was very common that people would say,
they would wake up and they would forget where they are. - Yeah. - For the first half minute.
And I had to look outside like, where am I? Which country? Which sounds really like privileged, but it was more like funny.
You literally don't know where you are because you're so disrooted. But there's something...
Man, it's like Anthony Bourdain. There's something pure about this kinda
vagabond travel thing. It's behind me, I think. Now I travel with my girlfriend, right?
It's very different. But it is a romantic, memories of this kind of like vagabond,
individualistic solo life. But the thing, it didn't make me happy, but it was very cool. But it didn't make me happy, right?
It made me anxious. - There's something about it that make you anxious. I don't know, I still feel like that, it's a cool feeling.
It's scary at first, but then you realize where you are. I don't know, it's like you awaken
to the possibilities of this place- - That's it. - When you feel like that. - That's it. - That's great. And it's even when you're doing some basic travel.
- [Pieter] Yeah. - Go to San Francisco or something else. - Yeah, you have like the novelty effect. You're in a new place.
Here things are possible. You don't get bored yet. And that's why people get addicted to travel.
- Back to startups. You wrote a book on how to do this thing and gave a great talk on it, how to do startups.
Indie hacking
The book is called "Make: Bootstrapper's Handbook." - Yeah. - I was wondering if you could go through some of the steps.
It's idea, build, launch, grow, monetize, automate, and exit. There's a lot of fascinating ideas in each one.
So idea stage. - Yeah. - How do you find a good idea? - So I think you need to be able to spot problems.
So for example, you can go in your daily life, when you wake up and you're like, what are stuff that I'm really annoyed with?
In my daily life that doesn't function well, and that's a problem that you can see. Okay, maybe that's something I can add, write code about,
code for and it will make my life easier. So I would say make like a list of all these problems you have and like an idea to solve it,
and see which one is like viable. You can actually do something and then start building it. - So that's a really good place to start.
Become open to all the problems in your life. Like actually start noticing them. - Yeah. - I think that's actually
not a true real thing to do, to realize that some aspects of your life could be done way, way better.
- Yeah. - Because we kinda very quickly get accustomed to discomforts. - [Pieter] Exactly.
- Like for example, like doorknobs. - [Pieter] Yeah. - Design of certain things. (laughs)
- I knew you like scream and doorknob. - Yeah. - 50 tons. - Well, that one I know how much
incredible design work has gone into. It's a really interesting. - Yeah. - Doors and doorknobs.
Just the design of everyday things. - Yeah. - Forks and spoons. It's gonna be hard to come up with a fork
that's better than the current- - Yeah. - Fork designs. - Yeah. - And the other aspect of it is you're saying like, in order to come up with interesting ideas,
you gotta try to live a more interesting life. - Yeah, but that's where travel comes in. - [Lex] Yeah.
- Because when I started traveling, I started seeing stuff in other countries that you didn't have in Europe, for example, or America even.
If you go to Asia, dude, especially 10 years ago, nobody knew about this WeChats,
all these apps that they already had before we had them, these everything apps, right? Now Elon's trying to make X,
this everything app like WeChat, same thing. In Indonesia or Thailand, you have one app that you can order food,
if you can order groceries, you can order massage, you can order car mechanic.
Anything you can think of is in the app. And that stuff, for example, that's called arbitrage.
You can go to back to your country and build that same app for your country, for example. So you start seeing problems,
you start seeing solutions that other people already did in the rest of the world. And also traveling in general
just gives you more problems, 'cause travel is uncomfortable.
Airports are horrible. Airplanes are not comfortable either. There's a lot of problems you start seeing,
just getting outta your house, you know. - But also you can, I mean in the digital world you can just go into different communities
and see what can be improved- - Yes. - In that. - Yeah, yeah, yeah. - What specifically is your process of generating ideas?
Do you like do idea dumps? Do you have a document where you just keep writing stuff? - Yeah, I used to have like a...
'Cause when I wasn't making money, I was trying to like make this list of ideas to see like, so I need to build...
I was thinking statistically already, like I need to build all these things, and one of these will work out probably. So I need to have a lot of things to try.
And I did that. Right now I think like, because I already have money, I can do more things based on technology.
So for example, AI, when I found out about when Stable Diffusion came or ChatGPT and stuff,
all these things were like, I didn't start working with them because I had a problem.
I had no problems. But I was very curious about technology and I was like playing with it
and figuring out like... First just playing with it and then you find something like, okay, this generates...
Stable Diffusion generates houses very beautiful and interiors. - So it's less about problem solving, it's more about the possibilities
of new things you can create. - Yeah, but that's very risky because that's the famous like solution trying to find a problem.
- Yeah. - And usually, it doesn't work. And that's very common with startup funds. I think they have tech,
but actually people don't need the tech, right? - Can you actually explain, it'd be cool to talk about some of the stuff you've created.
Photo AI
Can you explain the photoai.com? - Yeah, yeah, so it's like fire your photographer.
The idea is like, you don't need a photography anymore. You can train yourself as AI model and you can take as many photos
as you want anywhere in any clothes with facial expressions, like happy or sad,
or poses, all this stuff. - So how does it work? - Yeah.
- (laughs) You send me. - So you could press- - A link to a gallery of ones done on me. - Yeah. - Which is?
- So on the left you have the prompt, the box. Yeah, so you can write like, so model is your model, this Lex Fridman. - Yeah. - So you can write like model
as a blah, blah, blah, whatever you want. - Yep. - Then press the button and it will take photos. It will take one minute.
- Photos, what are you using for the hosting for the compute? - Replicate. - Okay. - Replicate.com. They're very, very good.
- Okay, it's cool like this interface wise. It's cool that you're showing how long it's gonna take. This is amazing.
So I'm presuming you just loaded in a few pictures from the internet. - Yeah, so I went to Google Images,
typed in Lex Fridman. I added like 10 or 20 images. You can open 'em in the gallery,
and you can use your cursor to, yeah. So some don't look like you, so the hit and miss rate is like,
I don't know, I'd say like 50/50 or something. - But when I was watching it tweet, like it's been getting better and better and better.
- It was very bad in the beginning. It was so bad. But still people sign up to it, you know. - (laughs) There's two Lex is great.
It is getting more and more sexual. It's making me very uncomfortable. - Man, but that's the problem with these models. 'cause (Lex laughs)
we need to talk about this, 'cause the models- - I'm sure. - In Stable Diffusion. - Yeah. - So the photo realistic models that are like fine tunes.
- [Lex] Yeah. - They were all trained on porn in the beginning. And it was a guy called Hassan. So I was trying to figure out
how to do photo realistic AI photos. Stable Diffusion by itself is not doing that well. The faces look all mangled. - Yep.
- And it doesn't have enough resolution or something to do that well. But I started seeing these base models,
these fine models and people would train on porn and I would try them and they would be very photorealistic.
They would have bodies that actually made sense like body anatomy.
But if you look at the photo realistic models that people use now, still, there's still core of porn there,
of naked people. - Yeah. - So I need to prompt out the naked and everyone needs to do this with AI startups, with imaging. You need to prompt out the naked stuff.
You need to put a naked- - You have to keep reminding the model. You need to put clothes on the thing.
- Yeah, don't put naked 'cause it's very risky. I have Google Vision that checks- - Yeah. - Every photo before it's shown to the user
to like check for NSFW. - Like the nipple detector. Oh, NSFW detector. - Because the journalists get very angry
if they, you know. - If you sexualized. - There was a journalist I think, that would got angry to use this. And it was like, oh, it showed like a nipple,
'cause Google Vision didn't detect it. So that's like these kind of problems you need to deal with,
that's what I'm talking about. This is with cats. But look at the cat face. It's also kind of mangled.
(Lex laughs) - I'm a little bit disturbed.
- Can zoom in on the cat if you want. Yeah, it's a very sad cut. (Lex laughs)
It doesn't have a nose. - It doesn't have a nose. Wow. - Man, but this is the problem with AI startup 'cause they all act like it's perfect.
This is groundbreaking. But it's not perfect. - Yeah. - It's like really bad half the time.
- So if I wanted to sort of update model as? - Yeah, so you remove this stuff and you write whatever you want,
like in Thailand or something, or in Tokyo. - In Tokyo? - Yeah.
- And then- - You could say like at night with neon lights, you can add more detail to make you.
- I'll go in Austin. Do you think you'll know in Texas? - Yeah, Austin. - In Austin, Texas. - With cowboy hats. - In Texas, yeah.
- As a cowboy. - As a cowboy.
It's gonna go towards the porn direction. Man, I hope not. It's the end of my career.
(Pieter and Lex laughs) - Or the beginning, it depends. We can send you a push notification when your photos are done.
Yeah, all right, cool. - Yeah, let's see. - Oh, wow. So this whole interface you've built.
- Yeah. - This is really well done. - It's so jQuery. - So I still use jQuery. - Yes. - The only one. - Still.
- After 10 years. - To this day. You're not the only one, the entire of the web. - Yeah. - This PHP. - PHP and jQuery.
Yeah, SQLite. - You're just like one of the top performers from a programming perspective
that are still openly talking about it. But everyone's using PHP.
Most of the web is still probably PHP and jQuery. - I think 70%, 'cause of WordPress, right? 'Cause the blogs are- - Yeah, that's true.
- Yeah. - That's true. - I'm seeing a revival now. People are getting sick of frameworks.
Like all the JavaScript frameworks are so like, what do you call it? Like wieldy, so it takes so much work to just maintain this code
and then it updates to a new version. You need to change everything. PHP just stays the same and works.
- Yeah, can you actually just speak to that stack? You build all your websites, apps, startups, projects,
all of that with mostly vanilla HTML. - [Pieter] Yeah, yeah.. - JavaScript, jQuery, PHP, and SQLite.
And so that's a really simple stack, and you get stuff- - Yeah. - Done really fast. Can you just speak to the philosophy behind that?
- I think it's accidental, 'cause that's the thing I knew, like I knew PHP, I knew HTML, CSS,
'cause you make websites and when my startups started taking off,
I didn't have time to... I remember putting on my to-do list like learn Node.js, 'cause it's important to switch,
'cause- - Yeah. - This obviously is much better language than PHP, and I never learned it. I never did it, 'cause I didn't have time.
These things were growing like this, and I was launching more project and I never had time. It's like one day,
I'll start coding properly and I never got to it. - I sometimes wonder if I need to learn that stuff.
It's still to do for me to really learn Node.js or Flask or these kind of-
- React. - Yeah, React. It feels like a responsible software engineer
should know how to use these, but you can get stuff done so fast
with vanilla versions of stuff. - Yeah, it's like software developers if you wanna get a job and it's like, you know, people making stuff like startups
and if you want to be entrepreneur probably maybe shouldn't, right? - I wonder if there's like, I really wanna measure performance and speed.
I think there's a deep wisdom in that. - Yeah. - I do think that frameworks and just constantly wanting to learn the new thing
that's complicated way of software engineering gets in the way. I'm not sure what to say about that because definitely like you shouldn't build everything
from just vanilla JavaScript or vanilla C, for example. - Yeah. - C++
when you're building systems engineering is like, there's a lot of benefits for a pointer safety
and all that kind of stuff. So I don't know, but it just feels like you can get so much more stuff done
if you don't care about how you do it. - Man, this is my most controversial take, I think, and maybe I'm wrong,
but I feel like there's frameworks now that raise money. They raise a lot of money.
They raise 50 million, 100 million, $30 million. And the idea is that you need to make the developers,
the new developers, like when you're 18 or 20 years old, right? Get them to use this framework and add a platform to it.
Where the framework can... It's open source, but you probably should use the platform which is paid to use it.
And the cost of the platforms to host it are a thousand times higher than just hosting it
on a simple AWS server or a VPS on DigitalOcean, right? So there's obviously like a monetary incentive here.
We wanna get a lot of developers to use this technology and then we need to charge them money 'cause they're gonna use it in startups
and then the starters can pay for the bills. It kind of destroys the information out there
about learning to code because they pay YouTubers, they pay influencers,
developer influencers is a big thing to like... And same thing what happens with like nutrition and fitness or something.
Same thing happens in developing, they pay this influencer to promote this stuff, use it, make stuff with it, make demo products with it.
And then a lot of people are like, "Wow, use this." And I started noticing this 'cause when I would ship my stuff, people would ask me, "What are you using?"
I would say, "Just PHP, jQuery, why does it matter?" And people would start kind of attacking me like, "Why are you not using this new technology,
this new framework, this new thing?" And I say, "I don't know, 'cause this PHP thing works and I'm optimizing for anything,
it just works." And I never understood like why, I understand there's new technologies that are better
and there should be improvement, but I'm very suspicious of money. Just like lobbying. There's money in this developer framework scene.
There's hundreds of millions that goes to ads or influencer or whatever. It can't all go to developers.
You don't need so many developers for a framework, and it's open source. To make a lot of more money on these startups.
- So that's a really good perspective. But in addition to that is like, when you say better,
it's like, can we get some data on the better? (Pieter laughs) Because I wanna know
from the individual developer perspective and then from a team of five, team of 10, team of 20 developers- - Yeah.
- Measure how productive they are in shipping features. How many bugs they create,
how many security holes result. - PHP was not good with security for a while, but now it's good.
- In theory, in theory- - Yeah. - Is it though? - Now it's good. - No, now as you're saying it,
I wanna know if that's true because PHP was just the majority- - Yeah. - Of websites on the internet.
- [Pieter] Could be true. - Is it just overrepresented? Same with WordPress? - Yeah. - Yes, there's a reputation that WordPress
has a gigantic number of security holes. I don't know if that's true. I know it gets attacked a lot because it's so popular.
- [Pieter] Yeah. - It definitely does have security holes, but maybe a lot of other systems have security holes as well.
Anyway, I just sort of questioning the conventional wisdom that keeps wanting to push software engineers towards frameworks, towards complex.
- [Pieter] Yeah, yeah, yeah, yeah. - Like super complicated sort of software engineering approaches that stretch out the time
it takes to actually build a thing. - Man, 100%. And it's the same thing with big corporations. 80% of the people don't do anything.
It's like- - Right. - It's not efficient. Your benchmark is like people building stuff
that actually gets done and like for society, right? If we wanna save time, we should probably use technology
that's simple, that's pragmatic, that works, that's not overly complicated. It doesn't make your life like a living hell.
- And use a framework one that obviously solves a problem, a direct problem that you- - Of course, yeah, of course.
I'm not saying you should code without a framework. You should use whatever you want. Yeah, think it's suspicious.
(Lex laughs) And I think it's suspicious. When I talk about it on the Twitter, there's this army comes out. - Yeah. - There's these framework armies.
- [Lex] Yeah. - Man, something... My gut tells me. - I wanna ask the framework army, what have they built this week?
It's the Elon question. What did you do this week? - Yeah, did you make money with it? Did you charge users? Is it a real business?
Yeah. - So going back to the cowboy. - First of all, some never look like you, right?
But some do. - Every aspect of this is pretty incredible. I'm also just looking at the interface. It's really well done. So this is all just jQuery.
- Yeah. - This is really well done. So take me through the journey of Photo AI.
Most of the world doesn't know much about Stable Diffusion or any of this- - Yeah. - Any of the generative AI stuff.
And so you're thinking, okay, how can I build cool stuff with this? - [Pieter] Yeah. - So what was the origin story of Photo AI?
- I think it started, 'cause Stable Diffusion came out. So Stable Diffusion is like this- - Yeah. - The first like generative image model, AI model.
And I started playing with it, like you could install it on your Mac, somebody forked it and made it work for MacBooks.
So I downloaded it and cloned the Repo, started using it to generate images
and it was like amazing. I found it on Twitter because you see things happen on Twitter
and I would post what I was making on Twitter as well and you could make any image, you could write a prompt.
So essentially write a prompt and then it generates a photo of that or image of that in any style.
They would use like artist names to make like a Picasso kind of style and stuff.
And I was trying to see like what is it good at? Is it good at people? No, it's really bad at people,
but it was good at houses. So architecture, for example, I would generate like architecture houses.
So I made a website called thishousedoesnotexist.org. And it generated like,
they called it like house porn at that one. (Lex laughs) House porn is like a subreddit. And this was Stable Diffusion like the first version.
So it looks really... You can click for another photo. So it generates all these kind of non-existing houses.
- It is house porn. - But it looked kind of good. Especially back then. - It looks really good. - Now things look much better.
- That's really, really well done. Wow. - And it also generates like a description.
- And you can upvote. Is it nice? - Yeah. - Upvote it. - Yeah. - Man, there's so much to talk to you about. Like the choices here. (Pieter chuckles)
It's really well done. - This is very scrappy. In the bottom, there's like a ranking of the most upvoted houses. So these are the top vote.
And if you go to old time, you see quite beautiful ones. Yeah, so this one is my favorite. The number one, it's kinda like a.
- How is this not more popular? - It was really popular for like a while, but then people got so bored of it, I think,
'cause I was getting bored of it too. Just continuous house porn. Everything starts looking the same.
But then I saw it was really good at interior, so I pivoted to interiorai.com where
I tried to like upload first generate interior designs. And then I tried to do like, there was a new technology called Image to Image
where you can input an image, like a photo, and it would kind of modify the thing.
So you see it looks almost the same as Photo AI. It's the same code essentially. - Nice.
- So I would upload a photo of my interior where I lived, and I would ask like change this into like a,
I don't know, like maximalist design. And it worked and it worked really well.
So I was like, okay, this is a startup, 'cause obviously interior design AI, and nobody's doing that yet.
So I launched this and I was successful and made like within a week, made 10K, 20K a month,
and now still makes like 40K, 50K a month. And it's been like two years. So then I was like, how can I improve this interior design?
I need to start learning fine tuning. And fine tuning is where you have this existing AI model and you fine tune it on a specific goal you wanted to do.
So I would find really beautiful interior design, make a gallery and train a new model
that was very good at interior design. And it worked and I used that as well. And then for fun, I uploaded photos of myself,
and here's where it happened. And to train myself like, and this would never work obviously.
And it worked. And actually it started understanding me as a concept. So my face worked,
and you could do like different styles, me as like very cheesy, medieval warrior, all this stuff.
So I was like, this is another startup. So now I did avatarai.me. I couldn't get to.com
And this was- - This still up? - Yeah, avatarai.me. Well, now it's forwards to photo AI, 'cause it pivoted.
- Got it. - But this was more like cheesy thing. So this is very interesting 'cause this went so viral.
It made like, I think 150K in a week or something. So most money I ever made.
And then big, this is very interesting, the big VC companies like Lenze, which are much better at iOS and stuff than me,
I didn't have iOS app. They quickly built an iOS app that does the same. And they found technology, and it's all open technology.
So it's good. And I think they made like $30 million with it. - [Lex] Yeah. - They became like the top grossing app after that.
- How do you feel about that? - I think it's amazing, honestly. And it's not like- - You didn't have like a feeling like, ah, fuck. - No, I was a little bit like sad,
'cause all my products would work out and I never had like real fierce competition. And now I have fierce competition from like a very skilled high talent.
I was developer studio or something that, and they already had an app. They had an app, an App Store for like,
I think retouching your face or something. So they were very smart. They add these avatars to there. It's a feature. They had the users,
they do a push notification to everybody. We have this avatars. - Yeah. - Man, they create, I think they made so much money.
I think they did a really great job. And I also made a lot of money with it. But I quickly realized it wasn't my thing,
'cause it was so cheesy. It was like Kitch, it's kind of like me as a Barbie
or me as a... - Yeah. - It was too cheesy. I wanted to go for like, what's a real problem we can solve? 'Cause this is gonna be a hype.
This is gonna be, and it was a hype, these avatars. It's like let's do real photography.
How can you make people look really photo realistic? And it was difficult. And that's why these avatars work, 'cause they were all like in a cheesy Picasso style,
and art is easy 'cause you interpret... All the problems that AI has
with your face are like artistic. If you call it Picasso. But if you make a real photo, all the problems with your face,
you look wrong. So I started making Photo AI, which was like a pivot of it
where it was like a photo studio where you could take photos without actually needing,
a photographer, needing a studio. You just type it. And I've been working on it for like the last year.
- Yeah, it's really incredible. That journey is really incredible. Let's go to the beginning of Photo AI though,
'cause I remember seeing a lot of really, (laughs) really hilarious photos. I think you were using yourself as a case study.
Right? - Yeah. - Yeah, so there's a tweet here. Sold $100,000 in AI generated avatars.
- Yeah, and it's a lot like, it's a lot for anybody. It's a lot for me. (Lex laughs) Making 10K a day on this, you know.
- That's amazing. That's amazing. - And then the nested tweet,
like that's the launch tweet, and then the before that it's like the me hacking on it.
- Oh, I see. So that... Okay, so October 26th, 2022.
- Yeah. - I trained an ML model on my face.
- Because my eyes are quite far apart. I learned when I did YouTube, I would put a photo of like my DJ photo, my mixture.
And people would say I look like a hammerhead shark. It was like the top comment. So then I realized my eyes are far apart.
- Yeah, the internet helps you figure out who you look like. - Yeah, helps realize how you look. - Boy, do I love the internet.
- So first trap. - Well what is, is this? Wait. - It's water from the waterfall,
but the waterfalls in the back, you know, so what's going on? - So how much of this is real?
- It's all AI. - It's all AI. - Yeah. - That's pretty good, though, for the early days. - Exactly.
But this was hit or miss, so you had to do a lot of curation, 'cause 99% of it was really bad. So these are the photos I uploaded.
- How many photos did you use? Only these, I will try more up to date picks later.
These are the only photos you uploaded? - Yeah, yeah. - Wow.
Wow, okay, so you were learning all this super quickly. - [Pieter] Yeah. - What are some interesting details
you remember from that time for what you had to figure out to make it work? And for people just listening, he uploaded just a handful of photos
that don't really have a good capture of the face. And he is able to- - I think it's cropped, it's like a cropped by the layout.
But they're square photos. So they're 512 by 512, because that's Stable Diffusion.
- But nevertheless not great capture the face. - Yeah. - It's not like a collection of several hundred photos
that are like 360 overview. - Exactly. I would imagine that too when I started I was like, oh, this must be like some 3D scan technology, right?
- Yeah. - So I think the cool thing with AI, it trains the concept of you. So it's literally like learning, just like any AI model learns, it learns how you look.
So I did this and then I was getting DMs, like Telegram messages,
how can I do the same thing? I want these photos. My girlfriend wants these photos. So I was like, okay, this is obviously a business,
but I didn't have time to code it, make a whole like app about it. So I made a HTML page,
registered domain name. It was a Stripe payment link, which means you have literally a link to Stripe to pay,
but there's no code in the back. So all you know is you have customers that paid money. Then I added like some a Typeform link.
So Typeform is a site where you can create your own input form like Google forms. So they would get a email with a link to the Typeform
or actually just a link after the checkout and they could upload their photos. So enter the email, upload the photos and I launched it,
and I was like, here first sale, so it's October 2022. And I think within the first 24 hours was like,
I'm not sure it was a thousand customers or something. But the problem was I didn't have code to automate this.
So I had to do manually. So the first few hundred, I just literally took their photos, train them,
and then I would generate the photos with the prompts, and I had this text file with the prompts, and I would do everything manually. And this quickly became way too much.
But that's another constraint. I was forced to code something up that would do that. And that was essentially making it
into a real website, right? - So at first it was the Typeform and they uploaded through the Typeform. - [Pieter] Stripe checkout platform, yeah.
- And then you were like, that image is downloaded. Did you write a script to export downloaded? - No, it downloaded the images myself.
It was a zip file, to unzipped the zip file. - Literally, and you unzipped it. One by one. - Yes. No, because you know, do things that don't scale.
Paul Graham says, right? And then I would train, and I would email them the photos, I think from my personal email say,
"Here's your avatars." And they liked it. They were like, "Wow, it's amazing." - You emailed them with your personal email.
- So I didn't have an email address on this- - Yeah. - Domain. - And this is like a hundred people. - Yeah, and then you know who signed up like,
man, I cannot say it, but really famous people, like really, really billionaires, famous tech billionaires did it.
And I was like, "Wow, this is crazy." And I was like so scared to mess them. So I said, "Thanks so much for using my sites."
And he's like, "Yeah, amazing app. Great work." So I was like, this is different than normal reaction.
- It's Bill Gates isn't, it? - Cannot say anything. (Lex laughs)
- Just like shirtless picks. - GDPR like privacy. - Right, right. - European regulation. - Right. - Cannot share anything.
I was like, wow. But this shows like... So you make something and then if it takes off very fast,
you're like, it's validated. You're like, here's something that people really want. But then also thought, this is a hype,
this is gonna die down very fast, and it did because it's too cheesy. - But you had to automate the whole thing.
How'd you automate it? So what's the AI component? How hard was that to figure out? - Okay, so that's actually in many ways the easiest thing,
'cause there is all these platforms already back then. There was platforms for fine tune, Stable Diffusion.
Now I use Replicate, back then I use different platforms, which was funny 'cause that platform
when this thing took off, I would tweet, 'cause I tweet always like how much money these websites make.
You call it vendor, right? The platform that did the GPUs, they increased their price for training from $3 to $20.
After they saw that I was making so much money. So immediately my profit is gone, 'cause I was selling them for $30
and I was in a Slack with them like saying, "What is this?" Can you just put it back to $3? They say, "Yeah, maybe in the future,
we're looking at it right now." I'm like, "What are you talking about?" You just took all my money, and they're smart. - Well, they're not that smart
because like you also have a large platform and a lot of people respect you.
So you can literally come out and say that. - I think it's like kind of dirty to cancel a company or something.
I prefer just bringing my business elsewhere. But there was no elsewhere- - Right. - Back then. - [Lex] Right.
- So I started talking to other AI model, ML platforms. So Replicate was one of those platforms.
And I started DMing, the CEO say, "Can you please create," it's called Dream Booth, this fine tuning of yourself.
Can you add this to your site? 'Cause I need this, 'cause I'm being price guard. And he said "No, because it takes too long to run.
It takes half an hour to run, and we don't have the GPUs for it." I said, "Please, please, please, and then after a week he said, "We're doing it, we're launching this."
And then this company became, it was like not very famous company. It became very famous with this stuff,
'cause suddenly everybody was like, oh, we can build similar apps like avatar apps. And everybody started building avatar apps
and everybody started using Replicate for it. And it was from these early DMs with like the CEO, like Ben Firshman.
Very nice guy. And he was like, they never prized media. They never treated me bad.
They always been very nice. It's a very cool company. So you can run any AI model, LLMs,
you can run on here. - And you can scale? - Yes, they scale, yeah, yeah. And I mean you can do now,
you can click on the model and just run it already. It's like super easy. You log in with GitHub. - That's great.
- And by running it on the website, then you can automate with the API, you can make a website that runs the model. - Generate images, generate text, generate videos,
generate music, generate speech. - Video. - Fine tune models. - They do anything, yeah. It's a very cool company.
- Nice. And you're like growing with them, essentially. They grew because of you, because it's like a big use case.
- Yeah, the website even looks weird now. It started as a machine learning platform
that was like, I didn't even understand what it did. It was just too ML. You would understand 'cause you're in the ML world.
I wouldn't understand - Now it's newb friendly. - Yeah, exactly. (Lex laughs) And I didn't know how it worked but I knew that they could probably do this and they did it.
They built the models and now I use them for everything. And we trainedlike, I think now 36,000 models,
36,000 people already. - But is there some tricks to fine tuning to like the collection of photos that are provided?
- Yes. - Like how do you? - Yes, man, there's so many hacks. - The hacks. - Yeah, it's like 100 hacks to make it work.
(Lex and Pieter laughs) - It get my secrets now. - Well, not the secrets, but the more like,
insights maybe about the human face and the human body. What kind of stuff get messed up a lot?
- I think people, well man, as a living, people don't know how they look. - [Lex] Yeah.
- They generate photos of themselves and then they say, "Ah, it doesn't look like me." - [Lex] Yeah.
- You can check the training photos. It does look like you. - Yeah. - But you don't know how you look. So there's a face dysmorphia of yourself
that you have known idea how you look. - Yeah, that's hilarious. I mean I've got to one of the least pleasant activities in my existence is having to listen to my voice
and look on my face. So I get to like really, really have to sort of
come into terms with the reality of how I look and how I sound. - Man, everybody. - But people often don't,
right? - Really? - You have a distorted view perspective. - I know that like if I would make a selfie
how I think I look that, that's nice. Other people think that's not nice. But then they make a photo of me, I'm like that's super ugly.
But then they're like, no, that's how you look. And you look nice. So how other people see you is nice. So you need to ask other people to choose your photos.
- Yeah, yeah, yeah. - You shouldn't choose them yourself 'cause you don't know how you look. - Yeah, you don't know what makes you interesting,
what makes you attractive or all this kind of stuff. - Yeah, exactly. - And a lot of us, this is dark aspect of psychology. We focus on some small flaws. - Yeah.
- This is why I hate plastic surgery, for example. - Yeah. - People try to remove the flaws when the flaws are the thing that makes you interesting and attractive.
- I learned from the hammerhead shark eyes this, the stuff about you that looks ugly to you. And it's probably what makes you,
original makes you nice and people like it about you. - [Lex] Yeah. - And it's not like, oh my god. And people notice it.
People notice your hammerhead eyes. But it's like, that's me, that's my face. I love myself.
And that's confidence, and confidence is attractive. - Yes. - Right? - Confidence is attractive. But yes, understanding what makes you beautiful.
It's the breaking of symmetry makes you beautiful. It's the breaking of the average face makes you beautiful.
All that. - Yeah. - And obviously different from men and women, a different age. It's all this kind of stuff. - Yeah, 100%.
- But underneath it all the personality, all of that. When the face comes alive,
that also is the thing that makes you beautiful. - Yeah. - But anyway, you have to figure all that out with AI. - Yeah, one thing that worked was like
people would upload full body photos themselves. So I would crop the face, right? And then the model knew better
that we're training mostly the face here. But then I started losing resemblance of the body, 'cause some people are skinny,
some people are muscular, whatever. So you want to have that too. So now I mix full body in the training with face photos,
face crops, and it's all automatic. And I know that other people, they use again AI models to detect like
what are the best photos in this training set? And then train on those. But it's all about training data
and it's with everything in AI. How good your training data is, is in many ways more important than
how many steps you train for like how many months or whatever with these GPUs. The goals.
- Do you have any guidelines for people of how to get good data? How to give good data to fine tune on?
- The photos should be diverse. So for example, if I only upload photos with a brown shirt or green shirts,
the model will think that I'm training the green shirts. So the things that are the same every photo
are the concepts that are trained. What you want is your face to be the concept that's trained
and everything else to be diverse, like different. - So diverse lighting as well, diverse everything. - Yeah, outside, inside.
But there's no, like, this is the problem. There's no like manual for this, and nobody knew. We were all just...
Especially two years ago, we're all hacking, trying to test anything. Anything you can think of.
And it's frustrating. It's one of the most frustrating and also fun and challenging things to do because with AI,
'cause it's a black box. And like Karpathy, I think says this.
We don't really know how this thing works, but it does something. But nobody really knows why, right?
We cannot look into the model of an LLM, like what is actually in there. We just know it's a 3D matrix of numbers, right?
So it's very frustrating, 'cause some things you... You think they're obvious that they will improve things will make them worse.
And there's so many parameters you can tweak. So you're testing everything to improve things.
- I mean there's a whole field novel of mechanistic interpretability that like studies that tries to figure out,
tries to break things apart and understand how it works. But there's also the data side
and the actual like consumer facing product side of figuring out how you get it to generate a thing
that's beautiful or interesting or naturalistic, all that kind of stuff. - Yeah. - And you're like at the forefront
of figuring that out about the human face. - Yeah. - And humans really care about the human face. - They're very vain.
(Lex laughs) - Like me, I want to look good on your podcast- - Yeah. - For example. - Yeah, for sure. - And then one of the things I actually would love to
like rigorously use Photo AI, because for the thumbnails, I take portraits of people.
I don't a shit about photography. I basically used your approach for photography. I like Google.
How do you take photographs? - Yeah. - Camera, lighting. And also it's tough
because maybe you could speak to this also, but with photography, no offense, Danny,
they're true artists, great photographers. But people take themselves way too seriously.
Think you need a whole lot of equipment. You definitely don't want one light, you need like five lights.
- Man, I know this. - And you have to have like the lenses.
And I talked to a guy, an expert of shaping the sound in a room, okay?
Because I was thinking, I'm gonna do a podcast studio, whatever, I should probably treat,
do a sound treatment on the room. And when he showed up and analyzed the room,
he thought everything I was doing was horrible. And then that's when I realized like, you know what?
I don't need experts in my life. - You kick him outta the house. - No, I didn't kick them. I mean, I said thank you, thank you very much.
- Thank you. Great tips, bye. - I just felt like there is...
Focus on whatever the problems are. Use your own judgment, use your own instincts. Don't listen to other people,
and only consult other people when there's a specific problem. And you consult them, not to offload the problem onto them,
but to gain wisdom from their perspective. Even if their perspective is ultimately one you don't agree with,
you're gonna gain wisdom from that. I ultimately come up with like a PHP solution.
PHP and jQuery solution- - PHP studio. - PHP studio. I have a little suitcase,
I use just the basic sort of consumer type of stuff.
One light, it's great. - Yeah, and look at you, you're like one of the top podcasts in the world and you get millions of views and it works.
And the people that spend so much money on optimizing for the best sound for the best studio, they get like 300 views.
So what is this about? This is about that either you do really well or also that a lot of these things don't matter.
What matters is probably the content of the podcast. - [Lex] Yeah. - You get the interesting guests - Focus on stuff that matters.
- Yeah, and I think that's very common. They call it Gear Acquisition Syndrome. Guests, like people in any industry do this,
they just buy all the stuff. There was a meme recently. What's the name for the guy that buys all the stuff before he even started doing the hobby, right?
Marketing. Marketing does that to people. They wanna buy this stuff. - Yeah. - But like, man,
you can make a Hollywood movie on an iPhone. If the content is good enough, and it will probably be original
because you would be using an iPhone for it. - That said, so the reason I brought that up
with photography. There is wisdom from people and one of the things I realized,
you probably also realized this, but how much power light has to convey emotion.
Just take one light and move it around. See you're sitting in the darkness, move it around your face.
The different positions are having a second light potentially, you can play with how a person feels just from a generic face.
- Yeah. - It's interesting. You can make people attractive, you can make 'em ugly, you can make them scary, you can make them lonely.
All of this. - Yeah. - And so you kind of start to realize this. And I would definitely love AI help
in creating great portraits of people. - Guest photos, yeah. - Guest photos, for example.
That's a small use case. But for me,
I suppose it's an important use case because I want people to look good but I also wanna capture who they are.
Maybe my conception of who they are, what makes them beautiful. - Yeah. - What makes their appearance powerful in some ways.
Sometimes it's the eyes, oftentimes it's the eyes, but there's certain features of the face can sometimes be really powerful.
It's also kind of awkward for me to take. - Yeah, yeah, yeah. - Photographs. So I'm not collecting enough. - Yeah.
- Photographs for myself to do it with just those photographs. If I can load that off onto AI
and then start to play with lighting all that stuff. - Man, you should do, and you should probably do it yourself. You can use Photo AI,
but it's even more fun if you do it yourself. So you train models, you can learn about like control nets.
Control net is where, for example, your photos in your podcast are usually like from the angle, right? So you can create a control net face post
that's always like this. So every model, every photo you generate uses this control net photos, for example.
I think would be very fun for you to try out that something. - Do you play with lighting at all? Do you play with lighting, with pose with the? - Man, actually, like this week
or recently, there's some new model came out that can adjust the light of any photo.
But also AI image with Stable Diffusion. I think it's called Relight.
And it's amazing. You can upload kinda like a light map.
So for example, red, purple, blue, and use the light map to change the light on the photo you input.
It's amazing. So there's for sure a lot of stuff you can do. - What's your advice for people in general on how to learn
How to learn AI
all this state-of-the-art AI tools available? You mentioned the new models coming out all the time.
- Yeah. - How do you pay attention? How do you stay on top of everything?
- I think you need to join Twitter X. X is amazing now and the whole AI industry is on X,
and they're all like anime avatars. So (chuckles) it's funny, 'cause my friends ask me this.
Who should I follow to stay up to date? And I say go to X, and follow all the AI anime models
that this person is following or follows. And I send them something URL, and they all start laughing like, what is this?
But they're real like people hacking around in AI. They get hired by big companies and they're on X,
and most of 'em are anonymous. It's very funny. They use anime avatar, I don't,
but those people hack around and then they publish what they're discovering. They talk about papers, for example.
So yeah, definitely X. - It's great. I almost exclusively all the people I follow are AI people.
- Yeah, it's a good time now. - Well, but also just brings happiness to my soul,
'cause there's so much turmoil on Twitter. - Yeah, politics and stuff. - There's battles going on.
It's like a war zone, and it's nice to just go into this happy place to where people are building stuff.
- Yeah, 100%. I like Twitter for that most like building stuff, like seeing other. 'Cause it inspires you to build
and it's just fun to see other people share what they're discovering and then you're like,
okay, I'm gonna make something too. It's just super fun. And so if you wanna start going X and then I would go to Replicate,
and start trying to play with models. And when you have something that kind of, you manually enter stuff,
you set the parameters, something that works, you can make an app out of it or a website. - Can you speak a little bit more to the process
of it becoming better and better and better Photo AI. - So I had this Photo AI, and a lot of people using it. There was like a million
or more photos a month being generated. And I discovered I was testing
parameters like increase the step count of generating a photo or chasing the sampler, like a scheduler.
You have DPM++2 Karras all these things I don't know anything about, but I know that you can choose them and you generate image
and they have different resulting images. But I didn't know which one were better. So I would do it myself, test it.
But then I was like, why dot I test on these users? 'Cause I have a million photos generated anyway. So unlike 10% of the users,
I would randomly test parameters, and then I would see if they would, 'cause you can favor the photo or you can download it.
I would measure if they favorite or like the photo. And then I would AB test, and you test for significance and stuff,
which parameters were were better and which were worse? - So you start starting to figure out which models are actually working well.
- Exactly, and then if it's significant enough data, you switch to that for the whole, you know, all the users. And so that was like the breakthrough to make it better.
Just use the users to improve themselves. And I tell them when they sign up, we do sampling, we do testing on your photos of random parameters,
and that worked really well. I don't do a lot of testing anymore because it's like, I kind of reached a diminishing point where it's like,
it's kind of good, but there was a breakthrough, yeah. - So it's really about the parameters,
the models that choose and letting the users help do the search in the space of models
and parameters for you. - Yeah, yeah. But actually, so like Stable Diffusion, I used 1.52, 2.0 came out
as Stable Diffusion Excel came out, all these new versions and they're all worse. And so the core scene of people are still using 1.5
because it's also not like, what do you call neutered? They neutered to make it super like,
with safety features and stuff. - Yeah. - So most of the people are still on Stable Diffusion 1.5
and meanwhile Stable Diffusion, the company went like, the CEO left.
A lot of drama happened. - Yeah. - Because they couldn't make money, and yeah, so it's very interesting,
they gave us this open source model that everybody uses. They raised like hundreds of millions of dollars.
They didn't make any money, there are not a lot. And they did amazing job. And now everybody uses open source model for free.
It's amazing. It's amazing. - You're not even using the latest one, you're saying? - No, and the strange thing is that this company raised hundreds of millions,
but the people that are benefiting from it are really small. People like me who make these small apps that are using the model.
And now they're starting to charge money for the new models. But the new models are not so good for people. They're not sell open source, right?
- Yeah, it is interesting because open source is so impactful in the AI space,
but you wonder like what is the business model behind that? But it's enabling this whole ecosystem of companies that-
- [Pieter] Yeah, yeah. - They're using the open source models. - So it's kinda like this frameworks, but then they didn't bribe enough influence to use it,
and they didn't charge money for the platform. - Okay, so back to your book and the ideas.
We didn't even get to the first step. Generating ideas, so you had notebook,
and you're filling it up. How do you know when an idea is a good one? You have this just flood of ideas.
How do you pick the one that you actually try to build? - Man, mostly you don't know. Mostly, I choose the ones
that are most viable for me to build. I cannot build a space company now, right? It would be quite challenging.
But I can build something. - Did you actually write down like space company? - No, I think asteroid mining would be very cool.
'Cause like you go to an asteroid, you take some stuff from there, you bring it back, you sell it, you know.
But then you need to do... And you can hire someone to launch the thing. So all you need is like the robot that goes to the asteroid,
and the robotic is interesting. I wanna also learn robotics. So maybe that could be.
- I think both the asteroid mining and the robotics is- - Yeah. - Together.
- I feel like. - No, exactly, this is it. - It says- - We do this not because it's easy,
but because we thought it would be easy. Exactly- - Asteroid mining. - That's me with asteroid mining. Exactly. (Lex laughs)
That's why I should do this. - It's not nomadlist.com. (laughs) - No, it's not. - It's asteroid mining.
You have to like build stuff. Gravity is really hard to overcome. - Yeah, but it seems...
Man, I sound like idiots, probably not. But it sounds quite approachable, relatively approachable. You don't have to build a rocket issue.
- Oh, you use something like SpaceX to get out the space. - Yeah, you hire SpaceX to send your, you know, this dog robot or whatever.
- So is there actually existing notebook where you wrote down asteroid mining? - No, back then I used Trello. - Trello. - Yeah.
But now I don't really, I used Telegram. I rather than like saved messages and I have like idea, I write it down.
- You type to yourself on Telegram? - 'Cause you use WhatsApp, right? I think, so you have messages to yourself, thing also, yeah, it's like a notepad.
- So you're talking to yourself on Telegram. - Yeah, you use like a Notepad, to not forget stuff. And then I pin it. - I love how like you're not using
super complicated systems or whatever. People use Obsidian now. There's a lot of these-
- A notion where you have systems for note taking. Your notepad, your notepad.exe guy.
If you're those user- - Yeah. Man, I saw some YouTubers doing this. There's a lot of these productivity gurus also.
And they do this whole iPad with a pencil. And then I also had an iPad and I also got the pencil and I got this app where you can like draw on paper.
Like a calendar. - Yeah. - People's students uses and you do coloring and stuff. And I'm like, dude, I did this for a week.
And then I'm like, what am I doing in my life? I could just write it as a message to myself and it's good enough.
- Speaking of ideas, you shared a tweet explaining why the first idea sometimes might be a brilliant idea.
The reason for this you think is the first idea submerges from your subconscious, and was actually boiling your brain for weeks, months,
sometimes years in the background. The eight hours of thinking can never compete with a perpetual subconscious background job.
So this is the idea that if you think about an idea for eight hours versus like the first idea that pops into your mind. - Yeah. - And sometimes
there is subconscious, like stuff that you've been thinking about for many years.
That's really interesting. - Yeah, I mean like emerges. I wrote it wrong because I'm not native English, but it emerges from your subconscious, right?
It comes from the like a water, your subconscious in here, it's boiling, and then when it's ready it's like ding.
It's like a microwave comes out and there you have your idea. - You think you have ideas like that? - Yeah, all the time, 100%.
- It's just stuff that's been like there. - Yes. - Yeah. - And also, it comes up and I bring it, I send it back,
like send it back to the kitchen- - Not ready yet. - To boil more. - Yeah. - And it's like a soup of ideas that's cooking.
It's 100%. This is how my brain works, and I think most people. - But it's also about the timing. Sometimes you have to send it back,
not just because you're not ready, but the world is not ready. - Yeah, so many times, startup founders are too early with their idea.
Yeah, 100%. - Robotics is an interesting one for that because like there's been a lot of robotics companies that failed.
Robots
- [Pieter] Yeah. - Because it's been very difficult to build, a robotics company, make money, 'cause there's the manufacturing, like the cost of everything.
The intelligence of the robot is enough, is not sufficient to create a compelling enough product from
which to make money. So there's this long line of robotics companies that have tried, they had big dreams and they failed.
- Yeah, like Boston Dynamics. I still don't know what they're doing, but they always upload YouTube videos, and it's amazing.
But I feel like a lot of these companies don't have a, it's like a solution looking for a problem for now. Military obviously use this,
do I need like a robotic dog now for my house? I don't know. It's fun, but it doesn't really solve anything yet.
I feel the same kinda VR, like it's really cool. Apple Vision Pro is very cool. It doesn't really solve something for me yet.
And that's kind of the tech looking for a solution, right? But one day, will. - When the personal computer,
when the Mac came along, there's a big switch that happened. It somehow captivated everybody's imagination
and like the application, the killer apps became apparent, you can type in a computer.
- But take became apparent like immediately. Back then they also had like this thing where like, we don't need these computers.
They're like a hype. And it also went like in kinda like waves.
- Yeah, yeah, but the hype is the thing that allowed the thing to proliferate sufficiently to where people's minds would start
opening up to it a little bit. - Yeah. - The possibility of it. Right now, for example, with the robotics, there's very few robots in the homes of people.
- Exactly, yeah. - The robots that are Roombas, so the vacuum cleaners or they're Amazon Alexa.
- Yeah, or dishwasher. I mean it's essentially a robot. - Yes, but the intelligence is very limited. - Yeah.
- I guess is one way we can summarize all of them. Except Alexa, which is pretty intelligent, but is limited with the kind of ways it interacts with you.
That's just one example. - Yeah. - I sometimes think about that as like, if some people in this world were
kind of born in the whole existence is like they were meant to build the thing.
- Yeah. - I think I sometimes wonder like what I was meant to do.
Because you have these plans for your life, you have these dreams. - I think you're meant to build robots.
- Okay, me personally. (Pieter and Lex laughs) Maybe, maybe. That's a sense of habit,
but it could be other things. It could hilariously not be the thing I was meant to be is to talk to people.
- Yeah. - Which is weird, because I always was anxious about talking to people. It's like a- - Really? - Yeah, I'm scared of this.
I was scared is (laughs) yeah, exactly. - I'm scared of you as well. (Lex laughs) - It's just anxiety throughout,
social interaction in general. I'm an introvert that hides from the world, so yeah. It's really strange.
- Yeah, but that's also kinda life. Life brings you to, it's very hard to super intently kind of choose
what you're gonna do with your life. It's more like surfing. You're surfing the waves. You go in the ocean,
you see where you end up. - Yeah, yeah. And there's universe has a kind of sense of humor.
- [Pieter] Yeah. - I guess you have to just, yeah, allow yourself to be carried away by the ways. Yeah. - Exactly, yeah, yeah.
- Have you felt that way in your life? - Yeah, all the time. Yeah, I think that's the best way to live your life.
- So allow whatever to happen. Do you know what you're doing in the next few years? Is it possible that it'll be completely,
like changed? - Possibly. I think relationships, you wanna hold relationships, right? You wanna hold your girlfriend,
you wanna become wife and all this stuff. I think you should stay open to where,
like for example, where you wanna live. I don't know, we don't know where we wanna live, for example. That's something that will figure itself out.
It will crystallize where you will get sent by the waves to somewhere
where you only live, for example, what you're gonna do. I think that's a really good way to live your life. I think most stress comes from trying to control,
like hold things... It's kind of Buddhist. You need to like lose control, let it loose.
And things will happen. When you do mushrooms, when you do drugs, like psychedelic drugs. The people that start,
that are like control freaks get bad trips, right? 'Cause you need to let go. I'm pretty control freak actually.
When I did mushrooms when I was 17, it was very good. And then at the end it wasn't so good, 'cause I tried to control it was like,
ah, now it's going too much. Let's stop. Bro, you can't stop it. You need to go through with it.
And I think it's a good metaphor for life. I think that's very tranquil way to lead your life. - Yeah, actually when I took Ayahuasca,
that lesson is deeply within me already that you can't control anything.
- [Pieter] Yes. - I think I probably learned that the most in jiu-jitsu. So just let go and relax. - Yeah.
- And that's why I had just an incredible experience. There's like literally no negative aspect of my Ayahuasca experience
or any psychedelics I've ever had. Some of that could be with my biology and my genetics, whatever. But some of it was just not trying to control.
- Yeah. - Just surf the wave. - For sure. I think most stress in life comes from trying to control.
- So once you have the idea- - Yeah. - Step two, build. How do you think about building
the thing once you have the idea? - I think you should build with the technology that you know. So for example, Nomad List,
which is like this website I made to figure out the best cities to live and work as digital nomad.
It wasn't a website, it launched as a Google spreadsheets. So it was a public Google spreadsheet. Anybody could edit.
And I was like, I'm collecting cities where we can live with as nomads, with the internet speeds, the cost of living, other stuff.
And I tweeted it, and back then I didn't have a lot of followers. I had like a few thousand followers or something.
And I went like viral for my skill viral back then, you know, which was like five retweets. And a lot of people started editing it.
And there was like hundreds of cities in this list, from all over the world with all the data. It was very crowdsourced. And then I made that into a website.
So figuring out like what technology you can use that you already know. So if you cannot code, you can use a spreadsheet.
If you cannot use a spreadsheet, like whatever, you can always use a, for example,
a website generator like Wix or something or Squarespace, right? You don't need to code to build a startup.
All you need is idea for a product. Build something like a landing page or something.
Put a Stripe button on there and then make it. And if you can code, use the language that you already know
and start coding with that and see how far you can get. You can always rewrite the code later. The tech stack is not actually,
it's not the most important of a business when you're starting on a business. The important thing is that you validate that there's a market,
that there's a product that people wanna pay for. So use whatever you can use. And if you cannot code,
use spreadsheets, landing page generators, whatever. - Yeah, and the crowdsourcing element is fascinating.
It's cool, it's cool when a lot of people start using it. You get to learn so fast. - Yeah. - I've actually did the spreadsheet thing.
You share a spreadsheet publicly and I made it editable. - Yeah. - It's so cool.
- [Pieter] Interesting things start happening. - Yeah, I did it for like a workout thing, 'cause I was doing a large
amount of pushups and pull ups every day. - Yeah, I remember this man, yeah. - (laugh) And well, I had Google Sheets is pretty limited
and that everything is allowed. So people could just write anything in any cell and they can create new sheets.
- Yeah. - New tabs. And it just exploded. And one of the things
that I really enjoyed is there's very few trolls because actually other people would delete the trolls.
There would be like this weird war- - Army, yeah. - Of like. They want like to protect the thing.
It's an immune system that's inherent to the thing. - It comes to society. - Yeah. - In the spreadsheets. - And then there's the outcast
who go to the bottom of the spreadsheet and they would try to hide messages, and they like, I don't wanna be with the cool kids up at the top of the spreadsheet,
so I'm gonna at the bottom. - Self-harmonizing. - Yes. - It's insane. - It's fast. I mean, but that kind of crowdsourcing element is really powerful.
And if you can create a product that use that to his benefit, that's really nice.
Any kind of voting system, any kind of rating system for A and B testing is really- - Yeah. - Really, really fascinating. So anyway, so Nomad List is great.
Hoodmaps
I would love for you to talk about that. But one sort of way to talk about it is
through you building Hoodmaps. - Yeah. - So you did an awesome thing,
which is document yourself building the thing and doing so in just a handful of days,
like three, four, five days. So people should definitely check out the video in the blog post.
Can you explain what Hoodmaps is and what this whole- - Yeah. - This process was? - So I was traveling, and I was still trying to find problems, right?
I would discover that like everybody's experience of a city is different because they stay in different areas.
- Yeah. - So I'm from Amsterdam and when I grew up in Amsterdam or I didn't grow up, but I lived there, in university,
I knew that center is like in Europe, the centers are always tourist areas. So they're super busy,
they're not very authentic. They're not really Dutch culture, it's Amsterdam tourist culture. So when people would travel to Amsterdam would say,
don't go to the center, go to Southeast of the center, Jordaan or the De Pijp or something,
more hipster areas. A little more authentic culture of Amsterdam. That's where I would live, and where I would go.
And I thought this could be like an app where you can have like a Google maps and you put colors over it. You have areas that are like color code.
Red is tourists, green is rich, green money, yellow is hipster. You can figure out where you need to go
in the city when you travel, 'cause I was traveling a lot. I wanted to go to the cool spots. - So just use color. - Yeah. Color, yeah.
Yeah, and I would use a Canvas. So I thought, okay, what do I need? I need to- - Did you know that you would be using a Canvas?
- No, I didn't know it was possible, 'cause I didn't know. - So this is the cool thing. People should really check out. - This is how it started.
- Because you're honestly capture so beautifully, the humbling aspects,
the embarrassing aspects of like not knowing what to do. It's like how do I do this? And you document yourself.
Yeah, you're right. Dude, I feel embarrassed about myself. (laughs) - Oh, really, yeah. - It's called being alive.
Nice. So you're like, you don't know anything about, so Canvas is a HTML5 thing
that allows you to draw shapes. - Yeah, draw images. Just draw pixels essentially so. - Yeah. - And that was special back then.
Because before you could only have like elements, right? So you wanna draw a pixel, use a Canvas. And I knew I needed to draw pixels
'cause I need to draw these colors. And I felt like, okay, I'll get like a Google maps iframe embed,
and then I'll put a Dave on top of it with the colors, and I'll do like opacity 50, so it kind of shows.
So I did that with Canvas. And then I started drawing, and then I felt like, obviously, other people need to edit this
'cause I cannot draw all these things myself. So I crowdsource it again,
and you would draw on the map and then it would send the pixel data to the server. It would put it in the database,
and then I would have a robot running like a cron job, which every week would calculate, or every day would calculate.
Okay, so Amsterdam Center, there's like six people say, it's tourist, this part of the center,
but two people say, it's like hipster. Okay, so the tourist part wins, right? It's just an array. So find the most common value
in a little pixel area on a map. So if most people say it's tourists, it's tourists,
and it becomes red. And I would do that for all the GPS corners in the world. - Can we just clarify- - Yeah.
- As a human that's contributing to this, do you have to be in that location to make the label or do you? - No, people just type in cities and go like,
go berserk and start drawing everywhere. - Would they draw shapes or would they draw pixels? - Man, they drew like crazy stuff. Like offensive symbols.
I cannot mention they would draw penises. - I mean, that's obviously a guy thing. - I would do the same thing, draw penises.
- That's the first thing. (Pieter laughs) When I show up to Mars and there's no cameras, I'm drawing penis on the sand. - Man, I did it in the snow, you know,
but the penises did not become a problem, 'cause I knew that not everybody would draw a penis and not in the same place.
So most people would use it fairly. So just if I had enough crowdsource data. So you have all these pixels on top of it.
It's like a layer of pixels. - Yeah. - And then you choose the most common pixel. So yeah, it's just like a bowl, but in visual format.
And it worked and within a week got enough data, and it was like cities that did really well,
like Los Angeles, a lot of people started using it. Like most data's in Los Angeles. - Because Los Angeles has defined neighborhoods.
- Yeah. - And not just in terms of the official labels, but like what they're known for.
- [Pieter] Yeah. - Did you provide the categories that they were allowed to use as labels?
- The colors, yeah. - As colors. - So I think you can see there, there's like hipster, tourist, rich, business.
There's always a business area, right? And then there's a residential. Residential is gray. So I thought those were the most common things
in the city kind of. - And a little bit meme, like it's almost fun to label it as that, right? - Yeah. I mean obviously, it's simplified,
but you need to simplify this stuff. You don't wanna have too many categories. And it's essentially just like using a paint brush
where you select the color in a bottom, you stick the category and you start drawing. There's no instruction. There's no manual.
And then I also added tagging so people could like write something on a specific location.
So don't go here or here's like nice cafe and stuff.
And man, the memes that came from that. And I also had upvoting, so that the tags could be upvoted.
So the memes that came from that is like amazing. People in Los Angeles would write crazy stuff. It would go viral in all these cities.
You can allow your location and will probably send you to Austin. - (laughs) Okay, so we're looking,
(laughs) oh boy, drunk hipsters.
- AirBroNBros. - AirBroNBros. - Gentrifiers. - Hipster girls who do cocaine.
- I saw a guy in a fish costume get beaten up here. - Yep, that seems also accurate. - Overpriced and underwhelming.
- (laughs) Let me see, let me make sure this is accurate.
Let's see. Dirty Sixth for people who know Austin
know that that's important to label. Sixth Street is famous in Austin. Dirty Sixth drunk frat boys, accurate.
Drunk frat bros. Continued on sixth, very well -known. - West Sixth douchebros. - West Sixth douchebros.
- They go from frat to douche. - Douche. I mean it's very accurate so far. - Really.
- They only let hot people live here. (laughs) I think that might be accurate.
- It's like the district. Exercise freaks on the river. Yeah, that's true. - Dog runners accurate. - Yeah.
- Saw a guy in the fish costume get beat up here. - I wanna know the story. - So that's all user contributed.
- Yeah, and that's like stuff I couldn't come up with it, 'cause I don't know Austin, I don't know the memes here in the subcultures.
- And then me as a user can upload or down vote this. - [Pieter] Yes. - So this is completely crowdsourced. - It's like 'cause of Reddit upvote, downvote,
took it from there. - That's really, really, really powerful. Single people with dogs, accurate.
At which point did it go from colors to the actually showing the text? - I think I added the text like a week after.
And so here's like the pixels. - So that's really cool. The pixels, how do you go from that? That's a huge amount of data. - Yeah.
- Now looking at an image where it's just a sea of pixels that call it different colors.
- Yeah. - In a city. So how do you combine that to be a thing that actually makes it some sense? - I think here the problem was that you have this data,
but it's like it's not locked to one location. - Yeah. - So I had to normalize it.
So when you click, when you draw on a map, it will show you the specific pixel location and you can convert the pixel location
to a GPS coordinate, right? Like latitude, longitudes. But the number will have a lot of commas or a lot of decimals, right?
Because it's very specific, it's like this specific part of the table. So what you wanna do is you wanna take that pixel
and you wanna normalize it by removing like decimals, which I discovered, so you're talking about this neighborhood,
or this street, right? And so that's what I did. I just took the decimals off and then I saved it like this. And then it starts going to like a grid.
And then you have like a grid of data. You get like a pixel map kind of. - And then you said it looks kind of ugly,
so then you smooth it. - Yeah, I started adding blurring and stuff. I think now it's not smooth again,
'cause I liked it better. People like the pixel look kinda. Yeah, a lot of people use it and it keeps going viral.
And every time my maps bill like Mapbox, I had to stop using... You first use Google Maps, it went viral,
and Google Maps, it was out of credits. It's so funny,
when I launched it, it went viral. Google Maps, the map didn't load anymore. It says over the limits,
you need to contact enterprise sales. But I need now like a map. And I don't wanna contact enterprise sales.
I don't wanna go on a call schedule with some calendar. So I switched to Mapbox, and then had Mapbox for years,
and then it went viral and I had a bill of $20,000 was like last year.
So they helped me with the bill. They said, "You can pay less." And then I now switched to like a open source
kind of map platform. So it's a very expensive product and never made any dollar money.
But it's very fun. But it's very expensive. - What do you learn from that? So like from that experience,
'cause when you leverage somebody else's through the API. - Yeah, I mean I don't think a map hosting service
should cost this much. But I could host it myself, but that would be...
I dunno how to do that, but I could do that. - Yeah, it's super complicated. - I think that the thing is more about like,
you can't make money with this project. I tried to do many things to make money with it and it hasn't worked.
You talked about like possibly doing advertisements on it or some somehow. - [Pieter] Yeah. - Or people sponsoring it, yeah.
It's really surprising to me that people don't want to advertise on it. - I think map apps are very hard to like monetize.
Google Maps also doesn't really make money. Sometimes you see these ads, but I don't think there's a lot of money there.
You could put like a banner ad but it's kind of ugly, and the product is kind of like, it's kind of cool. So it's kinda fun to like subsidize it.
And it's kinda a little bit part of Nomad List. I put it on Nomad List in the cities as well. But I also realized,
you don't need to monetize everything. Some products are just cool and it's cool to have Hoodmaps exist.
I want this to exist, right? - Yeah, there's a bunch of stuff you've created that I'm just glad exists in this world.
That's true. And it's a whole nother puzzle. And I'm surprised to figure out how to make money off of it.
I'm surprised maps don't make money, but you're right, it's hard. It's hard to make money. - Yeah. - 'Cause there's a lot of compute required
to actually bring it to life. - Also, where do you put the ad, right? If you have a website, you can put an ad box
or you can do a product placement or something. But you're talking about a map app that where 90% of the interface is a map.
So what are you gonna do? It's hard to figure out where is this? - Yeah, and people don't wanna pay for it.
- No, exactly, because if you make people pay for it, you lose 99% of the user base and you lose the crowdsource data.
So it's not fun anymore. It stops being accurate, right? They pay for it by crowdsourcing the data,
but then, yeah, it's fine. It doesn't make money, but it's cool. - But that said, Nomad List makes money.
- Yeah. - So what was the story behind Nomad List? So Nomad List started because I was in Chiang Mai in Thailand,
which is now like the second city here. And I was working on my laptop.
I met like other nomads there, and I was like, okay, this seems like a cool thing to do, like working on your laptop in a different country,
kinda travel around. But back then the internet everywhere was very slow. So the internet was fast in,
for example, Holland or United States, but in a lot of parts in South America or Asia was very slow, like 0.5 megabits.
So you couldn't watch a YouTube video. Thailand weirdly had like quite fast internet.
But I wanted to find like other cities where I could go to like work on my laptop, whatever, and travel.
But we needed like fast internet. So I was like, let's crowdsource this information with a spreadsheet.
And I also needed to know the cost of living, 'cause I didn't have a lot of money. I had $500 a month. So I had to find a place where the rent was $200 per month
or something where I had some money that I could actually rent something
and there was Nomad List. And it still runs. I think it's now almost 10 years. - So it's just to describe how it works.
- [Pieter] Yeah. - I'm looking at Chiang Mai here. There's a total score, rank number two.
- Yeah, that's a number score. - 4.82 like by members. But it's looking at the internet.
In this case, it's fast. - Yeah. - Fun, temperature, humidity, air quality,
safety, food safety, crime, racism
or lack of crime, lack of racism, educational level, power grid, vulnerability, to climate change, income level.
- It's a little much. - English. It's awesome. It's awesome. Walkability. - Keep getting stuff. - Because for certain groups of people,
certain things really matter. And this is really cool. - Yeah. - Happiness. I'd love to ask you about that. Nightlife, free Wi-Fi, AC,
female friendly, freedom of speech. - Yeah, not so good in Thailand. - Values derived from national statistics.
(laughs) I like how that one. - I need to do that because the data sets are usually national. They're not on city level,
right? - Yes. - So I dunno about the freedom of speech between Bangkok or Chiang Mai. I know them in Thailand. - I mean this is really fascinating.
So this is for city? - Yeah. - Is basically rating all the different things that matter to you and internet.
And this is all crowdsourced. - Well, so started crowdsourced, but then I realized that you can download more
accurate data sets from like public source, like World Bank. They have a lot of public data sets, United Nations,
and you can download a lot of data there, which you can freely use. I started getting frauds crowdsource data where,
for example, people from India, they really love India, and they would submit the best scores
for everything in India. And not just like one person, but like a lot of people, they would love to pump India.
And I'm like, I love India too, but that's not valid data. So you started getting discrepancies in the data
between where people where from and stuff. So I started switching to data sets,
and now it's mostly data sets, but one thing that's still crowdsourced is, so people add where they are, they add their travels to their profile
and use that data to see which places are upcoming and which places are popular now. So about half the ranking you see here is based on
actual digital nomads who are there. You can click on the city, you can click on people, and you can see the people, the users that are actually there.
And it's like 30,000, 45,000 members. So these people are in Austin now. - 1,800 remote workers in Austin now.
- Yeah. - Of which 8+ members checked in. Members who will be here soon and go.
- Yeah, so we have meetups. - It's amazing. - So people organize their own meetups and we have about, I think like 30 per month.
So it's like one meetup a day. And I don't do anything. They organize themselves.
It's a whole black box. It just runs and I don't do a lot on it. It pulls data from everywhere and it just works.
- Cons of Austin. It's too expensive, very sweaty, and humid now. Difficult to make friends. - Difficult to make friends. Interesting, right?
I didn't know that. - Difficult to make friends- - In Austin. - But its all crowdsource, but mostly it's pros.
- Yeah, Austin's very- - Pretty safe, fast internet. - I understand why it says not safe for women to check the dataset.
It feels safe. The problem with a lot of places like United States is that it depends per area, right? - Yeah.
- So if you get like city level data or nation level data, it's like Brazil is the worst because the range in like safe and wealthy
and not safe is like huge. So you can't say many things about Brazil. - So once they actually show up to the city,
how do you figure out what area? Like where to get fast Internet. For example, for me, it's consistently a struggle
to figure out like- - Still. - Hotels with fast Wi-Fi, for example, like a place. Okay, okay, I show up to a city.
There's a lot of fascinating puzzles, and I haven't figured out a way to actually solve this puzzle. When I show up to a city,
figuring out where I can get fast internet connection
and for podcasting purposes where I can find a place with a table that's quiet. - Right, yeah, yeah.
- That's not easy. - Construction sounds. - All kinds of sounds. You get to learn about all the sources
of sounds in the world, and also the quality of the room because the emptier the room
and if it's just walls without any curtains or any of this kind of stuff, then there's echoes in the room anyway.
But you figure out that a lot of hotels don't have tables. They don't have like normal. - They have this weird desk, right?
- Yeah, they have- - But it's not a center table. - Yep, and if you want get a nicer hotel
where it is more spacious and so on. They usually have these like boutique, fancy looking, modernist- - Annoying tables.
- Tables, that don't- - Yeah, it's too designy. - It's too designy. - Yeah. - They're not really real tables. - What if you get Ikea?
- Buy Ikea? - Yeah, before you arrive you order an Ikea. - Yeah. - Nomads do this. They get desks. - I feel like you should be able to show up to a place
and have the desk. Unless you stay in there for a long time. Just the entire assembly, all that.
Airbnb is so unreliable. The range in quality that you get-
- Yeah. - Is huge. Hotels have a lot of problems, pros and cons.
Hotels have the problem that the pictures, somehow never have good representative pictures of what's actually going to be in the room.
- And that's the problem. Fake photos, man. - If I could have the kind of data you have
on Nomad List for hotels. - Yeah, yeah, man. - And I feel like you can make a lot of money on that too. - Yeah, the booking fees affiliate, right?
I thought about this idea, 'cause we have the same problem. I go to hotels, and there's specific ones that are very good
and I know now the chains and stuff, but even if you go to some chains are very bad
in a specific city and very good in other cities. - And each individual hotel has a lot of kinds of rooms. - Yeah.
- Some are more expensive, some are cheaper, and so on. But you can get the details of what's in the room.
What's the actual layout of the room, what is the view of the room. - You scan it. - I feel like as a hotel you can win a lot.
So first, you create a service that allows you to have high resolution data about a hotel,
then one hotel signs up for that. I would 100% use that website to look for a hotel
instead of the crappy alternatives that don't give any information. And I feel like there'll be this pressure
for all the hotels to join that site and you could make a ton of money, 'cause hotels make a lot of money.
- I think it's true. But the problem is with these hotels, like it's same with airline industry. Why does every airline website suck
when you try book a flights? - Yeah. - It's very strange. Why does it have to suck? Obviously, there's competition here. Why doesn't the best website win?
- What's the explanation of that? - Man, I thought about this for years. So I think it's like I have to book the flight anyway.
I know there's a route that they take and I need to book, for example, Qatar Airlines, and I need to get through this process.
And with a hotel similar, you need a hotel anyway. So do you have time to like figure out the best one?
Not really. You kind of just need to get the place booked and you need to get the flight and you'll go through the pain of this process.
And that's why this process always sucks so much for hotels and airline websites and stuff. Because they don't have an incentive to improve it,
because generally only for a super upper segment of the market, I think super high luxury,
it affects the actual booking, right? - I don't know. I think that's an interesting theory.
I think that must be a different theory. My theory would be that great engineers,
great software engineers are not allowed to make changes. - [Pieter] Yeah. - Basically, there's some kind of bureaucracy,
there's way too many managers. There's a lot of bureaucracy. And great engineers show up,
they try to work there and they're not allowed to really make any contributions and then they leave. And so you have a lot of mediocre software engineers,
they're not really interested in improving any other thing. - [Pieter] Yeah. - And literally, they would like to improve the stuff, but the bureaucracy of the place,
plus all the bosses, all the high up people are not technical people probably. - [Pieter] Yeah.
- They don't know much about web dev. They don't know much about programming. So they just don't give any respect.
- Yeah. - You have to give the freedom and the respect to great engineers
as they try to do great things. That feels like an explanation. If you were a great programmer,
would you wanna work at America Airlines or? - No, no.
- I'm torn on that 'cause I actually as somebody who loves program, would love to work at America Airlines
so I can make the thing better. - Yeah, I would work there just to fix it for myself. - Yeah, for yourself.
And then you just know how much suffering you're alleviated. - [Pieter] Yeah, yeah, for the world, for society.
- Just imagine all the thousands, maybe millions of people that go to that website. - Yeah. - And have to click
like a million times. It often doesn't work. It's clunky, all that kind of stuff. You're making their life just so much better.
- Much better, yeah. - Yeah. There must be an explanation that has to do with managers and bureaucracies.
- I think it's money. Do you know booking.com? - Sure. - So it's a booking. It's the biggest booking website in the world. - Yeah. - It's Dutch actually.
And they have teams because my friend worked there. They have teams for a specific part of the website, like a 10 by 10 pixels area where they run tests on this.
So they run tests like, and they're famous for this stuff. Oh, there's only one room left, right? Which is red letters. One room left book now.
And they got a fine from the European Union about this, kind of interesting. So they have all these teams and they run the test for 24 hours.
They go to sleep. They wake up next day they come to the office, and they see, okay, this performed better. This website has become a monster,
but it's the most revenue generating hotel booking website in the world. It's number one.
So that shows that it's not about user experience, it's about like, I don't know about making more money,
not every company. It's a public company, if they're optimizing for money.
- But you can optimize for money by disrupting, like making it way better. - Yeah, but it's always start, they start with disrupting.
Booking all started as a startup 1997. And then they become like the old shit again.
Uber now starts to become a taxi again, right? It was very good in the beginning. Now it's kind of like taxis now in many places are better.
They're nicer than Ubers, right? So it's like this circle. - I think some of it is also just,
it's hard to have ultra competent engineers. - Yeah. - Stripe seems like a trivial thing,
but it's hard to pull off. - Yeah. - Why was it so hard for Amazon to have buy with one click?
Which I think is a genius idea. - Yeah. - Make buying easier.
Make it as frictionless as possible. Just click a button once thing you bought the thing.
- [Pieter] Yeah. - As opposed to most of the web was a lot of clicking, and it often doesn't work. - Yeah. - Like with the Airlines.
- Remember the forms would delete, you could click Next, Submit, and 404 or something where your internet would go down.
- Yeah. - Your modem. - Yeah. - That, man. - And I would have an existential crisis. The frustration would take over my whole body.
- [Pieter] Yes. - And I would just wanted to quit life for a brief moment there. - Yeah. - Yeah. - I'm so happy to form stays in Google Chrome
now when something goes wrong. So Google, somebody at Google improve society with that, right?
- Yeah, and one of the challenges of Google is to have the freedom to do that. - They don't anymore.
- There's a bunch of bureaucracy, yeah. - Yeah, at Google. - There's so many brilliant, brilliant people there. - Yeah. - But it just moves slowly. - Yeah.
- And I wonder why that is, and maybe that's the natural way of a company, but you have people like Elon who rolls in
and just fires most of the folks and always operate, like push the company to operate as a startup,
even what's already big. - Yeah, I mean, Apple does this. I like I started in business school, Apple does competing product teams that operate as startups.
So three to five people, they make something, they have multiple teams do make the same thing. The best team wins.
I think you need to emulate like a free market inside a company to make it entrepreneurial. - Yeah. - And you need
entrepreneurial mentality in a company to come up with new ideas and do it better.
Learning new programming languages
- So one of the things you do really, really well is learn. And you think like you're trying to...
You have an idea, you try to build it, and then you learn everything you need to in order to build it.
You have your current skills, but you need learn just the minimal amount of stuff. So you're a good person to ask like,
how do you learn? How do you learn quickly and effectively and just the stuff you need?
Just by way of example, you did a 30 days learning session on 3D. - [Pieter] Yeah.
- Where you documented yourself, giving yourself only 30 days to learn everything you can about 3D. - Yeah, I tried to learn virtuality
'cause I was like... This was same as AI, it came up suddenly like 2016, 2017, with I think HTC VIVE,
this big VR glasses before Apple Vision Pro. I was like, oh, this is gonna be big, so I need to learn this.
I know nothing about 3D. I installed like, I think Unity, and Blender and stuff.
And I started learning all this stuff because I thought this was like a new
nascent technology that was gonna be big. And if I had the skills for it, I could use this to build stuff.
And so I think with learning for me, I think learning is so funny 'cause people always ask me,
"How do you learn to code?" Should I learn to code?" And I'm like, "I don't know." Every day I'm learning.
It's kind of cliche, but every day I'm learning new stuff. So every day I'm searching on Google or asking out ChatGPT,
how to do this thing, how to do this thing. Every day, I'm getting better at my skill. So you never stop learning.
So the whole concept of like how do you learn? Well, you never ends. So where do you want to be? Do you wanna know a little bit? Or do you wanna know a lot?
Do you wanna do it for your whole life? So I think taking action is the best step to learn. So making things like, you know nothing,
just start making things. Okay, so like how to make a website? Search how to make a website. Or nowadays you ask ChatGPT,
how do I make a website? Where do I start? It generates codes for you, right? Copy the code, put it in a file, save it, open it in Google Chrome or whatever.
You have a website and then you start tweaking with it, and you start, okay, how do I add a button? How do I add AI features, right, nowadays.
So it's like by taking action, you can learn stuff much faster than I'm reading books, or tutorials.
- Actually, I'm curious, let me ask perplexity. How do I make a website?
I'm just curious what it would say. I hope it goes with like really basic vanilla solutions.
Define your website's purpose. Choose a domain name. Select a web hosting provider. Choose a website or builder or CMS,
website build a platform Wix. - Tells that Wix or Squarespace is what I said. - Yeah. - The landing page.
- How do I say if I wanna program it myself? Design your website, create essential pages.
- Yeah, even tells you to launch it, right? Start promoting it. - Launch your website. - Cool. - Well, I mean you could do that. - Yeah, but this is literally it.
- [Lex] If you wanna make a website. - This is the basic like Google Analytics, - Well, you can't make Nomad List with this way. - You can. - With Wix.
- No, you can get pretty far, I think. - You get pretty far. - These website builders are pretty advanced. All you need is a grid of images, right?
- Yeah. - That are clickable. That open like another page. - Yeah. - You can get quite far. - How do I learn to program?
Choose a programming language to start with. - Yeah, FreeCodeCamp is good.
- Work through resources systematically, practice coding regularly for 30, 60 minutes a day.
Consistency is key. Join programming communities like Reddit's. Yeah, yeah. Yeah, it is pretty good.
- Yeah. - It's pretty good. - So I think it's a very good starting ground, 'cause imagine you know nothing
and you wanna make a website, you wanna make a startup. This is like, that's why, man, the power of AI for education is gonna be insane.
People anywhere can ask this question and start building stuff. - Yeah, it clarifies it for sure,
and just start building. Like keep- - Yeah. - Build, build. Like actually apply the thing, whether it's AI,
or any of the programming for web development. - Yeah. - Just have a project in mind,
which I love the idea of like 12 startups in 12 months or like build a project almost every day.
- Yeah. - Just build a thing. - Yeah. - And get it to work, and finish it every single day.
That's a cool experiment. - I think that was the inspiration. There was a girl who did 160 websites
and 160 days or something. Literally mini websites. - Yeah. - And she learned to code that way.
So I think it's good to set yourself challenges. You can go to some coding bootcamp,
but I don't think they actually work. I think it's better to do, for me, how to deduct like self-learning
and setting yourself like challenges and just getting in, but you need discipline. You need to discipline to keep doing it.
And coding is very, it's a steep learning curve to get in. It's very annoying.
Working with computers is very annoying. So it can be hard for people to keep doing it.
- Yeah, that thing of just keep doing it and don't quit, that urgency that's required to finish a thing.
That's why it's really powerful when you documented this, the creation of Hoodmaps or like a working prototype that there is
just a constant frustration I guess. It's like oh, okay, how do I do this? And then you look it up,
and you're like, okay, you have to interpret the different options you have. - Yeah, man. - And then just try it,
and then there's a dopamine rush of like, "Ooh, it works cool." - Man, it's amazing.
I live streamed it. It's on YouTube and stuff. People can watch it, and it's amazing when things work.
Look, it's just like a main that you, I look very not... I don't look far ahead. So I only look, okay, what's the next problem to solve,
and then the next problem? And at the end, you have a whole app or website or thing.
But I think most people look way too far ahead. It's like this poster again.
You don't know hard it's gonna be, so you should only look like for the next thing, the next little challenge, the next step.
And then see where you end up. - And as assume it's gonna be easy. (laughs) - Yeah, exactly.
Be naive about it. Because you're gonna have very difficult problems. A lot of the big problems won't be even tech,
will be like public, right? Maybe people don't like your website. You will get canceled for a website, for example.
A lot of things can happen. - What's it like building in public, like you do? Openly, where you're just iterating quickly
and you getting people feedback. So there's the power of the crowdsourcing, but there's also the negative aspects
of people being able to criticize. - So man, I think haters are actually good, 'cause I think a lot of haters have good points.
- Yeah. - And it takes like stepping away from the emotion of like, ah, your website sucks because blah, blah, blah.
And you're like, okay, just remove this. Your website sucks 'cause it's personal. What did he say? Why did he didn't not like it? And you figure out, okay, he didn't like it
'cause the signup was difficult or something, or it wasn't the data. They say, no, this data is not accurate or something, right?
Okay, I need to improve the quality of data. This hater has a point, because it's dumb to completely ignore your haters.
And also, man, I think I've been there when I was like 10 years old or something. You're on the internet just shouting crazy stuff
that's like most of Twitter, or the half Twitter. So you have to take it with grain of salt.
Yeah, man, you need to grow a very thick skin on Twitter, on X.
But I'm mute a lot of people. I found out I muted already 15,000 people recently, I checked.
So in 10 years, I muted 15,000 people. So that's like- - That's one by one manual. - Yeah. - Oh, wow.
- So 1,500 people per year. And I don't like to block, 'cause then they get angry, they make a screenshot and they say, ah, ah, you block me.
So I just mute and it disappear and it's amazing. - So you mentioned Reddit.
So Hoodmaps, did that make it to the front page of Reddit? - Yeah, yeah it did, yeah, yeah, yeah it did.
It was amazing. And my server almost went down, and I was checking like Google Analytics was like 5,000 people on the website or something crazy.
And it was at night and it was amazing. Man, I think nowadays, honestly, TikTok,
YouTube reels, Instagram reels. A lot of apps get very big from people making TikTok videos about it.
So let's say you make your own app, you can make a video for yourself. Oh, I made this app.
This is how it works, blah, blah, blah. And this is why I made it, for example. And this is why you should use it.
And if it's a good video, we'll take off, and you will get, man, I got like $20,000 extra per month
or something from a TikTok from one TikTok video. It made a Photo AI. - By you or somebody else? - By some random guy.
So there's all these AI influencers that they write about. They show AI apps and then they ask money later,
like when a video goes viral. I can do it again, and send me $4,000 or something. I'm like, okay, I did that, for example.
But it works. TikTok is a very big platform for user acquisition, yeah.
And Organic, like the best user acquisition I think is Organic. You don't need to buy ads. You probably don't have money when you start to buy ads.
So use Organic or write a banger, tweet, right? That's can make an app take off as well.
- Well, I mean yeah, fundamentally create cool stuff and have just a little bit of a following enough to like for the cool thing to be noticed.
And then it becomes viral if it's cool enough. - Yeah, and you don't need a lot of followers anymore on X and a lot of platforms
'cause TikTok X, I think in reels also, they have the same algorithm now. It's not about followers anymore,
it's about they test your content on a small subset, like 300 people. If they like it,
it will gets tested to a thousand people and on and on. So if the thing is good, it will rise anyway.
It doesn't matter if you have half a million followers or a thousand followers or hundred. - What's your philosophy of monetizing how to make money from the thing you build?
Monetize your website
- Yeah, so a lot of starters, they do like free users. So you could sign up and could use an app for free, which is...
It never worked for me well, because I think free users generally don't convert. And I think if you have VC funding,
it makes sense to get free users, because you can spend your funding on ads and you can get like millions of people come in predictably
how much they convert and give them like a free trial, whatever, and then they sign up. But you need to have that flow worked out so well
for you to make it work, that you need like... It's very difficult. I think it's best to start and just start asking people
for money in the beginning. So show your app, what are you doing on your landing page? Make a demo or whatever video.
And then if you wanna use it, pay me money, pay $10, $20, $40. I would ask more than $10 per month.
Netflix, like $10 per month. But Netflix is a giant company, they can afford to make it so cheap, relatively cheap.
If you're an individual, like an indie hacker, you are making your own app. You need to make like at least $30
or more on a user to make it worthy for you. You need to make money.
- And it builds a community of people that actually really care about the product. - Also, yeah. Making a community, making a discord very normal now.
Every AI app has a discord and you have the developers and the users together in a discord, and they talk about,
they ask for features they build together. It is very normal now. And you need to imagine like if you're starting out,
getting a thousand users is quite difficult, getting a thousand pages is quite difficult. And if you charge them like $30,
you have 30K a month, and it's a lot of money. - That's enough to like- - Live a good life. - Yeah, live a pretty good life.
I mean that could be a lot of costs associated with hosting. - Yeah, so that's another thing. I make sure my profit margin are very high.
So I try to keep the cost very low. I don't hire people.
I try to negotiate with AI vendors now, can you make it cheaper? I discovered this, you can just email companies
and say, "Can you give me discount? It's too expensive." And they say, "Sure, 50%." I'm like, "Wow, very good." (Lex laughs)
And I didn't know this, you can just ask. And especially in like now it's kind of recession, you can ask companies like, I need a discount
or I kind of need to like, you don't need to be asshole about it. Say, "I kind of need a discount or I need to go maybe to another company,
maybe discount here and there." And they say, "Sure." A lot of them will say yes. Like 25% discount, 50% discounts,
'cause you think the price on the website is the price of the API or something. It's not.
- And also you're a public facing person. - Oh, that helps also. - And there's love and good vibes
that you put out into the world. You're actually legitimately trying to build cool stuff. So a lot of companies probably wanna associate with you
because you're trying to do. - Yeah, it's like a secret hack, but I think even without- - Secret hack. Be a good person. - It depends how much discount they will give.
They'll maybe give more, but you know that's why you should post on Twitter so you get discounts maybe.
(Lex and Pieter laughs) - Yeah, yeah. And also when it's crowdsourced,
I mean paying does prevent spam or help prevent spam. - Also, yeah. Yeah, it gives you high quality users.
- High quality users. - Free users are sure, but they're horrible. It's just like millions of people,
especially with AI startups, you get a lot of abuse. So you get millions of people from anywhere just abusing your app, just hacking it and whatever.
- There's something on the internet. You mentioned like 4chan discovered Hoodmaps. - Yeah, but I love 4chan.
I don't love 4chan, but you know what I mean, like they're so crazy, especially back then.
It's kind of funny what they do. - I actually, what is it? This new documentary on Netflix "Antisocial Network"
or something like that that was really- - Interesting. - Was fascinating. Just 4chan, the spirit of the thing, 4chan.
- And people just understand 4chan. - It's so much about freedom and also like the humor involved
and fucking with the system and fucking, man. - That's it. It's just anti-system for fun. - The dark aspect of it is you're having fun,
you're doing anti-system stuff, but like the Nazis always show up and it somehow- - Really bad shit
started happening. - It drifting somehow, yeah. - It like school shootings and stuff. So it's a very difficult topic,
but I do know, especially early on, I think 2010, I would go to 4chan for fun,
and they would post crazy offensive stuff. And this was just to scare off people. So we show to other people say, "Hey, do you know this internet website 4chan?
Just check it out." - Yeah. (laughs) - And they'd be, "Dude, what the fuck is that?" I'm like, no, no, you don't understand. - Yeah. - That's to scare you away.
But actually when you go through scroll, there's like deep conversations. - Yes. - And they would already be, this was like a normie filter,
like to stop. - Yeah. - So kind of cool. But yeah- - It goes dark. - It goes dark, yeah.
- And if you have those people show up, for the fun of it, do a bunch of racist things and all that kind of stuff you were saying.
- Yeah, but everything is, I think it was never, man, I'm not at 4chan, but it was always about provoking.
It's just provocateur. - But the provoking in the case of Hoodmaps or something like this can- - Oh, man.
- Can damage a good thing like (laughs)
a little poison in a town is always good. It's like the Tom Waits thing, but you don't want too much otherwise it destroys the town.
It destroys the thing. - Yeah, they're kind like pen testers, like penetration testers, hackers. - Yeah. - They just test your app for you
and then you add some stuff, like I add like a NSFW word list.
They would say like bad words. So when they would write like a bad words, they would get forwarded to YouTube,
which was like a video. It was like a very relaxing video that like kind of ASMR
with like glowing jelly streaming like this to relax them, or cheese melting on the toast.
- Cheese melting, nice. - And to chill them out. - Yeah, yeah. - I like it. - Yeah. - But actually a lot of stuff I didn't realize
how much originated in 4chan in terms of memes. Rickroll, I didn't understand. I did not know that Rickroll originated 4chan.
- Really? - There's so many memes, like most of the memes that you think- - The word roll I think comes from 4chan,
like not the word roll, but in this case, in the meme use. - Yeah. - You would get like roll doubles,
'cause there was like post IDs on 4chan. So they were kinda like random. So if I get doubles, this happens or something.
So you'd get like two, two. Anyway, it's like a betting market kind of on these doubles, on these post IDs, this so much funny stuff.
- Yeah, I mean that's the internet, that's purist. But yeah, again, the dark stuff kind of seeps in. - [Pieter] Yeah.
- It's nice to keep the dark stuff to some low amount. It's nice to have a bit of noise of the darkness,
but not too much. - Yeah. - But again, you have to pay attention to that with,
I mean I guess spam in general. You have to fight that with Nomad List. How do you fight spam? - Man, I use GPT-4 now.
Fighting SPAM
It's amazing. (laughs) So I have like user input have reviews,
people can review cities. And I don't need to actually sign up. It's anonymous reviews. And they write whole books about cities
and what's good and bad. So I run into GPT-4 now, and I ask like, "Is this a good review?
Is this offensive? Is this race is this or some stuff?" And then send me message on Telegram
when it rejects reviews and I check it, and man, it's so on point. It's so- - Automated.
- Yes, and it's so accurate. It understands double meanings. I have GPT-4 running on the chat community.
It's a chat community of 10,000 people, and they're chatting, and they start fighting with each other.
And I used to have human moderators was very good, but they would start fighting the human moderator.
This guy's biased or something. I have GPT-4. And it's really, really, really, really good.
It understands humor. It understands like you could say something bad, but it's kinda a joke,
and it's kind of not offensive so much, so it shouldn't be deleted, right? It understands that.
- I would love to have a GPT-4 based filter
of different kinds for like X. - Yeah, I thought this week like, I tweeted like a fact check.
You can click Fact Check and then GPT-4. Look, GPT-4 is not always right about stuff, right? But it can give you a general fact check on a tweet.
Usually, what I do now when I write something like difficult about economics or something about AI. I put in GPT-4 say, "Can you fact check it?"
'Cause I might have said something stupid. And the stupid stuff always gets taken out by the replies.
Oh, you said this wrong. And then the whole tweet kind of doesn't make sense anymore. So I ask GPT-4 the fact check a lot of stuff.
- So fact check is a tough one. - Yeah. - But it would be interesting to sort of
rate a thing based on how well-thought out it is and how well-argued it is. - Yeah. - That seems more doable.
That seems like more doable. It seems like a GPT thing because that that's less about the truth and it's more about the rigor of the thing.
- Exactly, and you can ask that, you can ask in the prompt like, I don't know, for example, do you think...
Create like a ranking score for X Twitter applies where I should dispose be, if we rank on like,
I dunno, integrity, reality, like fundamental deepness or something, interestingness.
And it will give you with a pretty good score probably. I mean Elon can do this with Grok, right? He can start using that to check replies,
because the reply section is like chaos. - Yeah, and actually the ranking and the replies is not great. - Doesn't make any sense. - Doesn't make sense.
- No. - And I would like to sort in different kinds of ways. - Yeah, and you get too many replies now, if you have a lot of followers.
I get too many replies. I don't see everything and a lot of stuff I just miss and I wanna see the good stuff.
- And also the notifications or whatever, is just complete chaos. - Yeah. - It'd be nice to be able to filter that
in interesting ways, sorted in interesting ways. 'Cause I feel like I miss a lot
and what's surfaced for me is just a random comment by a person with no followers.
- Yeah, yeah. - That's positive or negative. It's like, okay, - If it's a very good comment, it should happen, but it should probably look a little bit more,
do these people have followers, 'cause they're probably more engaged in the platform, right? - Oh, no. I don't even care about how many followers.
If you're ranking by the quality of the comment, great. - Yeah. - But not just randomly,
like chronological, just a sea of comments. - Yeah, yeah, yeah, it does make sense. - Yeah. - Yeah.
X could be very proof of that, I think. - One thing you espouse a lot, which I love is the automation step.
Automation
So once you have a thing... Once you have an idea and you build it, and it actually starts making money.
And it's making people happy, there's a community of people using it. You want to take the automation step
of automating the things you have to do as little work as possible for it to keep running indefinitely. - Yeah. - Can you explain
your philosophy there? What do you mean by automate? - Yeah, so the general theory of starters would be that when it starts, you start making money,
you start hiring people to do stuff, right? Do stuff that you, like marketing, for example. Do stuff that you would do in the beginning yourself,
and whatever community management and organizing meetups for Nomad List, for example, that would be a job, for example.
And I felt like I don't have the money for that and I don't really wanna run a big company
with a lot of people, 'cause there's a lot of work managing these people. So I've always tried to automate these things as much as possible.
And this can literally be like for Nomad List, it's literally like a... It's not a different other sources. It was like a webpage where you can organize your own meetup,
set a schedule, a date, whatever. You could see how many nomads will be there at that date. So there will be actually enough nomads to meet up, right?
And then when it's done, it sends a tweet out on the Nomad List account. There's a meetup here.
It sends a direct message to everybody in the city who are there, who are gonna be there. And then people show up on a bar and there's a meetup
and that's fully automated. And for me, it's so obvious to make this automatic,
why would you have somebody organize this? It makes more sense to automate it.
And with most of my things, like I figure out how to do it with codes. And I think especially now with AI,
you can automate so much more stuff than before. 'Cause AI understands things so well. Like before I would use if statements, right?
Now you ask GPT, you put something on GPT-4, and in the API and it sends back like, this is good, this is bad.
- Yeah, so you basically can now even automate sort of subjective type of things.
This is the difference now. - Yeah. - And that's very recent, right? - But it's still difficult to,
I mean that's step of automation is difficult to figure out how to...
Is you're basically delegating everything to code. - Yeah. - And it's not trivial to take that step for a lot of people.
So when you say automate, are you talking about like CronJob? - Yes, man, a lot of CronJob.
- A lot of CronJobs. - Yeah. - I literally, I log into the server and I do like sudo crontab-e,
and then I go into editor and I write like hourly and then I write PHP,
dothisthing.php, and that's a script. And that script does a thing and it does it then hourly.
That's it. And that's how all my websites work. - Do you have a thing where it like emails you or something like this? Or emails somebody managing the thing,
if something goes wrong? - I have these webpage that make, they're called like healthchecks. It's like healthcheck.php,
and then it has emojis, it has a green check mark if it's good, and a read one if it's bad.
And then it does like database cures, for example. Like what's the internet speed in, for example, Amsterdam.
Okay, it's a number. It's like 27 point megabits. So it's accurate number. Okay, check, good. And it goes to the next,
and it goes on all the data points. Did people sign up in it last 24 hours? It's important 'cause maybe the sign up broke.
Okay, check, somebody sign up. Then I have uptimerobot.com, which is like for Uptime, but it can also check keywords.
It checks for an emoji, which is like the red X, which is if something is bad.
And so it opens that health check page every minute to check if something's bad. Then if it's bad, it sends a message to me on Telegram
saying, "Hey, what's up?" Or it doesn't say, "Hey, what's up?" It sends me like alert. (Lex laughs) - Hey, hey, sweetie. - This thing is down and then I check.
So within a minute of something breaking, I know it and then I can open my laptop and fix it.
- Yeah. - But the good thing is like the last few years, things don't break anymore. And definitely 10 years ago, when I started,
everything was breaking all the time. And now it's like almost, last week was like a 100.000% Uptime.
And these health checks are part of the Uptime percentage. So it's like everything works. - You're actually making me realize
I should have a page for myself. Like one page that has all the healthchecks,
just so I can go to it and see all the green check marks. - It feels good to look at, you know. - It just be like, okay. - Yeah.
- All right, we're okay. Everything's okay. - Yeah. - And like you can see like, when was the last time something wasn't okay,
and it'll say like never. - Yeah. - Or meaning like you've checked
since you've last cared to check, it's all been okay. - For sure. It used to send me the good healthchecks.
- Yeah. - It all works, it all works. - But it's been- - It all works. - [Lex] So often. (laughs) - And I'm like, this feels so good.
But then I'm like, okay, obviously, it's not gonna, we need to hide the good ones and show only the bad ones, and now that's the case. - I need to integrate everything into one place.
I automate like everything. - Yeah, yeah. - Also just a large set of CronJob.
A lot of the publication of this podcast is done all, everything's just on automatically, it's all clipped up.
All this kind of stuff. - Wow, yeah. - But it would be nice to automate even more. - Yeah. - Like translation,
all this kind of stuff would be nice to automate. - Yeah, every JavaScript, every PHP error gets sent to my Telegram as well.
So every user, whatever user it is, doesn't have to be page user. If they run into a error,
the JavaScript sends the JavaScript error to the server and then it sends to my Telegram, from all my websites.
- So you get like a message. - So I get like a uncut, variable error, whatever, blah, blah, blah.
And then I'm like, "Okay, interesting." And then I go check it out. And that's like a way to get to zero errors, 'cause you get flooded with errors in the beginning,
and now it's like nothing almost. - So that's really cool. That's really cool.
- But this is the same stuff people, they pay like very big SaaS companies.
New Relic for right? To manage this stuff. So you can do that too. You can use off the shelf.
I like to build myself. It's easier. - Yeah, it's nice. It's nice to do that kind of automation. I'm starting to think of like,
what are the things in my life I'm doing myself that could be automated in addition. - You can ask GPT, give your daily your day
and then ask you what parts you to automate. - Well, one of the things I would love to automate more is my consumption and social media.
- [Pieter] Yeah. - Both the output and the input. - Man, I think there's some startups that do that.
They summarize the cool shit happening on Twitter, with AI, I think the guy called SWYX or something,
he does like a newsletter that's completely AI generated. We have the cool new stuff in AI.
- Yeah, I mean I would love to do that. But also like across Instagram, Facebook- - Yeah. - LinkedIn. - Yeah. - All this kind of stuff.
Just like, okay, can you summarize the internet for me (Pieter chuckles) For today? - Summarize internet.com. - Yeah, dot com.
- Yeah. - Because I feel like it pulls into way too much time,
but also like, I don't like the effect it has some days on my psyche. - Because of like haters
or just general content and politics? - Just general. No, no, just general. Like for example, TikTok is a good example of that for me.
I sometimes just feel dumber after I use TikTok. I just feel like- - [Pieter] Yeah, I don't use it anymore. - Empty somehow and I'm like uninspired.
- Yeah. - It's funny in the moment I'm like, ha-ha, look at that cat doing a funny thing.
And then you're like, oh, look at that person dancing in a funny way to that music. And then you're like,
10 minutes later you're like, I feel way dumber and I don't really wanna do much. - Yeah. - For the rest of the day.
- My girlfriend said, she saw me like watching some dumb video. She's like, "Dude, your face looks so dumb as well."
(Lex laughs) Your whole face starts going like, oh, interesting.
- I mean with social media, with X sometimes for me too, I think I'm probably naturally
gravitating towards the drama. - Yeah, hard wheel. - Yeah, and so with following AI people,
especially AI people that only post technical content and it's been really good, 'cause then I just look at them, and then I go on down rabbit holes
of like learning new papers that have been published or- - Yeah. - Git repos, or just any kind of cool demonstration of stuff
and the kind of things that they retweet. And that's the rabbit hole I go and I'm learning and I'm inspired, all that kind of stuff.
But it's been tough. It's been tough to control that. - It's difficult. You need to like manage your platforms. I have a mute board list as well,
so I mute like politics stuff, 'cause I don't really want it on my feed. And I think I've muted so much that now my feed is good.
I see interesting stuff, (Lex laughs) but the fact that you need to modify, you need to like mod your app,
your social media platform- - Yeah. - Just to function and not be toxic for you, for your mental health, right? That's like a problem.
It should be doing that for you. - It's some level of automation that would be interesting.
I wish I could access X and Instagram through API easier.
- You need to spend $42,000 a month, which my friends do. Yeah, you can do that. - But still, even if you do that,
that you're not getting, I mean there's limitations that don't make it easy to do like- - Yeah. - Automate.
The thing that they're trying to limit, like abuse or for you to steal all the data from the app to then train an LLM,
or something like this. - Yeah. - But if I just wanna figure out ways to automate my interaction with the X system,
or with Instagram, they don't make that easy. But I would love to sort of automate that and explore different ways to how to leverage LLMs
to control the content I consume, and maybe publish that and maybe they themselves can see how
that could be used to improve their system. - Yeah. - But there's not enough access. - Yes, if you could screen cap your phone, right?
It could be an app that watches your screen with you. - You could, yeah. - But I don't even know like what it would do.
Maybe it's can hide stuff before you see it. Scroll down. - I have that, I have Chrome extensions. I write a lot of Chrome extensions
that hide parts of different pages and so on. - Yeah. - For example, on my main computer, I hide all views and likes
and all that on YouTube content that I create. So that I don't- - Smart, doesn't affect you.
- It doesn't, yeah. So you don't pay attention to it. - Yeah. - I also hide parts there. I have a mode for X where I hide most of everything.
So there's no, it's same with YouTube. - I have the same, I have this extension. - Well, I wrote my own 'cause it's easier.
- Yeah. - 'Cause it keeps changing. It's not easy to keep it dynamically changing, but they're really good at like getting you to be distracted
and like starting to- - Related accounts, related post. - Related stuff. - I'm like, I don't want related. - And like 10 minutes later you're like,
or something that's trending. I have a weird amount of friends addicted to YouTube, and I'm not addicted. I think 'cause my attention span is too short for YouTube.
(Lex and Pieter laughs) But I have this extension to like YouTube Unhook, which it hides all the related stuff.
I can just see the video and it's amazing. But sometimes I need to like,
I need to search a video how to do something. And then I go to YouTube and then I had these YouTube shorts.
These YouTube shorts are like, they're algorithmically designed to just make you tap them. And I tap and I then I'm like five minutes later,
with this face, and you're just stuck. And it's like, what happened? I was gonna open,
I was gonna play like the coffee mix, the music mix for drinking coffee together in the morning, like jazz,
I didn't wanna go to shorts. So it's very difficult. - I love how we're actually highlighting
all kinds of interesting problems that all could be solved at a startup. Okay, so what about the exit?
When to sell startup
When and how to exit? - Man, you shouldn't ask me 'cause I never sold my company, and I've- - So you've never...
All the successful stuff you've done, you've never sold it. - Yeah, it's kind of sad, right? So I've been in a lot of acquisition like deals and stuff,
and I learned a lot about finance people as well there, like manipulation and due diligence
and then changing the valuation. People change the valuation after.
A lot of people string you on to acquire you and then it takes six months. It's a classic.
It takes six to 12 months. They wanna see everything. They wanna see your Stripe and your code and whatever.
And then in the end, they'll change the price to lower, 'cause you're already so invested.
So it's a negotiation tactic, right? I'm like, no, then I don't want to sell, right? And the problem with my companies is like,
they make 90% profit margin. So the multiple,
companies get sold with multiples, kind of multiples of profit or revenue. And often the multiple is like three times,
three times or four times or five times revenue or profit. So in my case, they're all automated.
So I might as as well wait three years and I get the same money as when I sell and then I can still sell the same company.
You know what I mean? I can still sell for three, five times. So financially, it doesn't really make sense to sell.
- Yeah. - Unless the price high enough. If the price gets to six or seven or eight, I don't wanna wait six years for the money.
But if you give me three, like three years is nothing. I can wait. - So that means they're really valuable stuff
about the companies you created is not just the interface and the crowdsource content,
but the people themselves, like the user base. - Yeah. So Nomad List, it's a community, yeah.
- So I could see that being extremely valuable. - Yeah. - I'm surprised that has not. - But Nomad List, it's like my baby. It's like my first project I took off,
and I don't really know if I wanna sell it. It's like something you- - Yeah. - Would be nice when you're old to just still work on this.
It has like a mission, which is like people should travel anywhere and they can work from anywhere
and they can meet different cultures. And that's a good way to make the world get better. If you go to China and live in China,
you'll learn that they're nice people. And a lot of stuff you hear about China's propaganda, a lot of stuff is true as well. But it's more, you know, you learn a lot from traveling.
And I think that's why it's a cool product to not sell. AI products, I have less emotional feeling
with AI products like photo AI, which I could sell, yeah. - Yeah, the thing you also mentioned is you have to
price in the fact that you're going to miss. - Yeah. - The company you created. - And the meaning it gives you, right?
There's a very famous depression after start finding a solar company. They're like, this was me.
Like who am I? And they immediately start building another one. (Lex laughs) They never can stop. So I think it's good to keep working until you die.
Just keep working on cool stuff and you shouldn't retire. I think retirement's bad probably.
Coding solo
- So you usually build this stuff solo and mostly work solo. What's the thinking behind that?
- I think I'm not so good working with other people. Not like I'm crazy, but I don't trust other people.
- To clarify, you don't trust other people to do a great job. - Yeah, and I don't wanna have this consensus meeting
where we all like, you have a meeting of three people and then you kind of get this compromise results,
which is very European. In Holland, we call pull them whatever. You put people the room and you only let 'em out
when they agree on the compromise, right? In politics. I think it breeds like averageness,
you get an average idea, average company, average culture, you need to have a leader or you need to be solo
and just do it, do it yourself, I think. And I trust some people, now with my best friend Andre,
I'm making a new AI startup. But it's because we know each other very long and he's one of the few people I would build something with
but almost never, yeah. - So what does it take to be successful when you have more than one?
How do you build together with Andre? How do you build together with other people? - So he codes, I should post on Twitter.
Literally, I promoted on Twitter. We set product strategy. I said, this should be better, this should be better.
But I think you need to have one person coding it. He codes in Ruby so was like cannot do Ruby, I'm in PHP.
- So have you ever coded with another person for prolonged periods of time? - Never in my life.
(Lex laughs) - What do you think is behind that?
- I know it was always just me sitting on my laptop, like coding. - No, like you've never had another developer
who like rolls in and like? - I've had once with Photo AI, there's an AI developer, Philip, I hired him to do the...
'Cause I can't write Python. - Yeah. - And AI stuff is Python. And I needed to get models to work and replicate and stuff.
And I needed to improve Photo AI. And he helped me a lot for 10 months he worked, and man, I was trying Python working with NumPy,
and package manager and it was too difficult for me to figure this shit out. And I didn't have time. I think 10 years ago I would've time to sit,
go do all-nighters to figure this stuff out with Python. I don't have the...
It's not my thing, - But it's not your thing. It's another programming language, I get it. AI, new thing, got it.
But you never had a developer roll in, look at your PHP, jQuery code and yes,
like in conversation or improv- - Yeah. - They talk about yes, and, like basically, alright.
- I had for one week. - Understand. - And that ended. - What happened? - Because he wanted to rewrite everything in the-
- No, that's the wrong guy. - I know. - He wanted to rewrite and what? - He wanted to rewrite, he said this jQuery, we cannot do this.
I'm like, okay. He's we need to rewrite a thing in Vue, vue.js I'm like, "Are you sure? Can we just like, you know, keep jQuery?"
He's like, "No, man." And we need to change a lot of stuff. And I'm like, "Okay." And I was kinda feeling it like this,
you know, we're gonna clean up shit. But then after week, this is gonna take way too much time. - I think I like working with people
where when I approach them, I pretend in my head
that they're the smartest person who has ever existed. - Wow. - So I look at their code or I look at the stuff they've created
and try to see the genius of their way. You really have to understand people, like really notice them.
And then from that place have a conversation about what is the better approach. - Yeah, but those are the top tier developers.
- [Lex] Yeah. - Those are the ones that are tech ambiguous. So they can work with, they can learn any tech stack
and they can- - Yeah. - And that's like really few, it's like- - Really? - Top 5%. - Damn. - Because if you try higher devs,
no offense to devs, but most devs are not. Man, most people in general jobs are not so good at the job,
even doctors and stuff. - That's too sad. - When you realize this, people are very average at the job. - Yeah. - Especially with dev with coding, I think.
So sorry for- - I think that's a really important skill for a developer to roll in and understand the musicality, the style.
- That's it, man. Empathy, it's like code empathy, right? - It's code empathy. - Yeah, it's new word, but that's it. You need to understand,
go over the code, get a holistic view of it and man, you can suggest we change stuff, for sure.
And look, jQuery is crazy. It's crazy, I'm using jQuery. We can change that. - It's not crazy at all. jQuery is also beautiful- - Yeah.
- And powerful, and PHP is beautiful and powerful. Especially as you said recently,
as the versions evolved, it's much more serious programming language now. It's super fast. - For sure.
- Like PHP is really fast now. - Yeah, yeah, yeah. - It's crazy JavaScripts- - Much faster than Ruby, yeah.
- Really fast now. - Yeah. - So if speed is something you care about, it's super fast. - Yeah. - And there's gigantic communities of people-
- [Pieter] Yeah. - Using those program languages, and there's frameworks if you like the framework. So whatever, it doesn't really matter what you use,
but also you, if I was like a developer working with you, like you are extremely successful.
You've shipped a lot. - Yeah. - So like if I roll in, I'm gonna be like,
I don't assume you know nothing. Assume Pieter is a genius, like the smartest developer ever.
And like learn, learn from it. - Yeah. - And yes and. Notice parts in the code where like, okay, okay, okay.
I got it. - Yeah. - Here's how he's thinking. And now if I want to add another,
like a little feature, definitely needs to have emoji. (laughs) - Yeah, man. - In front of it. And then like just follow the same style and add it.
- [Pieter] Yeah. - And my goal is to make you happy, to make you smile, to make you, ha-ha, fuck, I get it.
And now you're going to start respecting me. - Yeah. - And like trusting me, and you start working together in this way.
I don't know. I don't know how hard it's to find developers. - No, I think they exist. I think I need to hire more people.
I need to try more people. - Try people, yeah. - But that costs a lot of my energy and time. - Yeah. - But it's 100% possible.
- Yeah. - But do I want it? I don't know, things kind of run fine for now. (Lex laughs) And I mean like, okay.
You could say like, okay, Nomad List looks kind of clunky. People say the design's gonna clunky. Okay, I'll improve the design. It's like next to my to-do list, for example.
I'll get there eventually. - But it's true. I mean you're also extremely good at what you do.
Ship fast
I'm just looking at the interfaces of Photo AI. You with jQuery, right?
How amazing is jQuery? These cowboys are getting, these are...
There's these cowboys. This is a lot, this is a lot. But I'm glad they're all wearing shirts.
Anyway, the interface here is just really, really nice. I could tell you know what you're doing
and with Nomad List extremely nice, the interface. - Thank you, man. - And that's all you.
- [Pieter] Yeah, that's everything is me. - So all of this and every little feature. All of this. - People say it looks kind of ADHD or ADD,
like it's so much because it has so many things and designs these days is minimalist.
Right? - Right, right, I hear you. But this is a lot of information and it's useful information,
and it's delivered in a clean way while still stylish and fun to look at. So like minimalist design is about
when you want to convey no information whatsoever- - Yeah. - And look cool. - Yeah, it's very cool. It's pretentious, right?
- Pretentious or not, the function is useless. This is about a lot of information delivered to you in a clean,
and when it's clean you can't be too sexy. So it's sexy enough. - Yeah, this is I think how my brain looks.
It's a lot of shit going on. It's like drawing bass music. It's like very (imitates bass music)
- Yeah, but it's this still... The spacing of everything is nice. The fonts are really nice.
Like very readable, very small. - Yeah, I like it, you know, but I made it so I don't trust my own judgment.
- No, this is really nice. - Thank you, man. - Emojis are somehow, like this is a style, it's a thing.
- I need to pick the emoji. It takes a while to pick them. - Something about the emoji is a really nice memorable,
like placeholder for the idea. - Yeah. - If it was just text, it would actually be overwhelming if you was just text.
The emoji really helps. That's a brilliant addition. Some people might look at it, why do you have emojis everywhere?
It's actually really, for me, it's really- - People tell me to remove the emojis. - Yeah, well, people don't know what they're talking about. - Makes it immature.
- I'm sure people will tell you a lot of things. This is really nice. And then using color is nice.
Small font but not too small. And obviously, you have to show maps, which is really tricky. - Yeah.
- Yeah. - This is nice. - No, this is really, really, really nice. I mean, okay, how this looks
when you hover over it? - Yeah, it's easy as transitions. - No, I understand that.
I'm sure there's like, how long does that take you to figure out how you want it to look? Do you ever go down a rabbit hole where you spent like two weeks?
- No, it's all iterative. It's like 10 years of, you know, added C transition here or do this or.
- Well, let's say like, see these are rounded now. - Yeah. - If you wanted to like round is probably the better way.
But if you want it to be rectangular, like sharp corners, what would you do? You just? - So go to the index at CSS.
- Yeah. - And I do Command + F. and I search border radius 12 px. - [Lex] Yeah. - And then I replace with border radius zero.
And then I do Command + Enter- - Yeah. - And it's get deploys, it pushes to the git hub and then sends a WebBook and then deploys to my server,
and it's live in five seconds. - Oh, you often deployed to production. You don't have like a testing ground?
- No. (Lex laughs) So I'm like famous for this,
'cause I'm too lazy to set up a staging server on my laptop every time. So nowadays I just deploy to production.
- [Lex] Yeah. - Man, I'm gonna be canceled for this. But it works very well for me, 'cause I have a lot of...
I have PHP Lint and djLint so it tells me when there's error. So I don't deploy. - Yeah. - But literally,
I have like 37,000 git commits in the last 12 months or something. So I make small fix
and then Command + Enter, and sends to GitHub. GitHub sends a web to server, web server pulls it, deploys the production,
and is there. - What's the latency of that from you pressing Command + Enter? - One second, can be one two seconds.
- So you just make a change and then you- - That's right. - Getting really good at like not making mistakes basically. - Man, 100%, you're right.
People are like, how can you do this? Well, you get good at not taking the server down. - Yeah. - 'Cause you need to code more carefully.
Look, it's idiotic in any big company. But for me, it works 'cause it makes me so fast. Somebody will report a bug on Twitter
and I kind of did do a stopwatch. How fast can I fix this bug? And then two minutes later, for example, it's fixed.
- [Lex] Yeah. - And it's fun 'cause it's annoying for me to work with companies where you report a bug
and it takes like six months. - Yeah. - It's like horrible. And it makes people really happy when you can really quickly solve their problems.
But it's crazy, I admit. - I don't think it's crazy. I mean, I'm sure there's a middle ground,
but I think that whole thing where there's a phase of like testing and there's the staging,
and there's a development and then there's like multiple tables and databases that you use for the stage.
Like it's- - Filing. - It's a mess. - Yeah. - And there's different teams involved. It's not good.
- I'm like a good funny extreme on the other side. - But just a little bit safer but not too much. It would be great. - Yeah, yeah.
- And I'm sure that's actually like how X now, how they're doing rapid improvement. It's exactly. - No, they do
because there's more bugs. - Yeah. - And people complain about like, oh look, he bought this Twitter. Now it's full of bugs. Dude, these shipping stuff-
- Yeah. - Things are happening now and it's a dynamic app now. - Yeah, the bugs is actually a sign of a good thing happening.
- Yes. - The bugs of the feature because it shows- - Yes. - That the team is actually building shit. - 100%, yeah. - Well, one of the problems is like
I see with YouTube there's so much potential to build features, but I just see how long it takes.
So I've gotten a chance to interact with many other teams. But one of the teams is MLA, multi-language audio.
- Yeah. - I dunno if you know this, but in YouTube you can have audio tracks in different languages. - Yeah. - For over dubbing.
And there's a team, and not many people are using it, but like every single feature,
they have to meet and agree, and there's allocate resources. Engineers have to work on it.
But I'm sure it's a pain in the ass for the engineers to get approval to like, - [Pieter] I know. - Because it has to not break the rest of the site,
whatever they do. But if you don't have enough dictatorial, like top down, like we need this now,
it's gonna take forever to do anything multi-language audio. But multi-language audio is a good example of a thing
that seems niche right now, but it quite possibly could change the entire world.
When I upload this conversation right here, if instantaneously, it dubs it into 40 languages.
- [Pieter] Yeah, man. - And everybody consume every single video can be watched and listened to
in those different, it changes everything. And YouTube is extremely well-positioned to be the leader in this. - Yeah.
- They got the compute, they got the user base,
they have the experience of how to do this. So like multi-language audio should be- - High priority feature, right?
- Yeah, that's high priority. - Yeah, yeah. - And it's a way, Google is obsessed with AI right now. They wanna show off that they could be dominant in AI.
That's a way for Google to say like, we used AI. This is a way to break down the walls
that language creates. - The preferred outcome for them is probably their career and not the overall result of the cool product.
- I think they're not like selfish or whatever, they wanna do good. There's something about the machine- - The organization, yeah.
- The organizational stuff that's just so I happens. - I have this when I report bugs on like big companies I work with.
I talk to a lot of different people in DM and they're all really trying hard to do something. They're all really nice.
And I'm the one being kind of asshole- - Yeah. - 'Cause I'm like, guys, I'm talking to 20 people about this for six months and nothing's happening.
I say, "Man, I know but I'm trying my best." Yeah, so it's systemic. - Yeah, it requires, again,
I don't know if there must be a nicer word, but like dictatorial type of top down the CEO rolls in
and just says like, for you two, it's like MLA. - Yeah. - Get this done now. This is the highest priority.
- I think big companies, especially in America, a lot of it's legal, right? They need to pass everything through legal. - Yeah. - And you can't like,
man, the things I do, I could never do that in a big corporation, 'cause it's everything has to be probably Git deploy has to go through legal.
- Well, again, dictatorial, you basically say Steve Jobs did this quite a lot.
I've seen a lot of leaders do this. Ignore the lawyers. Ignore comms. - Exactly, yeah. - Ignore PR, ignore everybody.
Give power to the engineers. Listen to the people on the ground, get this shit done, and get it done by Friday.
- Yeah. - That's it. - And the law can change. For example, let's say you launch this AI dubbing and there's some legal problems with lawsuits.
Okay, so the law changes, there will be appeals, there will be some Supreme Court thing, whatever. And the law changes.
So just by shipping it you change society, you change the legal framework. And by not shipping, being scared of the legal framework all the time.
You're not changing things. - Just outta curiosity, what ID do you use?
Best IDE for programming
Let's talk about like your whole setup. Given how ultra productive you are and that you often program in your underwear
slouching on the couch. Does it matter to you in general?
Is there like a specific ID you use you use VS Code? - Yeah, VS Code. Before I used Sublime Text,
I don't think it matters a lot. I think I'm very skeptical of like tools when people think it...
They say it matters, right? I don't think it matters. I think whatever tool you know very well,
you go very, very fast and the shortcuts, for example, IDE. I love Sublime Text 'cause I could use multi-cursor,
you search something and I could just like make mass replaces in a foul- - Yeah.
- With the cursor thing, and VS Code doesn't really have that as well. - It's actually interesting. Sublime is the first editor where I've learned that.
- [Pieter] Yeah. - And I think they just make that super easy. So what would that be called? Multi-edit, multi-cursors edit-
- Yeah. - Thing whatever. - [Pieter] That's so good. - I'm sure like almost every editor can do that. It is just probably hard to set up.
- Yeah. - And why so why need it? - VS Code is not so good, I think, Or at least I try it. But I would use that to like process data.
Data sets, for example, from World Bank. I would just multi-cursor mass change everything,
but yeah, VS Codes. Man, I was bullied into using VS Code, 'cause Twitter would always see my screenshots
of Sublime Text and say, "Why are you still using Sublime Text?" Boomer, you need to use VS codes. - Yeah.
- And I'm like, yeah, I'll try it. I got a new MacBook and then I never installed, I never copied the old MacBook.
I just make it fresh, you know, like a clean, like format C Windows. Clean starts and I'm like, 'Okay, I'll try VS Code."
And it stuck, you know, but I don't really care. It's not so important for me. - Wow, you know the format C reference, huh?
- Dude, it was so good. You would install Windows and then after three or six months it would start breaking and everything was like get slow.
Then you would restart, go to Dos, format C, you would delete your hard drive and then install the Windows 95 again,
that was so good times. And you would design everything. Now I'm gonna install it properly. now I'm gonna design my desktop properly.
- Yeah, I don't know if it's peer pressure, but like I used E-MAX for many, many years and I know, you know, I love Lisp.
So a lot of the customization is done in Lisp. It's a programming language. And partially, it was peer pressure.
But part of it's realizing like you need to keep learning stuff. The same issue with jQuery.
I still think I need to learn Node.js, for example. - [Pieter] Yeah. - Even though that's not my main thing
or even close to the main thing. But I feel like you need to keep learning this stuff.
And even if you don't choose to use it long term, you need to give it a chance.
So your understanding of the world expands. - Yeah, you wanna understand the new technological concepts and see if they can benefit you.
It would be stupid not to even try it. - It's more about the concepts I would say than the actual tools.
Like expanding, and that could be a challenging thing. So going to VS Code and like really learning it, like all the shortcuts, all the extensions,
and actually installing different stuff and playing with it. That was a interesting challenge. It was uncomfortable at first.
- Yeah, for me too, yeah. - Yeah, but you just dive in. - It's like neuro flex, like you keep your brain fresh, like this kind of stuff.
- I gotta do that more. Have you given React a chance? (laughs) - No, but I wanna learn
and I understand the basics, right? I don't really know where to start.
- But would you like, I guess you gotta use your own model, which is like build the thing using it.
- No, man, so I kind of did that. - Yeah. - The stuff I do in jQuery is essentially,
a lot of it is like, I start rebuilding whatever tech is already out there.
Not based on that, but just on accident. - Yeah. - I keep coding long enough that I built the same, I start getting the same problems everybody else has,
and you start building the same frameworks kind of. So essentially, I use my own kind of framework of. - So you basically build a framework from scratch
that's your own, that you understand it? - Kinda yeah. With HX calls, but essentially it's the same thing. Look, I don't have the time.
I think saying you don't have the time is like always a lie, 'cause you just don't prioritize it enough.
My priority is still like the running the businesses and improving that and AI. I think learning AI is much more valuable now
than learning a front end framework. Yeah, It's just more impact. - I guess you should be just learning
every single day a thing. - Yeah, you can learn a little bit every day. - Yeah. - Like a little bit of React,
or I think now, like Next very big. So learn a little bit of Next. But I call them the military industrial complex.
But you need to know, you need to know it anyway. - You gotta learn how to use the weapons of war
and then you can be peacenik. - Yeah, yeah. - Yeah, I mean, but you gotta learn it in the same exact way
as we were talking about, which is learning by trying to build something with it and actually deploy it. - The frameworks are so complicated
and it changes so fast. So it's like, where do I start? And I guess it's the same thing when you're starting out making websites.
Where do you start? Ask GPT-4, I guess. Yeah, it's just so dynamic.
It changes so fast that, and I dunno if it would be a good idea for me to learn it. Maybe some combination of like,
few Next with PHP Laravel. Laravel is like a framework for PHP.
I think that would be... It could benefit me. Maybe Tailwind for CSS, like a styling engine.
That stuff could probably save me time. - Yeah, but like you won't know until you really give it a try. And it feels like you have to build,
if maybe I'm talking to myself, but I should probably recode
like my personal one page in Laravel. - [Pieter] Yeah. - And even though it might not have almost
any dynamic elements, maybe have one dynamic element, but it has to go end to end in that framework.
- Yeah. - Or like end to end build in Node.js. Some of it is, I don't... Figuring out how to even deploy the thing.
- I have no idea. - Full stack. - All I know is right now I would send it to GitHub and it sends it to my server. I don't know how to get JavaScript running.
I have no clue. - Yeah. - So I guess I need like a pass, like first an array,
or Heroku kind of those kind of platforms. - I actually kind of just gave myself the idea of like,
I kind of just wanna build a single webpage. Like one webpage that has one dynamic element
and just do it in every single, in a lot of frameworks. Like just- - Ah, on the same page.
- Same exact page. - All the same? - Kinda page. - It's smart. That's a cool project. You can learn all these frameworks. - Yeah. - And you can see
the differences. - Yeah. - That's interesting, right? - That how long it takes to do it. - Yeah, stopwatch, yeah, yeah. - I have to figure out actually
something sufficiently complicated, 'cause it should probably do, it should probably do some kind of thing
where it accesses the database and dynamically changing stuff. - Some AI stuff, some LLM stuff.
- Yeah, maybe some, it doesn't have to be AI LLM but maybe- - Do an API call. - API call to something. - Yeah, to replicate, for example.
And then that would be a very cool project. - Yeah, yeah. And like time it and also report on my happiness.
- Yeah. - I'm gonna totally do this - Because nobody benchmarks this. Nobody's benchmark developer happiness with frameworks.
- [Lex] Yeah - Nobody's benchmarked the shipping time. - Just take like a month and do this. How many frameworks are there?
How many? There's like five main ways of doing it. So there's like, this is no...
There's backend, frontend. - And this stuff confused me too. Like React now apparently has become backend. - [Lex] Yeah.
- Or something used to be on frontend, and you're forced to do now backend also. I don't know. But there's not really,
you're not really forced to do anything. So according to the internet, so like there's no...
It's actually not trivial to find the canonical way of doing things. So like the standard vanilla- - Yeah.
- You go to the ice cream shop, there's like a million flavors. I want vanilla. If I've never had ice cream in my life,
can we just like learn about ice cream? - Yeah. - I want vanilla. Nobody actually,
sometimes they'll literally name it vanilla. But I wanna know what's the basic way, but not like dumb,
but the standard canonical common. - Yeah, I know the dominant way- - [Lex] Yeah, the dominant way. - 60% of developers do it like this.
- [Lex] Yeah. - It's hard to figure that out, that's the problem. - Yeah, maybe LLMs can help.
Maybe you should explicitly ask what is the dominant? - Because they usually know the dominant, they give answers- - Yeah.
- That are like the most probable kind of. - Yeah. - So that makes sense to ask LLM.
I think honestly, maybe what would help is if you wanna learn or I would wanna learn a framework.
Hire somebody that already does it and just sit with them and make something together.
I've never done that, but I've thought about it. So it would be a very fast way to take their knowledge put them in my brain.
- I've tried these kinds of things. What happens is it depends what kind of, if they're like a world class developer, yes.
Oftentimes they themselves are used to that thing and they have not themselves explored in other options.
So they're have this dogmatic talking down to you, - [Pieter] Yeah. (laughs) - This is the right way to do it.
- Yeah. - It's like, no, no, no. We're just like exploring together. Okay, show me the cool thing you've tried,
which is like, it has to have open-mindedness to like,
Node.js is not the right way to do web development. It's like one way.
And there's nothing wrong with the old lamp, PHP,
jQuery, vanilla JavaScript way. It just has its pros and cons, and like- - Yeah.
- You really you need to know what the pros and cons. - Those people exist. You could find those people probably. - Yeah. - If you wanna learn AI,
Andrej Karpathy
imagine you have Karpathy sitting next to you- - Yeah. - Teach you, like he does these YouTube videos. It's amazing. He can teach it to like a five-year-old
about how to make LLM. It's amazing. Imagine this guy sitting next to you and just teaching you like,
let's make LLM together. Holy shit, it would be amazing. - Yeah, I mean, well, Karpathy has its own style
and is like, I'm not sure he's for everybody, for example, a five-year-old. It depends on the five-year-old.
- Yeah. - He's like super technical, - But he's amazing, 'cause he's super technical and he's the only one who can explain- - Yes. - The stuff in a simple way,
which shows his complete genius. - Yes. - 'Cause if you can explain without jargon- - No BS. - You're like, wow.
- And build it from scratch. - Yeah. it's like top tier. What a guy! - But he might be anti-framework
'cause he builds from scratch. - Actually, exactly, yeah. Actually he probably is, yeah. - He's like you, but for AI.
- Yeah, so maybe learning a framework is a very bad idea for us. Maybe we should stay in PHP, and like Script kiddie and the-
- But you have to... Maybe by learning the framework, you learn what you want to yourself,
build from scratch. - Yeah, maybe you learn concepts, but you don't actually have to start using it for your life, right? Yeah, yeah. - And you're still a Mac guy or was a Mac guy?
- Yeah, yeah, I switched to Mac in 2014, 'cause when I wanted to start traveling and my brother was like, "Dude, get a MacBook.
It's like the standard now." I'm like, wow, I need to switch from Windows. And I had like three screens, Windows.
- [Lex] Yeah. - I had this whole setup for music production. I had to sell everything. And then I had a MacBook,
and I remember opening up this MacBook box, like aah, and it was so beautiful.
It was like this aluminum, and then I opened it, I removed the screen protector thing. And it's so beautiful.
And I didn't touch it for three days. I was just like, looking at it. - Yeah. - Really. And I was still on the Windows computer. And then I went traveling with that.
And all my great things started when I switched to Mac, which sounds very dogmatic, right? - What great things are you talking about?
- All the business started working out. I started traveling. I started building startups. I started making money.
It all started when I switched to Mac. - Listen, I kinda...
You're making me wanna switch to Mac. So I either use Linux inside Windows with WSL
or just- - Yeah. - Ubuntu, Linux. But Windows for most stuff, like editing or any Adobe products.
- Adobe stuff, right? - Yeah, yeah, yeah. Well you could use, I guess you could do Mac stuff there. - Yeah. - I wonder if I should switch.
What do you miss about Windows? What was the pros and cons? - I think the Finder is horrible in Mac. - What is horrible? - The Finder.
Oh, you don't know the Finder? So there's the Windows Explorer. - Yeah. - Windows Explorer is amazing. - Thank you for talking down. - Finder is strange, man.
There's like strange things. There's this bug where if you send, like, attach a photo in WhatsApp or Telegram,
it just selects the whole folder and you almost accidentally can click Enter and you send all your photos, all your files
to this chat group, happened to my girlfriend. She starts sending me photo, photo, photo, photo, photo.
So Finder is very unusable, but it has Linux. The whole thing is like, it's Unix based, right?
- So you use the command like? - Yeah, all the time. Like all the time. And the cool thing is you can run,
I think it's like Unix, like Debian or whatever. You can run most Linux stuff on macOS,
which makes this very good for developments. I have my Nginx server, if I'm not lazy and set up my staging on my laptop,
it's just the Nginx server. The same as I have on my cloud server, right? The same way the websites run.
And I can use almost everything, the same config files, configuration files, and it just works.
And that makes Mac a very good platform for Linux stuff, I think. - Yeah, yeah.
- Real Ubuntu is like better of course. - Yeah, I'm in this weird situation where I'm
somewhat of a power user in Windows, and let's say Android and all the much smarter friends I have
all using Mac and iPhone. And it's like- - If you don't wanna
go through the peer pressure. - It's not peer pressure. It's like one of the reasons I wanna have kids
is that there's a lot of... I would love to have kids as a baseline, but there's like a concern.
Maybe there's gonna be a trade off, or all this kind of stuff. But you see like these extremely successful smart people
who are friends of mine, who have kids and are really happy they have kids. So that's not peer pressure, that's just like a strong signal.
- Yeah, it works for people. - That works for people. - Yeah, yeah, yeah. And the same thing with Mac. It's like- - Yeah. (Lex exhales)
- I don't see fundamentally, I don't like closed systems. So fundamentally, I like Windows more
because there's much more freedom. Same with Android, there's much more freedom. - Yeah. - It's much more customizable. But like all the cool kids,
the smart kids are using Mac and iPhones. All right, I need to really, I need to give it a real chance.
Especially for development, since more and more stuff is done in the cloud anyway. - Yeah. - Well, anyway. But it's funny to hear you say all
the good stuff started happening. Maybe I'll be like that guy too. When I switched to Mac, all the good stuff- - Yeah.
- Started happening. - I think it's just about the hardware. It's just much about the software that- - Yeah. - The hardware is so well built, right? A keyboard and- - Yeah.
But look at the keyboard I use. - Yeah, that's pretty cool. - That's one word for it.
What's your favorite place to work? - On the couch. Does the couch matter? Is the couch at home or is it any couch?
- No, like hotel couch also. In the room, right? - In the room. - Yeah, but I used to work like very ergonomically
with like a standing desk. - Yeah. - And everything like perfect, like eye height, screen, blah, blah, blah.
And I felt like, man, this has to do with lifting too. I started getting RSI like repetitive strain injury,
like tingling stuff. And it would go all the way on my back. And I was sitting in a coworking space like 6:00 AM, sun comes up and I'm working and I'm coding,
and I hear like a sound or something. So I do like, I look left and my neck gets stuck like (imitates cracking)
and I'm like, wow, fuck! (Lex laughs) And I'm like, am I dying? And I thought, (Lex laughs)
I'm probably dying. - Yeah, probably dying. - I don't wanna die in a cowork space. I'm gonna go home and die in like- - Yeah. - Peace and honor.
- Yeah. - So I closed my laptop, and I put it in my backpack. - Yeah. - And I walked to the street.
I got on my motorbike, went home. - Yeah. - And I lie down on like a pillow,
with my legs up and stuff, to get rid of this like, 'cause it was my whole back.
And it was because I was working like this all the time. - Yeah. - So I started getting like a, a laptop stand, everything.
Ergonomically correct. But then I started lifting and since then,
it seems like everything gets straightened out. Your posture kinda, you're more straight.
And I never have RSI anymore, repetitive injury. I never have tingling anymore.
No pains and stuff. So then I started working on the sofa and it's great. It feels close to the...
I sit like this. - Yeah. - Legs together and then a pillow and then a laptop.
And then I work. - Are you like leaning back? - I'm kind of like, together like legs,
and then- - Where's the mouse? - No, so everything is tracked on the macOs, the MacBook.
I used to have the Logitech MX mouse, the perfect ergonomic mouse. So you're just doing like this little thing with the thing.
- Yes. - One screen. - One screen. And I used to have three screens. I know where people come from. - Yeah, yeah, yeah.
- I had all the stuff, but then I realized that having it all condensed in one laptop, it's a 16 inch MacBook.
So it's quite big. But having it one there is amazing, 'cause you're so close to the tools, you're so close to what's happening.
It's like working on a car or something. Man, if you have trees, you to look here,
look there, you get also neck injury actually. - Well, I don't know. This sounds like you're part of a cult,
and you're just trying to convince me. I mean, but it's good to hear that you can be ultra productive on a single screen.
- Yeah. - I mean that's crazy. - Come on tap, you all tap, Windows is all up tap, macros Command + Tap,
you switch very fast. - So you have like one, the entire screen is taken out by VS Code. Say you look at the code and then-
- Yeah. - And then if you deploy like a website, you what? Switch screens. - Command + Tap to Chrome.
I used to have this swipe screen, you could do like different screen. - Yeah, yeah. - Spaces. - Yeah. - I was like,
"Ah, it's too difficult." Let's just put it all on one screen on the MacBook and then. - And you can be productive that way?
- Yeah, very productive, yeah. More productive than before. - Interesting. Because I have three screens,
then two of them are vertical. Like on the size? - Yeah, code, right, yeah. - For the code, you can see a lot. - Yeah. No man, I love it.
I love seeing it with friends. They have amazing like battle stations, right? - Yeah. - It's called. It's amazing.
I want it but I don't want it, right? - So you like the constraints. - [Pieter] That's it. - There's some aspect of the constraints,
which like once you get good at it, you can focus your mind and you can. - Man, I'm suspicious of like more.
- Yeah. - Do you really need all the stuff? It might slow me down, actually. - It's a good way to put it. I'm suspicious of more, me too.
- [Pieter] Yeah. - I'm suspicious of more in all ways, in all walks of life. - 'Cause you can defend more, right? You can defend.
Yeah, I'm a developer, I make money. I need to get more screens, right? I need to be more efficient. And then you read stuff about "Mythical Man-Month,"
where like hiring more people slows down a software project that's famous. Think you can use a metaphor maybe for tools as well.
Then I see friends just with gear acquisition syndrome that buying so much stuff, but they're not that productive.
They have the best, most beautiful battle stations, desktops, everything. They're not that productive.
And it's also like kind of fun. It's all from my laptop in a backpack, right? - Yeah. - It's kinda nomad minimalist. - Take me through like the perfect
Productivity
ultra productive day in your life. Say like where you get a lot of shit done.
- Yeah. - And it's all focused on getting shit done. When are you waking up?
Is it a regular time? Super early, super late? - Yes, so I go to sleep like 2:00 AM usually, something like that.
And before 4:00 AM, but my girlfriend would go sleep midnight. So we did a compromise like 2:00 AM you know,
so I wake up around 10, 11. The more like 10, shower, make coffee,
I make coffee, like drip coffee, like the V60, you know the filter. And I'd boil water and then I put the coffee in,
and then chill, live with my girlfriend and then open laptops, start coding, check what's going on, like bugs or whatever.
- How long are you, like how stretches of time are you able to just sit behind the computer coding?
- So I used to need like really long stretches where I would do like all nighters and stuff to get shit done. But I've gotten trained to like have more interruptions
where I can like- - Because you have to. - This is life. There's a lot of distractions. Your girlfriend asks stuff,
people come over, whatever. - Yeah. - So I'm very fast now, I can lock in and lock out quite fast.
And heard people, developers or entrepreneurs with kids have the same thing. Before they're like, ah, I cannot work,
but they get used to it, and they get really productive in like short time, because they only have like 20 minutes
and then shit goes crazy again. So another constraint, right? - Yeah, it's funny.
- So I think that works for me, but yeah. And then cook food and stuff, like have lunch, steak and chicken and whatever.
- Do you eat a bunch of times a day? So you said coffee. - Yeah. - What are you doing? - Yeah, so a few hours later cook foods.
We get like locally stores like meat and stuff and vegetables and cook that,
and then second coffee and then go some more. Maybe go outside for lunch. You can mix fun stuff.
- How many hours are you saying a perfectly productive day? Are you doing programming? If you were like to kill it?
Are you doing like all day basically? - You mean like the special days where like- - Special days. - Girlfriend leaves to like bears or something,
and you're alone for a week at home. Which is amazing. - Yes. - You can just code. And you stay up all night and eat chocolate and-
- Yeah, chocolate. - Yeah, you know. - Yeah, yeah, okay, okay. Let's remove girlfriend from picture. Social life from picture.
It's just you. - Man, then goes shit crazy. - Yeah, because when shit goes crazy. - Yeah, now shit goes crazy.
- Okay, good. Let's rewind. Are you still waking up? There's coffee, there's no girlfriend to talk to.
There's no- - Now we wake up (Lex and Pieter laughs) Like 1:00 PM or 2:00 PM.
(Lex laughs) - Because you went to bed at 6:00 AM. - Yeah, because I was coding,
I was finding some new AI shit. - Yeah, yeah. - And I was studying it, and it was amazing. And I cannot sleep 'cause it's too important.
We need to stay awake. - Yeah, yeah. - We need to see all of this. We need to make something now. But that's the times I do make new stuff more,
so I think I have a friend, he actually books a hotel for like a week to leave his,
and he has a kid too, and his girlfriend and his kids stay in the house and he goes to another hotel. Sounds a little suspicious, right?
Going to the hotel. But all he does (Lex laughs) is like writing or coding. - Yeah. - He's a writer, and he needs like this alone time, this silence.
And I think for this flow state, it's true. I'm better maintaining stuff
when there's a lot of disruptions then like creating new stuff. I need this. And it's common, it's close. It's this uninterrupted period of time.
So yeah, I wake up like one, 2:00 PM, still coffee, shower. We still shower, you know,
and then this code like nonstop. Maybe my friends comes over anyway. - Just some distraction.
- Yeah, Andre, he codes too. So he comes over, we code together, we listen... It starts going back to like the Bali days,
you know, like- - Yeah. - Coworking days. - You're not really working with him, but you're just both working. - Because it's nice to have like the vibe
where you both sit together on the couch and coding on something and you actually, it's mostly silent or there's music,
and sometimes you ask something. But generally, you are really locked in. - What music are you listening to?
- I think like techno, like YouTube techno. There's a channel called HOR with Umlaut,
HO like double dot. It's Berlin techno, whatever. It looks like they film it in like a toilet
with like white tiles and stuff. And it's very cool. And they always have like, very good,
kind of industrial. - Industrial, so fast phase. - Kinda aggressive, like (imitates techno music) - Yeah, yeah. That's not distracting to you brain.
- That's amazing. - Okay. - I think distracting, man, jazz. I listen coffee jazz with my girlfriend when I wake up
and it's kind of like, this piano starts getting annoying. It's like (imitates jazz music). (Lex laughs) It's too many tones.
It's like, too many things go on. - [Lex] Yeah, yeah. - This industrial techno is like, you know, these African rain dances. (imitates techno music)
It's this transcendental- - Yeah. - Trans. - That's interesting, 'cause I actually mostly now listen to brown noise,
noise. - Yeah, wow. - Pretty loud. - Wow. - And one of the things you learn is your brain gets used to whatever.
So I'm sure to techno, if I actually give it a real chance. - [Pieter] Yeah. - My brain would get used to it. But like with noise,
what happens is something happens to your brain. I think there's a science to it, but I don't really care. You just have to be a scientist of one.
Study yourself, your own brain. Yeah. - For me, it does something.
I discovered it right away when I tried it for the first time. After about like a couple minutes,
every distraction just like disappears. And it goes like (imitates pressure deflating)
You can like hold focus on things like really well. It's weird.
You can like really focus on a thing. It doesn't really matter what that is. I think that's what people achieve with like meditation.
You can like focus on your breath, for example, for so long. - It's just normal brown noise. It's not like binaural.
- No, it's just normal brown noise. - It's like shhhh. - Yeah. - White noise, I think it's same. It's like make noise, white noise.
Brown noise I think is when it's like bassier. - Yeah, it's more diffused. More dampened. - Yeah. - Yeah, yeah. - Dampened.
- Yeah, I can see that. - No sharpness. - Yeah, sharp brightness. - Yeah, brightness. - Yeah, I can see that. And you use a headphones, right?
- Yeah, headphones. - Yeah. - I actually like, walk around in life often with brown noise. - Dude,
that's like psycho batshit. But it's cool. (Lex laughs) - Yeah, yeah, yeah. When I murder people, it helps. (Lex laughs)
It drowns out their screams. - Jesus Christ. - I'm sorry, I said too much. - Man, I'm gonna try brown noise.
- With a murder or for the coding? Yeah. - For the coating, yeah. - Okay, good. Try it, try it. But you have to like, with everything else,
you give it a real chance. - Yeah. - I also, like I said, do techno type stuff.
Electronic music on top of the brown noise, but then control the speed,
'cause the faster it goes, the more anxiety. So if I really need to get shit done, especially with programming, I'll have a beat.
- Yeah. - And it's great. It's cool. Say is cool to play those little tricks of your mind to study yourself. - Yeah.
- I usually don't like to have people around, 'cause when people, even if they're working, I don't know, I like people too much.
They're like, interesting. - There might be, yeah. In coworker space, I would just start talking too much. - Yeah. - Yeah, yeah.
- So there's a source of distraction. - Yeah, in the cowork space, we would do like a money pot, like a mug.
So we'd work for 45 minutes and then if you would say, like pair of words, you would get a fine, which is like $1.
So you'd put $1 to say, "Hey, what's up?" So $3 you put in the mug,
and then 15 minutes free time. We can like party, whatever. And then 45 minutes again working.
And that works. But you need to shut people up or they, you know. - I think there's an intimacy in being silent together-
- [Pieter] Yeah. - Maybe I'm uncomfortable with.
If you need to make yourself vulnerable and actually do it, like with close friends to just sit there in silence
for long periods of time. - Yeah, yeah, yeah. - And like doing a thing. - Dude, I watched this video of this podcast.
It was like this Buddhism podcast with people meditating, and they were interviewing each other or whatever, and like a podcast.
And suddenly after a question, it's like, yeah, yeah.
And they were just silent for like three minutes. And then they said it was amazing. Yeah, it was amazing.
I was like, wow, pretty cool. - Elon is like that. And I really like that,
he'll ask a question. I don't know, what's a perfectly productive day for you?
Like I just asked, and you just sit there for like 30 seconds thinking. - Yeah, he thinks.
- Yeah, I don't know. - That's so cool. I wish I could think more about,
but I wanna show you my heart. I wanna show you... go straight from my heart to my mouth to like saying the real thing.
And the more I think the more I start like filtering myself, right? And I wanna just throw it out there immediately.
- I do that more with team. I think he has a lot of practice in that. I do that as well. And in team setting, when you're thinking,
brainstorming. - Yeah. - And you allow yourself to just like, think in silence. - Yeah. - Just like,
'cause even in meetings, people wanna talk. - [Pieter] Yeah. - It's like, no, you think before you speak
and just like, it's okay to be silent together. - [Pieter] Yeah. - And if you allow yourself the room to do that, you can actually come up with really good ideas.
- Yeah. - So, okay, this perfect day, (laughs) how much caffeine are you consuming in this day?
- Man, too much, right? Because normally like two cups of coffee. But on this perfect day, we go to four maybe.
So we're starting to hit the anxiety levels. - So four cups is a lot for you? - Well, I think my coffees
are quite strong when I make them. It's like 20 grams of coffee powder in the V60. So my friends call 'em like nuclear coffee
'cause it's quite heavy. - Yeah, super strong. - It's quite strong. But it's nice to hit that anxiety level
where you're like almost panic attack. - Yeah. - But you're not there yet. But that's like, man, it's like super locked in.
Just like (imitates intense music) It's amazing. But I mean there's a space for that in my life.
But I think it's great for making new stuff. It's amazing. - Starting from scratch, creating a new thing. - Yes, I think girlfriends should let their guys
go away for like two weeks. Every few, no, every year at least.
Maybe every quarter, I dunno. And just sit and make some shit without,
they're amazing but like no disturbance. Just be alone. And then people can make something very, very amazing.
- Just wearing cowboy hats in the mountains like we showed. - Exactly, we can do that. - There's a movie about that. - With the laptops. - They didn't do much programming though.
- Yeah, you can do a little bit of that. - Okay. - And then a little bit of shipping. You could do both.
- It's a different, "Brokeback Mountain." - They need to allow us to go. They need like a man cave, right? - Yeah, to ship. - Yeah, to ship. (Lex laughs)
- Get shit done, yeah. It's a balance, okay, cool. What about sleep, naps and all that?
You not sleeping much? - I don't do naps in the day. I think power naps are good, but I'm never tired anymore in the day.
Man, also 'cause of gym, I'm not tired. I'm tired when I wanna... When it's night, I need to sleep.
- Yeah, me, I love naps. - I sleep very well. - I love naps. - Yeah. - I don't care. I don't know. I don't know why, brain shuts off, turns on.
I dunno if it's healthy or not. It just works. - Yeah. - I think with anything mental, physical, you have to be a student of your own body
and like- - Yeah, yeah, yeah. - Know what the limits are. You have to be skeptical taking advice from the internet in general,
'cause a lot of the advice is just like a good baseline for the general population. - It's not personalized, yeah.
- You have to become a student of your own- - Yeah. - Like of your own body, of your own self, of how you work, yeah.
I've done a lot of and just like, for me, fasting was an interesting one, because I used to eat a bunch of meals a day,
especially when I was lifting heavy. 'Cause everybody says, "You have to eat," kind of a lot, multiple meals a day.
But I realize I can get much stronger, feel much better if I eat once or twice a day on.
- Yeah, me too, yeah. - It's crazy. - I never understood this small meal thing, yeah. It didn't work for me. - Well, let me just ask you,
it'd interesting if you can comment on some of the other products you've created. We talked about Nomad List, Interior AI,
Photo AI, Therapist AI. What's RemoteOK? - It's a job board for remote jobs.
Because back then, like 10 years ago there was job boards, but it was not really specifically remote job, job boards.
So I made one... First of all, Nomad List is I made like nomad jobs, like a page. And a lot of companies started hiring
and they pay for job posts. So I spin it off to RemoteOK. And now it's like this number one or number two biggest remote job boards.
And it's also fully automated and people just post a job and people apply. It has like profiles as well.
It's kinda like LinkedIn for remotes work. - So's focus on remote only. - Yeah.
It's essentially like a simple job board. I discover job boards are way more complicated than you think.
Yeah, it's a job board for remote jobs. (Lex laughs) But the nice thing is you can charge a lot of money for job posts.
Man, it's good money. B2B, you can charge like, you start with 299. But at the peak when the Fed started printing money, 2021.
I was making like 140K a month with RemoteOK, with just job posts. And I started like adding crazy upsells,
like rainbow color, it's job posts. You can add your background images. - Yeah. - It's just upsells man. And you charge $1,000 for an upsell.
It was crazy. And all these companies is up so up. So yeah, we want everything.
Job post would cost 3,000, $4,000. And I was like, this is good business.
And then the Fed stopped printing money and it all went down, and it went down to like 10K a month from 140.
- Yeah. - Now it's back. I think it's like 40. It was good times. - I gotta ask you about back to the digital nomad life.
Minimalism
- [Pieter] Yeah. - You wrote a blog post on the reset. And in general, just giving away everything,
living a minimalist life. - Yeah. - What did it take to do that, like to get rid of everything?
- 10 years ago was like this trend in the blog. Back then blogs were so popular. It was a blogosphere, and it was like 100 things challenge.
- What is that? The 100 things challenge. - I mean, it's ridiculous. But like you write down every object you have in your house and you count it, you make a spreadsheet
and you're like, "Okay, I have 500 things." You need to get it down to 100. Why? This just the trend, so I did it.
I started like selling stuff, started throwing away off. And I did like MDMA and ecstasy like 2012 kind of.
And after that trip, I felt so different, and I felt like I had to start throwing shit away. I swear. - Yeah.
- And I started throwing shit away. And I felt that was like, it was almost the drug sending me to a path of like,
you need to throw all your shit away. You need to start go on a journey. You need to get out of here. And that's what the MDMA did, I think, yeah.
- How hard is it to get down to 100 items? - Boy, you need to like, sell your PC and stuff. You need to go on eBay
and then, man, going eBay, selling all your stuff is balancing, 'cause you discover society. You meet the craziest people.
You meet every range from rich to poor, everybody comes to your house to buy stuff. It's so funny, so interesting.
I recommend everybody do this. - Just to meet people that want your shit. - Yeah, it was so like, I didn't know,
I wasn't living in Amsterdam, and I didn't know, I have my own subculture or whatever. And I discovered the Dutch people, like as they are from eBay.
So I sold everything. - What's the weirdest thing you had to sell and you had to find a buyer for,
not the weirdest, but like, what's memorable? - So back then I was making music and we would make music videos
with like a Canon 5D camera. - Yeah. - Back then everybody's making films and musicals.
And we bought it with my friends and stuff. And it was kind of like, I had to sell this thing too,
'cause it was very expensive. It was like 6K or something. - [Lex] Yeah. - But it meant that selling this,
meant that we wouldn't make music theater anymore. I would leave Holland. This kind of stuff we were working on would end.
And I was kind of saying this music theater stuff, we're not getting famous in this or successful. We need to stop doing this.
This music production also, it's not really working. And it was kinda like, felt very bad for my friends,
'cause we would work together on this and to sell this camera that we'd make stuff with.
- It was a hard goodbye. - It was just a camera, but it was like, it felt like, sorry guys,
it doesn't work and I need to go. - Who bought it? Do you remember? It was some guy who couldn't possibly understand
the journey. - The emotion of it. - Yeah. - Yeah. - He just showed up, here's the money, thanks. - Yeah, but it was like cutting your life.
This shit ends now and now we gonna do new stuff. - I think it's beautiful. I did that twice in my life.
I give away everything, everything, everything. - Wow. - Like down to just pants, underwear, backpack. - Yeah.
- I think it's important to do. It shows you what's important. - Yeah, I think that's what I learned from it.
You learn that you can live a very little objects very little stuff,
but there's a counter to it. You lean more on the stuff, on the services, right? Like for example, you don't need a car,
you use Uber, right? Or you don't need kitchen stuff because you go to restaurants when you're traveling.
So you lean more on other people's services, but spend money on that as well. So that's good. - Yeah, but just letting go
of material possessions, which it gives a kind of freedom to how you move about the world. - Yeah. - It gives you
complete freedom to go into another city to- - Yeah, with your backpack. - The backpack. - Yeah. - There's a kind of freedom to it.
There's something about material possessions and having a place and all that, that ties you down a little bit. - Yeah. - Like spiritually.
- Yeah. - It's good to take a leap alternate into the world. Especially when you're younger to like. - Man, I recommend if you're 18, you get out of high school,
do this, go travel, and build some internet stuff, whatever. Bring your laptop.
It's amazing experience. Five years ago, it's still good in university, but now I'm thinking like, no, maybe skip university.
Just go first, like travel around a little bit, figure some stuff out. You can go back to university when you're 25.
You can like, okay, now I learned, I'd be successful in business. You have money at least. Now you can choose what you really wanna study.
Because people at 18, they go study what's probably good for the job market, right? So it probably makes more sense.
If you want that, go travel, build some businesses, and go back to university if you want. - So one of the biggest uses
of a university is the networking. You gain friends, you gain, like you meet people.
It's a forcing function to meet people. But if you can meet people out to the world- - Travel. - By travel. - Man, and you meet so many different cultures.
- I mean, the problem for me is like if I traveled at that young age, I'm attracted to people at the outskirts of the world.
Like for me- - Like where? - Not geographically. - Oh, like the subcultures.
- Yeah, like the weirdos, the darkness. - Yeah. Yeah, me too. - But that might not be the best networking at 18 years old.
(Lex and Pieter laughs) - No, man, if you're smart about it, you can stay safe. And I met so many weirdos from traveling.
That's how travel works. If you really let loose, you meet the craziest people. - [Pieter] Yeah. - And it's the most interesting people.
And I cannot recommend it enough. - Well see, the other thing is that when you're 18, I feel like depending on your personality,
you have to learn both how to be a weirdo and how to be a normie.
You still have to learn how to fit into society. - [Pieter] Yeah. - For a person like me, for example, who's always an outcast.
There's always a danger for going full outcast. - [Pieter] Yeah. - And that's a harder life if you,
if you go to like, go full artists in full like darkness, it's just a harder life. - You can come back,
you can come back to normie. - That's a skill. I think you have to learn- - You think? - How to fit in to polite society.
- But I was very strange outcast as well. And I'm more adaptable to normie now. - You learned it, yeah, learned it.
- After 30s, you're like, yeah. - But you need a skill, you have to learn. - Yeah.
Man, I feel also that, you start as an outcast, but the more you work on yourself, the less like shit you have.
You kind of start becoming more normie, because you become more chill with yourself and more happy. And it kind of makes you uninteresting, right?
- Yes. - A little bit. - Yes, yes. - The crazy people are always the most interesting.
If you've solved your internal struggles and you therapy and stuff and you kind of become kind of,
you know, it's not so interesting anymore maybe. - You don't have to be broken to be interesting,
I guess is what I'm saying. - Yeah. - What kind of things were left when you minimalized?
- So the backpack. - Yeah. - MacBook, toothbrush, some clothes, underwear, socks.
- [Lex] Yeah. - You don't need a lot of clothes in Asia 'cause it's hot. So you just wear swim pants, swim shorts.
You walk around flip flops. So very basic, T-shirt, and go to the laundromat and wash my stuff.
And I think it was like 50 things or something, yeah. - Yeah, it's nice.
As I mentioned to you, there's the show alone. - Yeah. - They really test you, 'cause, oh, you only get 10 items,
and you have to survive out in the wilderness. And then ax, like everybody brings an ax.
Some people also have a saw. - Wow.
- But usually ax does the job. You basically have to, in order to build a shelter, you have to cut down and to cut the trees and make,
and like- - Learn Minecraft. - Everything I learned about life, (Pieter laughs) I learn Minecraft, bro.
Yeah, yeah, you could. It's nice to create those constraints for yourself to understand what matters to you
and also how to be in this world. And one of the ways to do that is just to live a minimalist life.
But some people, I've met people that really enjoy material possessions and that brings some happiness, and that's a beautiful thing. - Yeah.
- For me, it doesn't, but people are different. - It gives me happiness for like two weeks.
- [Lex] Yeah. - I'm very quickly adapting to like a baseline. Hedonistic adaptation very fast.
- Yeah. - But man, if you look at the studies, most people like get a new car six months,
get a new house six months, you just feel the same. She's like, wow, should I buy all this stuff?
Studying hedonistic adaptation made me think a lot about minimalism. - And so that you don't even need to go through the whole journey of getting it.
Just focus on the thing that's more permanent. - Yeah. - Like building shit.
- Yeah, like people around you, like people you love. Nice food, nice experiences. - Yeah. - Meaningful work, those things.
Exercise, those things make you happy, I think. Make me happy for sure. - You wrote a blog post,
Emails
"Why I'm unreachable and maybe you should be too." What's your strategy on communicating with people?
- Yeah, so when I wrote that, I was getting so many DMs (Lex laughs) as you probably have, you have a million times more,
and people were getting angry that I wasn't responding and I was like, "Okay, I'll just close down these DMs completely.
And people got angry that I closed my DMs down, that I'm not like man of the people. - It's like you changed man. - Yeah, you've changed.
You got, you know, like this. And I'm like, I'll explain why. I just don't have the time in a day
to answer every question. And also people send you like crazy shit, man.
Stalkers and like, people write their whole life story for you and then ask you advice. Man, I have no idea.
I'm not a therapist. I don't know, I don't know this stuff. - But also beautiful stuff. - Absolutely, sure. - Life story.
I've posted a coffee forum, if you wanted to have a coffee with me. - Nice. - And I've gotten an extremely large number of submissions
and when I look at them, there's just like beautiful people in there. - Yeah, stories. - Beautiful human beings. - [Pieter] Yeah.
- There's really powerful stories and breaks my heart that I won't get to meet those people. - Yeah.
- And so this part of it is just like, there's only so much bandwidth to truly see other humans
and help them or understand them or hear them or yeah, see them. - Yeah, I have this problem that I try...
I wanna try help people and also like, oh- - Yeah. - Let's make startups and whatever.
And I've learned over the years that generally for me, and it sounds maybe bad, right?
But I helped my friend Andre, for example, he came up to me in a cowork space. That's how I met him. And he said, "I wanna learn to code. I wanna do startups, how do I do it?"
I said, "Okay, let's go install Nginx. Let's start coding." And he has this self-energy that he actually...
He doesn't need to be pushed, he just goes and he just goes and he ask questions and he doesn't ask too many questions.
He just goes, goes and learns it. And now he has a company and makes a lot of money, has his own startups.
And the people that I had to kind of like, that ask me for help, but then I gave help and then they started debating it.
- Yeah. - Do you have that? People ask you advice and they go against you say, "No, you're wrong, because." I'm like, "Okay, bro, I don't wanna debate.
You asked me for advice," right? And the people need to push generally,
it doesn't happen. - Yeah. - You need to have this energy for yourself. - Well, they're searching. They're searching, they're trying to figure it out.
But oftentimes their search, if they successfully find what they're looking for,
it'll be within. It sounds very like spiritual boost. - [Pieter] Yeah. - But it's really like figuring that shit out on your own.
- Yeah. - But they're reaching, they're trying to ask the world around them.
How do I live this life? How do I figure this out? But ultimately, the answer is gonna be from them working on themselves.
And literally, it's the stupid thing, but Googling and doing like searching- - Yeah, surfing is procrastination.
I think sending messages to people. - Yeah. - Is a lot of procrastination. Lex, how do you become successful podcaster? - Yeah. - Bro, just start.
Just go. - Yeah. And just go. - I would never ask you how to be successful podcaster?
I would just start it, and then I would copy your methods. I would say, "Ah, this guy's a Black background. We probably need this as well."
- Yeah, try it. - Yeah. - Yeah, try. And then you realize it's not about the Black background, it's about something else. So you find your own voice,
just keep trying stuff. - Exactly. - Meditation is a difficult thing. Like a lot of people copy and they don't move past it.
- Yeah. - You should understand their methods and then move past it. - Yeah. - Find yourself, find your own voice. Find your own. - Yeah, you imitate
and then you put your own spin to it, and that's like creative process. That's literally the whole create... Everybody always builds on the previous work.
- Yeah. - You shouldn't get stuck. - [Lex] 24 hours in a day, eight hours of sleep. You break it down into a math equation.
90 minutes of showering, clean up, coffee. It just keeps whittling down to zero.
- Man, it's not this specific, but I had to make like an average or something. - Yeah. Firefighting (laughs) oh, I like that.
One hours of groceries and errands. I've tried breaking down minute by minute, what I do in a day. - Yeah.
- Especially when my life was simpler. It's really refreshing to understand where you waste a lot of time. - Yeah. - And what you enjoy doing.
How many minutes it takes to be happy? (laughs) - Yeah. - Doing the thing that makes you happy and how many minutes it takes to be productive?
And you realize there's a lot of hours in the day- - Yeah. - If you spend it right. - Yeah, a lot of it's wasted, yeah. - For me, it's been the biggest battle
for the longest time is finding stretches of time where I can deeply focus into really, really deep work.
Just like zoom in and completely focused, cutting away all the distractions. - Yeah, me too. - That's the battle.
- Yeah. - It's unpleasant. It's extremely unpleasant. - We need to fly to an island, make a man cave island where we can just,
everybody can just code for a week, and just get shit done. Make new projects. - Yeah, yeah.
- But man, they called me psychopaths for this, 'cause it says like one hours of sex, hugs, love. Man, I had to write something,
and they were like, "Oh, this guy's psychopath." He plans his sex in specific hour- - Like hugs. - Bro, I don't.
- A counter for hugs. - Yeah, exactly. Yeah, like click, click, click.
- It's just a numerical representation of what life is. - Yeah. - It's like one of those,
when you draw out how many weeks you have in a life. - Oh, dude, this is like dark. Yeah, man, don't wanna look at that too much.
- Holy shit. - Yeah, man. (Lex laughs) How many times you see your parents? Jesus, man. - Yeah. - It's scary, man. - That's right.
It might be only a handful more times. - [Pieter] Yeah, man. - You just look at the math of it. If you see him once a year or twice a year.
- Yeah, FaceTime today. - Yeah. - Yeah. - I mean, that's like dark when you see somebody
you like seeing, like a friend that's on the outskirts of your friend group.
And then you realize like, well, I haven't really seen him for like three years.
So how many more times do we have- - Yeah. - That we see each other? - Do you believe that like, friends just slowly disappear from your life?
Your friend group evolves, right? - [Lex] So it does, it does. - There's a problem with Facebook, you get all these old friends from school,
when you were 10 years old. - Yeah. - Back when Facebook started. You would add friend them and then you're like, why are we in touch again?
Just keep the memories there. It's different life now. - Yeah, that might be a guy thing or I don't know.
There's certain friends I have that like, we don't interact often, but we're still friends. - Yeah. - Every time I see him
I think it's because we have a foundation of many shared experiences. - Yeah. - And many memories. I guess it's like nothing has changed.
Almost like, we've been talking every day, even if we haven't talked for a year. - Yeah, yeah, that's deep.
- Yeah. - Issues. - So I don't have to be interacting with them for them to be in a friend group. And then there's some people I interact with a lot.
So it depends, but there's just this network of good human beings that I can.
- [Pieter] Yeah. - Yeah, they have like a real love for them. And I can always count on them,
if any of them called me in the middle of the night, I'll get rid of a body, I'm there.
I like how that's a different definition of friendship, but it's true, it's true. - True friend.
Coffee
- You've become more and more famous recently. How's that affect you? - It's not recently because it's this gradual thing, right?
It keeps going, and I also don't know why it's keeps going.
- Does that put pressure on you to, 'cause you're pretty open on Twitter and you're just like basically building shit in the open.
- Yeah. - And just not really caring if it's too technical, if it's any of this just being out there,
does it put pressure on you? Is it become more popular to be a little bit more collected and?
- Man, I think the opposite, right? 'Cause the people I follow are interesting,
'cause they say whatever they think and they ship or whatever. It's so boring that people
start tweeting only about one topic. - Yeah. - I don't know anything about their personal life. I wanna know about their personal life. Like you do podcasts,
you ask about life stuff of personality. That's the most interesting part of business or sports. What's the behind the sport, the athlete, right?
Behind the entrepreneur. - Yeah. - That's interesting stuff. - To be human. - Yeah.
I shared a tweet went too far, but we were cleaning the toilet 'cause the toilet was clogged.
But it's just real stuff, 'cause Jensen Huang, the Nvidia guy, he says, he started cleaning toilets.
- That was cool. You tweeted something about the Denny's thing, I forget. - Yeah, it was recent.
Nvidia was started in a Denny's diner table. - And you made it somehow profound.
- [Pieter] Yeah, this one, this one. - Nvidia, a $3 trillion company was started in a Denny's, an American diner.
People need a third space to work on their laptops to build the next billion or trillion dollar company. What's the first and second space?
- The home office. - And then the in between. The island. - Yeah, I guess, yeah. - The island. - Yeah. You need a space to like congregate.
Man, and I found history on this. So 400 years ago in the coffee house of Europe. The scientific revolution, the enlightenment happened
because they would go to coffee houses, they would sit there, they would drink coffee and they would work. They would work.
They would write and they would do debates and they would organize marine routes, right?
They would do all the stuff in Coffeehouse in Europe, in France, in Austria, in UK, in Holland.
So we were always going to cafes to work and to have serendipitous conversations
with other people and start business and stuff. And like you asked me to come on here
and we flew to America, and the first thing I realized was that I've been to America before, but we were in this cafe and there's a lot of laptops.
Everybody's working on something. And I took this photo, and then when you're in Europe,
like large parts of Europe now, you cannot use a laptop anymore. It's like no laptop. Which I understand.
- But that is to you, a fundamental place to create shit. Isn't that natural, organic coworking space of a coffee?
- Well, for a lot of people. A lot of people have very small homes- - [Lex] Yeah. - And coworking spaces are kind of boring.
They're private. They're not serendipitous, kinda boring. Cafes are amazing 'cause random people can come in
and ask you what are you working on, or you know. And not just laptops, people are also having conversations
like they did 400 years ago debates or whatever. Things are happening. And man, I understand the aesthetics of it.
It's like, oh, startup bro, shipping is a bullshit startup.
But there's something more there. There's people actually making stuff, making new companies that the society benefits from.
We're benefiting from Nvidia. I think it's the US GDP for sure is benefiting from Nvidia,
European GDB could benefit if we build more companies. And I feel in Europe there's this vibe
and you have to connect things. But not allowing laptops in cafes is kind of like part of the vibe, which is like,
yeah, we're not really here to work. We're here to like enjoy life. I agree with this Anthony Bourdain, like this tweet was quote to Anthony Bourdain photo of him
with cigarettes and a coffee in France. And he said, "This is what the cafes are for." I agree.
- But there is some element of like entrepreneurship. You have to allow people to dream big
and work their ass off towards that dream. And then feel each other's energy as they interact with. - [Pieter] Yes.
- That's one of the things I liked in Silicon Valley when I was working there, is the cafes. - Yeah.
- There's a bunch of dreamers. You can make fun of them for like, everybody thinks they're gonna build- - Sure. - A trillion dollar company,
but like- - Yeah, and it's off. It's not everybody wins. 99% of people- - Yeah. - Will be bullshit. - But they're working their ass off. - Yeah, and they're doing something,
and you need to pass this StartupBros. Oh, it's StartupBros level. No, it's not. It's people making cool shit.
- Yeah. - And this will benefit you 'cause this will create jobs for your country and your region.
And I think in Europe that's a big problem. We have a very anti-entrepreneurial mindset.
- Dream big and build shit. - Yeah. - I mean this is really inspiring. This has been tweet of yours.
All the projects that you've tried and the ones that succeeded.
- Has very few. - Mute life. - [Pieter] It was for Twitter to share the mute list.
- Yeah. - Your mute words. - Fire calculator. No more Google, make a rank.
How much is my site project worth? Climate Finder, Ideas AI. - AirlineList still runs, but it doesn't make money.
AirlineList like compares the safety of airlines because I was nervous to fly. So I was like, let's collect all the data on crashes
for all the airplanes. - Bali sea cable. Nice, that's awesome.
Make village, nomad gear, 3D, and virtual reality dev, play in my inbox like you mentioned.
There's a lot of stuff. - Yeah, man. - I'm trying to find some embarrassing tweets of yours. - You can go to the highlight tab. It has all like the good shit kind.
- There you go. - This was Dubai. - POV, building an AI startup.
Wow, you're a real influencer. - (laughs) And if people copy this photo now and they change the screenshots.
It becomes like a meme. (Lex laughs) Of course, you know. - (laughs) This is good.
- That's how Dubai looks, it's insane. - That's beautiful. Architectural wise. It's crazy. The story behind these cities.
- Yeah, the story behind for sure. So this is about the European economy where like. - European economy landscape is ran by dinosaurs,
and today I studied this so I can produce you with my evidence. 80% of top EU companies were founded before 1950.
Only 36% of top US companies were founded before 1950. - Yeah, so the median founding of companies in US
is something like 1960, and the top companies, right? And the median in Europe is like 1,900 or something.
- Yeah. - So it's here 1913 and 1963. So there's a 50th difference.
- It's a good representation of the very thing you were talking about, the difference in the cultures,
entrepreneurial, spirit of the peoples. - But Europe used to be entrepreneurial. There was companies founded in 1800, 1850, 1900.
It flipped like around 1950 where America took the lead.
And I guess my point is like, I hope that Europe gets back to, 'cause I'm European, I hope that Europe gets back to being an entrepreneurial culture
where they build big companies again. 'Cause right now, all the old dinosaur companies control the economies.
They're lobbying with the government. Europe is also, they're infiltrated with the government where they create so much regulation,
I think it's called regulatory capture, right? Where it's very hard for a newcomer to join and to enter an industry
because there's too much regulation. So actually regulation is very good for big companies 'cause they can follow it. I can't follow it, right?
If I wanna start an AI startup in Europe now, I cannot because there's an AI regulation that makes it very complicated for me.
I probably need to get like notaries involved. I need to get certificates licenses. Whereas in America, I can just open my laptop.
I can start a AI startup right now, mostly.
E/acc
- What do you think about e/acc, effective accelerationist movement? - Man, you had Beff Jezos on,
I love Beff Jezos and he's amazing. And I think e/acc is very needed to
similarly create a more positive outlook on the future. Because people have been very pessimistic
about society, about the future of society, climate change, all this stuff.
E/acc is a positive outlook in the future. It's like technology can make us, we need to spend more energy.
We should find ways to of course get like clean energy. But we need to spend more energy to make cooler stuff
and go into space, and build more technology that can improve society. And we shouldn't shy away from technology.
Technology can be the answer for many things. - Yeah, build more. Don't spend so much time- - Yeah.
- On fearmongering and cautiousness and all this kind of stuff. Something is okay, something is good,
but most of the time should be spent on building and creating on- - Yeah. - And doing so unapologetically.
It's a refreshing reminder of what made United States great is all the builders, like you said, the entrepreneurs.
- [Pieter] Yeah. - We can't forget that in all the sort of discussions of how things could go wrong with technology and all this kind of stuff.
- Yeah, it goes Kaluga, China. China's now at the stage of like America, what? Like 1900 or something. They're building rapidly insane.
And obviously, China's massive problems. But that comes with the whole thing that comes with American is beginning
all that massive problems, right? But I think it's very dangerous for a country
or a region like Europe to, you get to this point where you're kind of complacent and you're kind of comfortable
and then you can either go this or you can go this way, right? You're from here, you go like this,
and then you can go this or this. I think you should go this way. - (laughs) And go off. - Yeah, go off.
I think it's the problem is the mind culture. So eacc, I made EU Acc, which is like the European kind of version.
(Lex laughs) I made like hoodies and stuff. So a lot of people wear like, this make Europe great again hat.
- Yeah. - I made it red first, but it became too like Trump. So now it's more like European blue. Make Europe great again.
- All right. Okay, so you had incredible life.
Advice for young people
Very successful, built a lot of cool stuff. So what advice would you give to young people about how to do the same?
- Man, I would listen to like nobody. Just do what you think is good and follow your heart, right?
Everybody peer press you into doing stuff you don't wanna do. And they tell you, parents or family or society tell you,
but try your own thing, 'cause it might work out. You can steer the ship.
It probably doesn't work out immediately. You probably go into very bad times like I did as well, relatively, right?
But in the end, if you're smart about it, you can make things work and you can create your own little life of things
as you did, as I did. And I think that should be more promoted. Do your own thing.
There's space in economy and in society for do your own thing. - Yeah. - It's like little villages,
everybody would sell. I would sell bread, you would sell meat. Everybody can do their own little thing. You don't need to be a normie as you say.
You can be what you really wanna be. - And go all out doing that thing. - Yeah, you gotta go all out
'cause if you half ass it, you cannot succeed. You need to go lean in to the outcast stuff.
Lean in to the being different, and just doing whatever it is that you wanna do, right?
- You got a whole asset. - Yeah, whole assets, yeah. - This was an incredible conversation.
It was an honor to finally meet you. Finally. - It was an honor to be here, Lex. - To talk to you and keep doing your thing.
Keep inspiring me and the world with all the cool stuff you're building. - Thank you, man.
- Thanks for listening to this conversation with Pieter Levels. To support this podcast, please check out our sponsors in the description.
And now let me leave you with some words from Drew Houston, Dropbox Co-founder, by the way, I love Dropbox.
Anyway, Drew said, "Don't worry about failure. You only have to be right once."
Thank you for listening, and I hope to see you next time.